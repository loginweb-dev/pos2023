
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `account_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_transactions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `account_id` int NOT NULL,
  `type` enum('debit','credit') COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_type` enum('opening_balance','fund_transfer','deposit') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(22,4) NOT NULL,
  `reff_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `operation_date` datetime NOT NULL,
  `created_by` int NOT NULL,
  `transaction_id` int DEFAULT NULL,
  `transaction_payment_id` int DEFAULT NULL,
  `transfer_transaction_id` int DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `account_transactions_account_id_index` (`account_id`),
  KEY `account_transactions_transaction_id_index` (`transaction_id`),
  KEY `account_transactions_transaction_payment_id_index` (`transaction_payment_id`),
  KEY `account_transactions_transfer_transaction_id_index` (`transfer_transaction_id`),
  KEY `account_transactions_created_by_index` (`created_by`),
  KEY `account_transactions_type_index` (`type`),
  KEY `account_transactions_sub_type_index` (`sub_type`),
  KEY `account_transactions_operation_date_index` (`operation_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `account_transactions` WRITE;
/*!40000 ALTER TABLE `account_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_transactions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `account_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_types` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_account_type_id` int DEFAULT NULL,
  `business_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `account_types_parent_account_type_id_index` (`parent_account_type_id`),
  KEY `account_types_business_id_index` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `account_types` WRITE;
/*!40000 ALTER TABLE `account_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_types` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_details` text COLLATE utf8mb4_unicode_ci,
  `account_type_id` int DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_by` int NOT NULL,
  `is_closed` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `accounts_business_id_index` (`business_id`),
  KEY `accounts_account_type_id_index` (`account_type_id`),
  KEY `accounts_created_by_index` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_log` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `log_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_id` int DEFAULT NULL,
  `subject_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_id` int DEFAULT NULL,
  `causer_id` int DEFAULT NULL,
  `causer_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `properties` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activity_log_log_name_index` (`log_name`)
) ENGINE=InnoDB AUTO_INCREMENT=436 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES (1,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-01-26 15:59:55','2023-01-26 15:59:55'),(2,'default','logout',1,'App\\User',1,1,'App\\User','[]','2023-01-26 16:08:37','2023-01-26 16:08:37'),(3,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-01-26 16:08:52','2023-01-26 16:08:52'),(4,'default','logout',1,'App\\User',1,1,'App\\User','[]','2023-01-26 16:40:56','2023-01-26 16:40:56'),(5,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-01-26 16:42:40','2023-01-26 16:42:40'),(6,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-01-26 16:47:36','2023-01-26 16:47:36'),(7,'default','login',3,'App\\User',3,3,'App\\User','[]','2023-01-26 19:20:27','2023-01-26 19:20:27'),(8,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-01-26 19:25:43','2023-01-26 19:25:43'),(9,'default','login',3,'App\\User',3,3,'App\\User','[]','2023-01-26 19:27:39','2023-01-26 19:27:39'),(10,'default','added',4,'App\\User',3,3,'App\\User','{\"name\":\" jonathan \"}','2023-01-26 19:38:51','2023-01-26 19:38:51'),(11,'default','added',5,'App\\User',3,3,'App\\User','{\"name\":\" percy \"}','2023-01-26 19:39:29','2023-01-26 19:39:29'),(12,'default','logout',3,'App\\User',3,3,'App\\User','[]','2023-01-26 19:39:42','2023-01-26 19:39:42'),(13,'default','login',4,'App\\User',3,4,'App\\User','[]','2023-01-26 19:39:49','2023-01-26 19:39:49'),(14,'default','logout',3,'App\\User',3,3,'App\\User','[]','2023-01-26 19:44:29','2023-01-26 19:44:29'),(15,'default','added',3,'App\\Transaction',3,4,'App\\User','{\"attributes\":{\"payment_status\":\"due\"}}','2023-01-26 19:44:35','2023-01-26 19:44:35'),(16,'default','login',5,'App\\User',3,5,'App\\User','[]','2023-01-26 19:44:36','2023-01-26 19:44:36'),(17,'default','added',4,'App\\Transaction',3,4,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":1066}}','2023-01-26 19:58:47','2023-01-26 19:58:47'),(18,'default','added',5,'App\\Transaction',3,5,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":1916.12}}','2023-01-26 19:58:47','2023-01-26 19:58:47'),(19,'default','added',4,'App\\Contact',3,5,'App\\User','[]','2023-01-26 20:10:30','2023-01-26 20:10:30'),(20,'default','added',6,'App\\Transaction',3,5,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":950}}','2023-01-26 20:10:43','2023-01-26 20:10:43'),(21,'default','added',5,'App\\Contact',3,4,'App\\User','[]','2023-01-26 20:12:32','2023-01-26 20:12:32'),(22,'default','added',7,'App\\Transaction',3,4,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"due\",\"final_total\":375}}','2023-01-26 20:14:11','2023-01-26 20:14:11'),(23,'default','edited',6,'App\\Transaction',3,5,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"due\",\"final_total\":950},\"old\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"950.0000\"}}','2023-01-26 20:14:12','2023-01-26 20:14:12'),(24,'default','logout',5,'App\\User',3,5,'App\\User','[]','2023-01-26 20:24:29','2023-01-26 20:24:29'),(25,'default','login',6,'App\\User',4,6,'App\\User','[]','2023-01-26 20:28:22','2023-01-26 20:28:22'),(26,'default','logout',6,'App\\User',4,6,'App\\User','[]','2023-01-26 20:41:54','2023-01-26 20:41:54'),(27,'default','login',6,'App\\User',4,6,'App\\User','[]','2023-01-26 20:42:06','2023-01-26 20:42:06'),(28,'default','logout',6,'App\\User',4,6,'App\\User','[]','2023-01-26 20:42:56','2023-01-26 20:42:56'),(29,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-01-26 20:43:04','2023-01-26 20:43:04'),(30,'default','logout',1,'App\\User',1,1,'App\\User','[]','2023-01-26 20:46:44','2023-01-26 20:46:44'),(31,'default','login',6,'App\\User',4,6,'App\\User','[]','2023-01-26 20:46:49','2023-01-26 20:46:49'),(32,'default','added',7,'App\\User',4,6,'App\\User','{\"name\":\" ventas 1 \"}','2023-01-26 21:00:07','2023-01-26 21:00:07'),(33,'default','logout',6,'App\\User',4,6,'App\\User','[]','2023-01-26 21:00:18','2023-01-26 21:00:18'),(34,'default','login',7,'App\\User',4,7,'App\\User','[]','2023-01-26 21:00:24','2023-01-26 21:00:24'),(35,'default','logout',1,'App\\User',1,1,'App\\User','[]','2023-01-26 21:00:49','2023-01-26 21:00:49'),(36,'default','login',6,'App\\User',4,6,'App\\User','[]','2023-01-26 21:00:58','2023-01-26 21:00:58'),(37,'default','logout',6,'App\\User',4,6,'App\\User','[]','2023-01-26 21:38:48','2023-01-26 21:38:48'),(38,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-01-26 21:38:52','2023-01-26 21:38:52'),(39,'default','logout',7,'App\\User',4,7,'App\\User','[]','2023-01-26 21:39:33','2023-01-26 21:39:33'),(40,'default','login',5,'App\\User',3,5,'App\\User','[]','2023-01-27 09:54:36','2023-01-27 09:54:36'),(41,'default','login',4,'App\\User',3,4,'App\\User','[]','2023-01-27 10:27:34','2023-01-27 10:27:34'),(42,'default','added',9,'App\\Transaction',3,5,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":1396}}','2023-01-27 10:28:52','2023-01-27 10:28:52'),(43,'default','added',7,'App\\Contact',3,5,'App\\User','[]','2023-01-27 10:29:25','2023-01-27 10:29:25'),(44,'default','edited',9,'App\\Transaction',3,5,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":1396},\"old\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"1396.0000\"}}','2023-01-27 10:29:38','2023-01-27 10:29:38'),(45,'default','logout',5,'App\\User',3,5,'App\\User','[]','2023-01-27 10:30:34','2023-01-27 10:30:34'),(46,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-01-27 10:30:45','2023-01-27 10:30:45'),(47,'default','logout',4,'App\\User',3,4,'App\\User','[]','2023-01-27 10:31:03','2023-01-27 10:31:03'),(48,'default','login',4,'App\\User',3,4,'App\\User','[]','2023-01-27 15:50:51','2023-01-27 15:50:51'),(49,'default','login',5,'App\\User',3,5,'App\\User','[]','2023-01-27 16:00:28','2023-01-27 16:00:28'),(50,'default','added',8,'App\\Contact',3,5,'App\\User','[]','2023-01-27 16:01:32','2023-01-27 16:01:32'),(51,'default','added',10,'App\\Transaction',3,5,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"due\",\"final_total\":1270}}','2023-01-27 16:04:52','2023-01-27 16:04:52'),(52,'default','added',11,'App\\Transaction',3,5,'App\\User','{\"attributes\":{\"payment_status\":\"due\"}}','2023-01-27 16:07:52','2023-01-27 16:07:52'),(53,'default','imported',9,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(54,'default','imported',10,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(55,'default','imported',11,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(56,'default','imported',12,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(57,'default','imported',13,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(58,'default','imported',14,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(59,'default','imported',15,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(60,'default','imported',16,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(61,'default','imported',17,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(62,'default','imported',18,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(63,'default','imported',19,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(64,'default','imported',20,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(65,'default','imported',21,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(66,'default','imported',22,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(67,'default','imported',23,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(68,'default','imported',24,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(69,'default','imported',25,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(70,'default','imported',26,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(71,'default','imported',27,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(72,'default','imported',28,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(73,'default','imported',29,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(74,'default','imported',30,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(75,'default','imported',31,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(76,'default','imported',32,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(77,'default','imported',33,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(78,'default','imported',34,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(79,'default','imported',35,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(80,'default','imported',36,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(81,'default','imported',37,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(82,'default','imported',38,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(83,'default','imported',39,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(84,'default','imported',40,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(85,'default','imported',41,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(86,'default','imported',42,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(87,'default','imported',43,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(88,'default','imported',44,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(89,'default','imported',45,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(90,'default','imported',46,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(91,'default','imported',47,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(92,'default','imported',48,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(93,'default','imported',49,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(94,'default','imported',50,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(95,'default','imported',51,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(96,'default','imported',52,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(97,'default','imported',53,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(98,'default','imported',54,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(99,'default','imported',55,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(100,'default','imported',56,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(101,'default','imported',57,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(102,'default','imported',58,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(103,'default','imported',59,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(104,'default','imported',60,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(105,'default','imported',61,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(106,'default','imported',62,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(107,'default','imported',63,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(108,'default','imported',64,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(109,'default','imported',65,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(110,'default','imported',66,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(111,'default','imported',67,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(112,'default','imported',68,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(113,'default','imported',69,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(114,'default','imported',70,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(115,'default','imported',71,'App\\Contact',3,4,'App\\User','[]','2023-01-27 16:35:10','2023-01-27 16:35:10'),(116,'default','logout',4,'App\\User',3,4,'App\\User','[]','2023-01-27 16:36:04','2023-01-27 16:36:04'),(117,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-01-27 16:36:17','2023-01-27 16:36:17'),(118,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-01-27 16:36:38','2023-01-27 16:36:38'),(119,'default','logout',5,'App\\User',3,5,'App\\User','[]','2023-01-27 16:37:01','2023-01-27 16:37:01'),(120,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-01-27 16:37:11','2023-01-27 16:37:11'),(121,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-01-27 16:39:27','2023-01-27 16:39:28'),(122,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-01-27 16:39:36','2023-01-27 16:39:36'),(123,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-01-27 16:53:23','2023-01-27 16:53:23'),(124,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-01-27 16:57:01','2023-01-27 16:57:01'),(125,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-01-28 11:09:15','2023-01-28 11:09:15'),(126,'default','logout',1,'App\\User',1,1,'App\\User','[]','2023-01-28 11:52:04','2023-01-28 11:52:04'),(127,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-01-28 11:52:11','2023-01-28 11:52:11'),(128,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-01-28 11:52:56','2023-01-28 11:52:56'),(129,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-01-28 11:53:03','2023-01-28 11:53:03'),(130,'default','logout',1,'App\\User',1,1,'App\\User','[]','2023-01-28 11:55:10','2023-01-28 11:55:10'),(131,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-01-28 11:55:19','2023-01-28 11:55:19'),(132,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-01-28 17:46:16','2023-01-28 17:46:16'),(133,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-01-28 17:46:20','2023-01-28 17:46:20'),(134,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-01-29 17:31:54','2023-01-29 17:31:54'),(135,'default','logout',1,'App\\User',1,1,'App\\User','[]','2023-01-29 19:42:29','2023-01-29 19:42:29'),(136,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-01-29 19:42:36','2023-01-29 19:42:36'),(137,'default','logout',1,'App\\User',1,1,'App\\User','[]','2023-01-29 19:42:49','2023-01-29 19:42:49'),(138,'default','login',5,'App\\User',3,5,'App\\User','[]','2023-01-29 19:42:54','2023-01-29 19:42:54'),(139,'default','logout',5,'App\\User',3,5,'App\\User','[]','2023-01-29 20:24:04','2023-01-29 20:24:04'),(140,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-01-29 20:24:09','2023-01-29 20:24:09'),(141,'default','login',5,'App\\User',3,5,'App\\User','[]','2023-01-30 10:06:49','2023-01-30 10:06:49'),(142,'default','login',4,'App\\User',3,4,'App\\User','[]','2023-01-30 10:07:55','2023-01-30 10:07:55'),(143,'default','added',73,'App\\Contact',3,5,'App\\User','[]','2023-01-30 10:17:46','2023-01-30 10:17:46'),(144,'default','added',12,'App\\Transaction',3,5,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":50}}','2023-01-30 10:19:19','2023-01-30 10:19:19'),(145,'default','logout',5,'App\\User',3,5,'App\\User','[]','2023-01-30 15:55:10','2023-01-30 15:55:10'),(146,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-01-30 15:55:15','2023-01-30 15:55:15'),(147,'default','logout',1,'App\\User',1,1,'App\\User','[]','2023-01-30 16:10:38','2023-01-30 16:10:38'),(148,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-01-30 16:16:17','2023-01-30 16:16:17'),(149,'default','login',4,'App\\User',3,4,'App\\User','[]','2023-01-31 10:21:42','2023-01-31 10:21:42'),(150,'default','login',5,'App\\User',3,5,'App\\User','[]','2023-01-31 10:21:57','2023-01-31 10:21:57'),(151,'default','added',13,'App\\Transaction',3,5,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":340}}','2023-01-31 10:23:25','2023-01-31 10:23:25'),(152,'default','added',14,'App\\Transaction',3,4,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"partial\",\"final_total\":500}}','2023-01-31 10:24:36','2023-01-31 10:24:36'),(153,'default','added',75,'App\\Contact',3,5,'App\\User','[]','2023-01-31 10:24:39','2023-01-31 10:24:39'),(154,'default','added',15,'App\\Transaction',3,5,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":60}}','2023-01-31 10:25:14','2023-01-31 10:25:14'),(155,'default','added',16,'App\\Transaction',3,4,'App\\User','{\"attributes\":{\"payment_status\":\"due\"}}','2023-01-31 10:26:16','2023-01-31 10:26:16'),(156,'default','added',17,'App\\Transaction',3,5,'App\\User','{\"attributes\":{\"payment_status\":\"due\"}}','2023-01-31 10:37:27','2023-01-31 10:37:27'),(157,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-01-31 14:30:51','2023-01-31 14:30:51'),(158,'default','logout',1,'App\\User',1,1,'App\\User','[]','2023-01-31 18:37:04','2023-01-31 18:37:04'),(159,'default','login',5,'App\\User',3,5,'App\\User','[]','2023-01-31 18:37:11','2023-01-31 18:37:11'),(160,'default','logout',5,'App\\User',3,5,'App\\User','[]','2023-01-31 18:39:09','2023-01-31 18:39:09'),(161,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-01-31 18:39:12','2023-01-31 18:39:12'),(162,'default','logout',1,'App\\User',1,1,'App\\User','[]','2023-01-31 18:41:26','2023-01-31 18:41:26'),(163,'default','login',5,'App\\User',3,5,'App\\User','[]','2023-01-31 18:41:31','2023-01-31 18:41:31'),(164,'default','logout',4,'App\\User',3,4,'App\\User','[]','2023-01-31 18:42:57','2023-01-31 18:42:57'),(165,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-01-31 18:43:10','2023-01-31 18:43:10'),(166,'default','logout',1,'App\\User',1,1,'App\\User','[]','2023-01-31 18:48:09','2023-01-31 18:48:09'),(167,'default','login',4,'App\\User',3,4,'App\\User','[]','2023-01-31 18:48:18','2023-01-31 18:48:18'),(168,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-02-01 10:44:14','2023-02-01 10:44:14'),(169,'default','logout',1,'App\\User',1,1,'App\\User','[]','2023-02-01 10:53:45','2023-02-01 10:53:45'),(170,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-02-01 10:55:14','2023-02-01 10:55:14'),(171,'default','logout',1,'App\\User',1,1,'App\\User','[]','2023-02-01 11:15:05','2023-02-01 11:15:05'),(172,'default','login',10,'App\\User',7,10,'App\\User','[]','2023-02-01 11:15:12','2023-02-01 11:15:12'),(173,'default','login',4,'App\\User',3,4,'App\\User','[]','2023-02-03 10:37:44','2023-02-03 10:37:44'),(174,'default','payment_edited',10,'App\\Transaction',3,4,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"partial\",\"final_total\":\"1270.0000\"},\"old\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"due\",\"final_total\":\"1270.0000\"}}','2023-02-03 10:39:09','2023-02-03 10:39:09'),(175,'default','login',5,'App\\User',3,5,'App\\User','[]','2023-02-03 10:45:52','2023-02-03 10:45:52'),(176,'default','added',77,'App\\Contact',3,5,'App\\User','[]','2023-02-03 10:48:11','2023-02-03 10:48:11'),(177,'default','added',18,'App\\Transaction',3,5,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":340}}','2023-02-03 10:52:34','2023-02-03 10:52:34'),(178,'default','added',19,'App\\Transaction',3,4,'App\\User','{\"attributes\":{\"payment_status\":\"due\"}}','2023-02-03 14:12:21','2023-02-03 14:12:21'),(179,'default','login',5,'App\\User',3,5,'App\\User','[]','2023-02-03 14:12:38','2023-02-03 14:12:38'),(180,'default','edited',10,'App\\Transaction',3,4,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"partial\",\"final_total\":1270},\"old\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"partial\",\"final_total\":\"1270.0000\"}}','2023-02-03 14:13:54','2023-02-03 14:13:54'),(181,'default','edited',10,'App\\Transaction',3,4,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"partial\",\"final_total\":1270},\"old\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"partial\",\"final_total\":\"1270.0000\"}}','2023-02-03 14:14:54','2023-02-03 14:14:54'),(182,'default','sell_deleted',10,'App\\Transaction',3,4,'App\\User','{\"id\":10,\"invoice_no\":\"0006\",\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"partial\",\"final_total\":\"1270.0000\"}}','2023-02-03 14:20:23','2023-02-03 14:20:23'),(183,'default','added',20,'App\\Transaction',3,4,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"partial\",\"final_total\":1270}}','2023-02-03 14:20:59','2023-02-03 14:20:59'),(184,'default','edited',11,'App\\Transaction',3,5,'App\\User','{\"attributes\":{\"payment_status\":\"paid\"}}','2023-02-03 14:23:11','2023-02-03 14:23:11'),(185,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-02-05 16:17:02','2023-02-05 16:17:02'),(186,'default','login',4,'App\\User',3,4,'App\\User','[]','2023-02-06 18:57:57','2023-02-06 18:57:57'),(187,'default','login',5,'App\\User',3,5,'App\\User','[]','2023-02-07 14:35:38','2023-02-07 14:35:38'),(188,'default','login',5,'App\\User',3,5,'App\\User','[]','2023-02-08 19:32:30','2023-02-08 19:32:30'),(189,'default','login',4,'App\\User',3,4,'App\\User','[]','2023-02-10 19:32:19','2023-02-10 19:32:19'),(190,'default','added',78,'App\\Contact',3,4,'App\\User','[]','2023-02-10 19:35:38','2023-02-10 19:35:38'),(191,'default','added',21,'App\\Transaction',3,4,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"partial\",\"final_total\":1740}}','2023-02-10 19:36:01','2023-02-10 19:36:01'),(192,'default','added',79,'App\\Contact',3,4,'App\\User','[]','2023-02-10 19:39:23','2023-02-10 19:39:23'),(193,'default','added',22,'App\\Transaction',3,4,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"partial\",\"final_total\":500}}','2023-02-10 19:40:09','2023-02-10 19:40:09'),(194,'default','added',23,'App\\Transaction',3,4,'App\\User','{\"attributes\":{\"payment_status\":\"due\"}}','2023-02-10 19:41:59','2023-02-10 19:41:59'),(195,'default','login',5,'App\\User',3,5,'App\\User','[]','2023-02-10 19:42:46','2023-02-10 19:42:46'),(196,'default','added',24,'App\\Transaction',3,5,'App\\User','{\"attributes\":{\"payment_status\":\"due\"}}','2023-02-10 19:52:49','2023-02-10 19:52:49'),(197,'default','payment_edited',7,'App\\Transaction',3,4,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"partial\",\"final_total\":\"375.0000\"},\"old\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"due\",\"final_total\":\"375.0000\"}}','2023-02-10 20:06:18','2023-02-10 20:06:18'),(198,'default','login',5,'App\\User',3,5,'App\\User','[]','2023-02-11 00:53:12','2023-02-11 00:53:12'),(199,'default','edited',24,'App\\Transaction',3,5,'App\\User','{\"attributes\":{\"payment_status\":\"paid\"}}','2023-02-11 00:59:00','2023-02-11 00:59:00'),(200,'default','login',4,'App\\User',3,4,'App\\User','[]','2023-02-11 10:22:29','2023-02-11 10:22:29'),(201,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-02-13 18:00:32','2023-02-13 18:00:32'),(202,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-13 18:01:31','2023-02-13 18:01:31'),(203,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-02-13 18:43:00','2023-02-13 18:43:00'),(204,'default','login',8,'App\\User',5,8,'App\\User','[]','2023-02-13 18:43:27','2023-02-13 18:43:27'),(205,'default','logout',8,'App\\User',5,8,'App\\User','[]','2023-02-13 18:45:48','2023-02-13 18:45:48'),(206,'default','login',9,'App\\User',6,9,'App\\User','[]','2023-02-13 18:45:53','2023-02-13 18:45:53'),(207,'default','logout',9,'App\\User',6,9,'App\\User','[]','2023-02-13 19:00:12','2023-02-13 19:00:12'),(208,'default','login',8,'App\\User',5,8,'App\\User','[]','2023-02-13 19:00:18','2023-02-13 19:00:18'),(209,'default','logout',1,'App\\User',1,1,'App\\User','[]','2023-02-13 19:05:36','2023-02-13 19:05:36'),(210,'default','login',8,'App\\User',5,8,'App\\User','[]','2023-02-13 19:07:44','2023-02-13 19:07:44'),(211,'default','logout',8,'App\\User',5,8,'App\\User','[]','2023-02-13 19:20:02','2023-02-13 19:20:02'),(212,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-02-13 19:20:13','2023-02-13 19:20:13'),(213,'default','logout',1,'App\\User',1,1,'App\\User','[]','2023-02-13 19:26:27','2023-02-13 19:26:27'),(214,'default','login',8,'App\\User',5,8,'App\\User','[]','2023-02-13 19:26:34','2023-02-13 19:26:34'),(215,'default','logout',8,'App\\User',5,8,'App\\User','[]','2023-02-13 19:30:35','2023-02-13 19:30:35'),(216,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-02-13 19:30:43','2023-02-13 19:30:43'),(217,'default','logout',1,'App\\User',1,1,'App\\User','[]','2023-02-13 19:47:09','2023-02-13 19:47:09'),(218,'default','login',8,'App\\User',5,8,'App\\User','[]','2023-02-13 19:47:20','2023-02-13 19:47:20'),(219,'default','added',80,'App\\Contact',5,8,'App\\User','[]','2023-02-13 20:25:41','2023-02-13 20:25:41'),(220,'default','added',29,'App\\Transaction',5,8,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"due\",\"final_total\":2.1}}','2023-02-13 20:25:47','2023-02-13 20:25:47'),(221,'default','payment_edited',29,'App\\Transaction',5,8,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"2.1000\"},\"old\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"due\",\"final_total\":\"2.1000\"}}','2023-02-13 20:28:15','2023-02-13 20:28:15'),(222,'default','added',30,'App\\Transaction',5,8,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"due\",\"final_total\":91}}','2023-02-13 20:30:14','2023-02-13 20:30:14'),(223,'default','added',31,'App\\Transaction',5,8,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"due\",\"final_total\":14.7}}','2023-02-13 20:34:54','2023-02-13 20:34:54'),(224,'default','added',32,'App\\Transaction',5,8,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"due\",\"final_total\":105}}','2023-02-13 20:35:51','2023-02-13 20:35:51'),(225,'default','added',33,'App\\Transaction',5,8,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"due\",\"final_total\":45.5}}','2023-02-13 20:39:49','2023-02-13 20:39:49'),(226,'default','added',34,'App\\Transaction',5,8,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"due\",\"final_total\":9.1}}','2023-02-13 20:42:13','2023-02-13 20:42:13'),(227,'default','added',81,'App\\Contact',5,8,'App\\User','[]','2023-02-13 20:48:47','2023-02-13 20:48:47'),(228,'default','added',35,'App\\Transaction',5,8,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"due\",\"final_total\":30}}','2023-02-13 20:48:51','2023-02-13 20:48:51'),(229,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-14 10:30:26','2023-02-14 10:30:26'),(230,'default','added',11,'App\\User',2,2,'App\\User','{\"name\":\"Sra Gaby Luna Duchen\"}','2023-02-14 10:47:59','2023-02-14 10:47:59'),(231,'default','edited',2,'App\\User',2,2,'App\\User','{\"name\":\"Dr Rodrigo Skot Alvarez\"}','2023-02-14 10:51:12','2023-02-14 10:51:12'),(232,'default','edited',11,'App\\User',2,2,'App\\User','{\"name\":\"Sra Gaby Luna Duchen\"}','2023-02-14 10:52:06','2023-02-14 10:52:06'),(233,'default','edited',11,'App\\User',2,2,'App\\User','{\"name\":\"Sra Gaby Luna Duchen\"}','2023-02-14 10:53:15','2023-02-14 10:53:15'),(234,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-02-14 11:02:32','2023-02-14 11:02:32'),(235,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-14 11:03:02','2023-02-14 11:03:02'),(236,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-14 16:18:52','2023-02-14 16:18:52'),(237,'default','login',4,'App\\User',3,4,'App\\User','[]','2023-02-14 20:22:51','2023-02-14 20:22:51'),(238,'default','login',12,'App\\User',8,12,'App\\User','[]','2023-02-15 09:06:29','2023-02-15 09:06:29'),(239,'default','login',9,'App\\User',6,9,'App\\User','[]','2023-02-15 21:47:15','2023-02-15 21:47:15'),(240,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-16 10:15:14','2023-02-16 10:15:14'),(241,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-02-16 11:03:08','2023-02-16 11:03:08'),(242,'default','login',4,'App\\User',3,4,'App\\User','[]','2023-02-16 21:03:32','2023-02-16 21:03:32'),(243,'default','added',42,'App\\Transaction',3,4,'App\\User','{\"attributes\":{\"payment_status\":\"due\"}}','2023-02-16 21:53:51','2023-02-16 21:53:51'),(244,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-17 09:32:19','2023-02-17 09:32:19'),(245,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-17 10:10:41','2023-02-17 10:10:41'),(246,'default','edited',11,'App\\User',2,2,'App\\User','{\"name\":\"Sra Gaby Luna Duchen\"}','2023-02-17 10:18:33','2023-02-17 10:18:33'),(247,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-02-17 10:18:42','2023-02-17 10:18:42'),(248,'default','login',11,'App\\User',2,11,'App\\User','[]','2023-02-17 10:18:48','2023-02-17 10:18:48'),(249,'default','logout',11,'App\\User',2,11,'App\\User','[]','2023-02-17 10:19:33','2023-02-17 10:19:33'),(250,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-17 10:19:40','2023-02-17 10:19:40'),(251,'default','added',43,'App\\Transaction',2,2,'App\\User','{\"attributes\":{\"status\":\"in_transit\"}}','2023-02-17 10:29:48','2023-02-17 10:29:48'),(252,'default','edited',43,'App\\Transaction',2,2,'App\\User','{\"attributes\":{\"status\":\"final\"},\"old\":{\"status\":\"in_transit\"}}','2023-02-17 10:31:48','2023-02-17 10:31:48'),(253,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-02-17 10:33:58','2023-02-17 10:33:58'),(254,'default','login',11,'App\\User',2,11,'App\\User','[]','2023-02-17 10:34:06','2023-02-17 10:34:06'),(255,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-17 10:34:49','2023-02-17 10:34:49'),(256,'default','edited',11,'App\\User',2,2,'App\\User','{\"name\":\"Sra Gaby Luna Duchen\"}','2023-02-17 10:40:17','2023-02-17 10:40:17'),(257,'default','logout',11,'App\\User',2,11,'App\\User','[]','2023-02-17 10:41:29','2023-02-17 10:41:29'),(258,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-17 10:41:36','2023-02-17 10:41:36'),(259,'default','added',45,'App\\Transaction',2,2,'App\\User','{\"attributes\":{\"status\":\"in_transit\"}}','2023-02-17 10:43:36','2023-02-17 10:43:36'),(260,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-02-17 10:44:18','2023-02-17 10:44:18'),(261,'default','login',11,'App\\User',2,11,'App\\User','[]','2023-02-17 10:44:24','2023-02-17 10:44:24'),(262,'default','logout',11,'App\\User',2,11,'App\\User','[]','2023-02-17 10:45:06','2023-02-17 10:45:06'),(263,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-17 10:45:12','2023-02-17 10:45:12'),(264,'default','edited',45,'App\\Transaction',2,2,'App\\User','{\"attributes\":{\"status\":\"final\"},\"old\":{\"status\":\"in_transit\"}}','2023-02-17 10:45:29','2023-02-17 10:45:29'),(265,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-02-17 10:45:49','2023-02-17 10:45:49'),(266,'default','login',11,'App\\User',2,11,'App\\User','[]','2023-02-17 10:45:52','2023-02-17 10:45:52'),(267,'default','logout',11,'App\\User',2,11,'App\\User','[]','2023-02-17 10:47:09','2023-02-17 10:47:09'),(268,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-17 10:47:14','2023-02-17 10:47:14'),(269,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-02-17 10:50:27','2023-02-17 10:50:27'),(270,'default','login',11,'App\\User',2,11,'App\\User','[]','2023-02-17 10:50:31','2023-02-17 10:50:31'),(271,'default','logout',11,'App\\User',2,11,'App\\User','[]','2023-02-17 10:52:29','2023-02-17 10:52:29'),(272,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-17 10:52:32','2023-02-17 10:52:32'),(273,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-02-17 11:50:42','2023-02-17 11:50:42'),(274,'default','login',11,'App\\User',2,11,'App\\User','[]','2023-02-17 11:50:55','2023-02-17 11:50:55'),(275,'default','logout',11,'App\\User',2,11,'App\\User','[]','2023-02-17 11:51:52','2023-02-17 11:51:52'),(276,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-17 11:52:06','2023-02-17 11:52:06'),(277,'default','edited',11,'App\\User',2,2,'App\\User','{\"name\":\"Sra Gaby Luna Duchen\"}','2023-02-17 12:03:08','2023-02-17 12:03:08'),(278,'default','added',13,'App\\User',2,2,'App\\User','{\"name\":\"Sr Junior Mendez\"}','2023-02-17 12:07:08','2023-02-17 12:07:08'),(279,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-02-17 12:10:54','2023-02-17 12:10:54'),(280,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-17 12:11:09','2023-02-17 12:11:09'),(281,'default','added',47,'App\\Transaction',2,2,'App\\User','{\"attributes\":{\"status\":\"final\"}}','2023-02-17 12:15:27','2023-02-17 12:15:27'),(282,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-02-17 12:58:30','2023-02-17 12:58:30'),(283,'default','login',11,'App\\User',2,11,'App\\User','[]','2023-02-17 12:58:40','2023-02-17 12:58:40'),(284,'default','logout',11,'App\\User',2,11,'App\\User','[]','2023-02-17 12:59:02','2023-02-17 12:59:02'),(285,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-17 12:59:14','2023-02-17 12:59:14'),(286,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-02-17 13:00:26','2023-02-17 13:00:26'),(287,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-17 13:00:33','2023-02-17 13:00:33'),(288,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-17 13:44:44','2023-02-17 13:44:44'),(289,'default','login',11,'App\\User',2,11,'App\\User','[]','2023-02-17 13:46:21','2023-02-17 13:46:21'),(290,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-02-17 13:46:25','2023-02-17 13:46:25'),(291,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-17 13:51:00','2023-02-17 13:51:00'),(292,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-02-17 13:52:56','2023-02-17 13:52:56'),(293,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-17 16:26:33','2023-02-17 16:26:33'),(294,'default','edited',11,'App\\User',2,2,'App\\User','{\"name\":\"Sra Gaby Luna Duchen\"}','2023-02-17 16:27:22','2023-02-17 16:27:22'),(295,'default','added',63,'App\\Transaction',2,2,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"sub_status\":\"quotation\",\"final_total\":70}}','2023-02-17 16:35:27','2023-02-17 16:35:27'),(296,'default','added',64,'App\\Transaction',2,2,'App\\User','{\"attributes\":{\"payment_status\":\"due\"}}','2023-02-17 16:37:11','2023-02-17 16:37:11'),(297,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-02-17 16:41:27','2023-02-17 16:41:27'),(298,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-17 16:43:58','2023-02-17 16:43:58'),(299,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-02-17 16:48:07','2023-02-17 16:48:07'),(300,'default','login',11,'App\\User',2,11,'App\\User','[]','2023-02-17 16:48:14','2023-02-17 16:48:14'),(301,'default','logout',11,'App\\User',2,11,'App\\User','[]','2023-02-17 16:53:53','2023-02-17 16:53:53'),(302,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-17 16:54:00','2023-02-17 16:54:00'),(303,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-02-17 16:59:45','2023-02-17 16:59:45'),(304,'default','login',11,'App\\User',2,11,'App\\User','[]','2023-02-17 16:59:53','2023-02-17 16:59:53'),(305,'default','logout',11,'App\\User',2,11,'App\\User','[]','2023-02-17 17:00:13','2023-02-17 17:00:13'),(306,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-17 17:00:20','2023-02-17 17:00:20'),(307,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-02-17 17:02:53','2023-02-17 17:02:53'),(308,'default','login',11,'App\\User',2,11,'App\\User','[]','2023-02-17 17:03:12','2023-02-17 17:03:12'),(309,'default','logout',11,'App\\User',2,11,'App\\User','[]','2023-02-17 17:21:25','2023-02-17 17:21:25'),(310,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-17 17:21:32','2023-02-17 17:21:32'),(311,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-02-17 17:27:55','2023-02-17 17:27:55'),(312,'default','login',11,'App\\User',2,11,'App\\User','[]','2023-02-17 17:28:03','2023-02-17 17:28:03'),(313,'default','logout',11,'App\\User',2,11,'App\\User','[]','2023-02-17 17:36:21','2023-02-17 17:36:21'),(314,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-17 17:36:29','2023-02-17 17:36:29'),(315,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-02-17 17:48:54','2023-02-17 17:48:54'),(316,'default','login',11,'App\\User',2,11,'App\\User','[]','2023-02-17 17:48:59','2023-02-17 17:48:59'),(317,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-02-17 17:49:00','2023-02-17 17:49:00'),(318,'default','logout',11,'App\\User',2,11,'App\\User','[]','2023-02-17 17:49:16','2023-02-17 17:49:16'),(319,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-17 17:49:21','2023-02-17 17:49:21'),(320,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-02-17 17:51:15','2023-02-17 17:51:15'),(321,'default','login',11,'App\\User',2,11,'App\\User','[]','2023-02-17 17:51:19','2023-02-17 17:51:19'),(322,'default','logout',11,'App\\User',2,11,'App\\User','[]','2023-02-17 17:51:42','2023-02-17 17:51:42'),(323,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-17 17:51:48','2023-02-17 17:51:48'),(324,'default','login',2,'App\\User',2,2,'App\\User','[]','2023-02-17 17:52:30','2023-02-17 17:52:30'),(325,'default','added',65,'App\\Transaction',2,2,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"sub_status\":\"quotation\",\"final_total\":15}}','2023-02-17 17:53:05','2023-02-17 17:53:05'),(326,'default','added',66,'App\\Transaction',2,2,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"sub_status\":\"quotation\",\"final_total\":15}}','2023-02-17 17:53:29','2023-02-17 17:53:29'),(327,'default','logout',2,'App\\User',2,2,'App\\User','[]','2023-02-17 17:58:24','2023-02-17 17:58:24'),(328,'default','added',86,'App\\Transaction',2,11,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":15}}','2023-02-17 18:38:47','2023-02-17 18:38:47'),(329,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-02-24 17:22:18','2023-02-24 17:22:18'),(330,'default','logout',1,'App\\User',1,1,'App\\User','[]','2023-02-24 17:23:31','2023-02-24 17:23:31'),(331,'default','login',6,'App\\User',4,6,'App\\User','[]','2023-02-24 17:23:41','2023-02-24 17:23:41'),(332,'default','login',6,'App\\User',4,6,'App\\User','[]','2023-02-24 17:24:31','2023-02-24 17:24:31'),(333,'default','login',4,'App\\User',3,4,'App\\User','[]','2023-02-26 20:46:02','2023-02-26 20:46:02'),(334,'default','payment_edited',21,'App\\Transaction',3,4,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"1740.0000\"},\"old\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"partial\",\"final_total\":\"1740.0000\"}}','2023-02-26 20:47:50','2023-02-26 20:47:50'),(335,'default','login',4,'App\\User',3,4,'App\\User','[]','2023-03-01 21:58:56','2023-03-01 21:58:56'),(336,'default','payment_edited',14,'App\\Transaction',3,4,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"500.0000\"},\"old\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"partial\",\"final_total\":\"500.0000\"}}','2023-03-01 22:00:27','2023-03-01 22:00:27'),(337,'default','login',14,'App\\User',9,14,'App\\User','[]','2023-03-06 14:09:25','2023-03-06 14:09:25'),(338,'default','login',14,'App\\User',9,14,'App\\User','[]','2023-03-06 20:39:40','2023-03-06 20:39:40'),(339,'default','login',15,'App\\User',10,15,'App\\User','[]','2023-03-21 16:07:30','2023-03-21 16:07:30'),(340,'default','logout',15,'App\\User',10,15,'App\\User','[]','2023-03-21 16:09:59','2023-03-21 16:09:59'),(341,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-03-21 16:10:06','2023-03-21 16:10:06'),(342,'default','login',15,'App\\User',10,15,'App\\User','[]','2023-03-21 16:12:51','2023-03-21 16:12:51'),(343,'default','added',85,'App\\Contact',10,15,'App\\User','[]','2023-03-21 16:46:26','2023-03-21 16:46:26'),(344,'default','added',87,'App\\Transaction',10,15,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":120}}','2023-03-21 16:54:13','2023-03-21 16:54:13'),(345,'default','added',88,'App\\Transaction',10,15,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":120}}','2023-03-21 16:55:19','2023-03-21 16:55:19'),(346,'default','added',89,'App\\Transaction',10,15,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":120}}','2023-03-21 16:58:45','2023-03-21 16:58:45'),(347,'default','added',90,'App\\Transaction',10,15,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":75}}','2023-03-21 17:00:30','2023-03-21 17:00:30'),(348,'default','added',91,'App\\Transaction',10,15,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":75}}','2023-03-21 17:00:56','2023-03-21 17:00:56'),(349,'default','added',92,'App\\Transaction',10,15,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":45}}','2023-03-21 18:38:57','2023-03-21 18:38:57'),(350,'default','added',93,'App\\Transaction',10,15,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":150}}','2023-03-21 18:50:28','2023-03-21 18:50:28'),(351,'default','added',94,'App\\Transaction',10,15,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":195}}','2023-03-21 19:01:17','2023-03-21 19:01:17'),(352,'default','added',95,'App\\Transaction',10,15,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":120}}','2023-03-21 19:04:00','2023-03-21 19:04:00'),(353,'default','added',96,'App\\Transaction',10,15,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":120}}','2023-03-21 19:15:38','2023-03-21 19:15:38'),(354,'default','added',97,'App\\Transaction',10,15,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":120}}','2023-03-21 19:19:18','2023-03-21 19:19:18'),(355,'default','added',98,'App\\Transaction',10,15,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":120}}','2023-03-21 19:28:12','2023-03-21 19:28:12'),(356,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-03-22 11:16:05','2023-03-22 11:16:05'),(357,'default','logout',15,'App\\User',10,15,'App\\User','[]','2023-03-22 11:25:48','2023-03-22 11:25:48'),(358,'default','login',15,'App\\User',10,15,'App\\User','[]','2023-03-22 11:29:23','2023-03-22 11:29:23'),(359,'default','added',99,'App\\Transaction',10,15,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":120}}','2023-03-22 11:33:30','2023-03-22 11:33:30'),(360,'default','added',86,'App\\Contact',10,15,'App\\User','[]','2023-03-22 11:34:22','2023-03-22 11:34:22'),(361,'default','added',100,'App\\Transaction',10,15,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":100}}','2023-03-22 11:35:31','2023-03-22 11:35:31'),(362,'default','logout',1,'App\\User',1,1,'App\\User','[]','2023-03-22 11:58:02','2023-03-22 11:58:02'),(363,'default','logout',15,'App\\User',10,15,'App\\User','[]','2023-03-22 11:58:45','2023-03-22 11:58:45'),(364,'default','login',15,'App\\User',10,15,'App\\User','[]','2023-03-22 11:59:04','2023-03-22 11:59:04'),(365,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-03-22 12:04:28','2023-03-22 12:04:28'),(366,'default','logout',15,'App\\User',10,15,'App\\User','[]','2023-03-22 12:06:32','2023-03-22 12:06:32'),(367,'default','login',16,'App\\User',11,16,'App\\User','[]','2023-03-22 12:12:34','2023-03-22 12:12:34'),(368,'default','login',15,'App\\User',10,15,'App\\User','[]','2023-03-22 13:12:38','2023-03-22 13:12:38'),(369,'default','logout',16,'App\\User',11,16,'App\\User','[]','2023-03-22 13:27:48','2023-03-22 13:27:48'),(370,'default','login',15,'App\\User',10,15,'App\\User','[]','2023-03-22 13:27:55','2023-03-22 13:27:55'),(371,'default','login',15,'App\\User',10,15,'App\\User','[]','2023-03-22 13:47:33','2023-03-22 13:47:33'),(372,'default','logout',15,'App\\User',10,15,'App\\User','[]','2023-03-22 14:42:21','2023-03-22 14:42:21'),(373,'default','login',16,'App\\User',11,16,'App\\User','[]','2023-03-22 14:46:40','2023-03-22 14:46:40'),(374,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-03-24 22:41:37','2023-03-24 22:41:37'),(375,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-03-28 11:45:40','2023-03-28 11:45:40'),(376,'default','login',8,'App\\User',5,8,'App\\User','[]','2023-03-28 11:52:00','2023-03-28 11:52:00'),(377,'default','login',8,'App\\User',5,8,'App\\User','[]','2023-03-28 11:55:37','2023-03-28 11:55:37'),(378,'default','added',103,'App\\Transaction',5,8,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":14}}','2023-03-28 12:36:19','2023-03-28 12:36:19'),(379,'default','added',104,'App\\Transaction',5,8,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":15}}','2023-03-28 12:40:19','2023-03-28 12:40:19'),(380,'default','login',15,'App\\User',10,15,'App\\User','[]','2023-03-28 22:45:30','2023-03-28 22:45:30'),(381,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-03-28 22:48:03','2023-03-28 22:48:03'),(382,'default','sell_deleted',100,'App\\Transaction',10,15,'App\\User','{\"id\":100,\"invoice_no\":\"FAC-2023-0008\",\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"100.0000\"}}','2023-03-28 22:50:57','2023-03-28 22:50:57'),(383,'default','sell_deleted',99,'App\\Transaction',10,15,'App\\User','{\"id\":99,\"invoice_no\":\"REC-2023-0006\",\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"120.0000\"}}','2023-03-28 22:51:03','2023-03-28 22:51:03'),(384,'default','sell_deleted',98,'App\\Transaction',10,15,'App\\User','{\"id\":98,\"invoice_no\":\"REC-2023-0005\",\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"120.0000\"}}','2023-03-28 22:51:08','2023-03-28 22:51:08'),(385,'default','sell_deleted',97,'App\\Transaction',10,15,'App\\User','{\"id\":97,\"invoice_no\":\"fac2023-0007\",\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"120.0000\"}}','2023-03-28 22:51:12','2023-03-28 22:51:12'),(386,'default','sell_deleted',96,'App\\Transaction',10,15,'App\\User','{\"id\":96,\"invoice_no\":\"rec2023-0003\",\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"120.0000\"}}','2023-03-28 22:51:17','2023-03-28 22:51:17'),(387,'default','sell_deleted',95,'App\\Transaction',10,15,'App\\User','{\"id\":95,\"invoice_no\":\"0006\",\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"120.0000\"}}','2023-03-28 22:51:22','2023-03-28 22:51:22'),(388,'default','sell_deleted',94,'App\\Transaction',10,15,'App\\User','{\"id\":94,\"invoice_no\":\"0002\",\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"195.0000\"}}','2023-03-28 22:51:27','2023-03-28 22:51:27'),(389,'default','sell_deleted',93,'App\\Transaction',10,15,'App\\User','{\"id\":93,\"invoice_no\":\"0001\",\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"150.0000\"}}','2023-03-28 22:51:33','2023-03-28 22:51:33'),(390,'default','sell_deleted',92,'App\\Transaction',10,15,'App\\User','{\"id\":92,\"invoice_no\":\"0000\",\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"45.0000\"}}','2023-03-28 22:51:39','2023-03-28 22:51:39'),(391,'default','sell_deleted',90,'App\\Transaction',10,15,'App\\User','{\"id\":90,\"invoice_no\":\"0004\",\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"75.0000\"}}','2023-03-28 22:51:49','2023-03-28 22:51:49'),(392,'default','sell_deleted',91,'App\\Transaction',10,15,'App\\User','{\"id\":91,\"invoice_no\":\"0005\",\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"75.0000\"}}','2023-03-28 22:52:20','2023-03-28 22:52:20'),(393,'default','sell_deleted',89,'App\\Transaction',10,15,'App\\User','{\"id\":89,\"invoice_no\":\"0003\",\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"120.0000\"}}','2023-03-28 22:52:27','2023-03-28 22:52:27'),(394,'default','sell_deleted',88,'App\\Transaction',10,15,'App\\User','{\"id\":88,\"invoice_no\":\"0002\",\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"120.0000\"}}','2023-03-28 22:52:49','2023-03-28 22:52:49'),(395,'default','sell_deleted',87,'App\\Transaction',10,15,'App\\User','{\"id\":87,\"invoice_no\":\"0001\",\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"120.0000\"}}','2023-03-28 22:52:53','2023-03-28 22:52:53'),(396,'default','contact_deleted',86,'App\\Contact',10,15,'App\\User','[]','2023-03-28 23:28:56','2023-03-28 23:28:56'),(397,'default','edited',84,'App\\Contact',10,15,'App\\User','[]','2023-03-28 23:29:36','2023-03-28 23:29:36'),(398,'default','logout',15,'App\\User',10,15,'App\\User','[]','2023-03-28 23:44:27','2023-03-28 23:44:27'),(399,'default','login',8,'App\\User',5,8,'App\\User','[]','2023-03-28 23:45:11','2023-03-28 23:45:11'),(400,'default','edited',72,'App\\Contact',5,8,'App\\User','[]','2023-03-28 23:52:49','2023-03-28 23:52:49'),(401,'default','added',112,'App\\Transaction',5,8,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"due\",\"final_total\":14}}','2023-03-28 23:58:44','2023-03-28 23:58:44'),(402,'default','login',8,'App\\User',5,8,'App\\User','[]','2023-03-29 10:06:49','2023-03-29 10:06:49'),(403,'default','logout',8,'App\\User',5,8,'App\\User','[]','2023-03-29 10:13:44','2023-03-29 10:13:44'),(404,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-03-29 10:13:59','2023-03-29 10:13:59'),(405,'default','login',6,'App\\User',4,6,'App\\User','[]','2023-03-29 10:15:38','2023-03-29 10:15:38'),(406,'default','login',8,'App\\User',5,8,'App\\User','[]','2023-03-29 10:31:18','2023-03-29 10:31:18'),(407,'default','logout',6,'App\\User',4,6,'App\\User','[]','2023-03-29 10:41:00','2023-03-29 10:41:00'),(408,'default','login',8,'App\\User',5,8,'App\\User','[]','2023-03-29 10:41:12','2023-03-29 10:41:12'),(409,'default','added',113,'App\\Transaction',5,8,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"due\",\"final_total\":51.3}}','2023-03-29 10:49:46','2023-03-29 10:49:46'),(410,'default','added',114,'App\\Transaction',5,8,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"due\",\"final_total\":2.7}}','2023-03-29 10:49:46','2023-03-29 10:49:46'),(411,'default','payment_edited',113,'App\\Transaction',5,8,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"partial\",\"final_total\":\"51.3000\"},\"old\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"due\",\"final_total\":\"51.3000\"}}','2023-03-29 10:54:35','2023-03-29 10:54:35'),(412,'default','added',88,'App\\Contact',5,8,'App\\User','[]','2023-03-29 11:07:03','2023-03-29 11:07:03'),(413,'default','added',89,'App\\Contact',5,8,'App\\User','[]','2023-03-29 11:07:26','2023-03-29 11:07:26'),(414,'default','added',90,'App\\Contact',5,8,'App\\User','[]','2023-03-29 11:08:16','2023-03-29 11:08:16'),(415,'default','added',115,'App\\Transaction',5,8,'App\\User','{\"attributes\":{\"type\":\"purchase\",\"status\":\"received\",\"payment_status\":\"due\",\"final_total\":52}}','2023-03-29 11:09:32','2023-03-29 11:09:32'),(416,'default','logout',8,'App\\User',5,8,'App\\User','[]','2023-03-29 11:27:15','2023-03-29 11:27:15'),(417,'default','login',6,'App\\User',4,6,'App\\User','[]','2023-03-29 11:27:22','2023-03-29 11:27:22'),(418,'default','logout',1,'App\\User',1,1,'App\\User','[]','2023-03-29 11:37:36','2023-03-29 11:37:36'),(419,'default','login',6,'App\\User',4,6,'App\\User','[]','2023-03-29 11:37:44','2023-03-29 11:37:44'),(420,'default','edited',6,'App\\Contact',4,6,'App\\User','[]','2023-03-29 11:41:32','2023-03-29 11:41:32'),(421,'default','added',117,'App\\Transaction',4,6,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":32}}','2023-03-29 11:48:42','2023-03-29 11:48:42'),(422,'default','login',6,'App\\User',4,6,'App\\User','[]','2023-03-29 11:58:52','2023-03-29 11:58:52'),(423,'default','logout',6,'App\\User',4,6,'App\\User','[]','2023-03-29 12:02:42','2023-03-29 12:02:42'),(424,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-03-29 12:02:51','2023-03-29 12:02:51'),(425,'default','logout',1,'App\\User',1,1,'App\\User','[]','2023-03-29 13:27:40','2023-03-29 13:27:40'),(426,'default','login',6,'App\\User',4,6,'App\\User','[]','2023-03-29 13:27:48','2023-03-29 13:27:48'),(427,'default','login',8,'App\\User',5,8,'App\\User','[]','2023-03-29 13:38:37','2023-03-29 13:38:37'),(428,'default','added',91,'App\\Contact',4,6,'App\\User','[]','2023-03-29 13:42:38','2023-03-29 13:42:38'),(429,'default','added',118,'App\\Transaction',4,6,'App\\User','{\"attributes\":{\"type\":\"purchase\",\"status\":\"received\",\"payment_status\":\"due\",\"final_total\":50}}','2023-03-29 13:45:36','2023-03-29 13:45:36'),(430,'default','sell_deleted',117,'App\\Transaction',4,6,'App\\User','{\"id\":117,\"invoice_no\":\"0001\",\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"32.0000\"}}','2023-03-29 13:51:53','2023-03-29 13:51:53'),(431,'default','purchase_deleted',118,'App\\Transaction',4,6,'App\\User','{\"attributes\":{\"type\":\"purchase\",\"status\":\"received\",\"payment_status\":\"paid\",\"final_total\":\"50.0000\"}}','2023-03-29 13:52:35','2023-03-29 13:52:35'),(432,'default','added',121,'App\\Transaction',4,6,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":14}}','2023-03-29 14:11:27','2023-03-29 14:11:27'),(433,'default','login',6,'App\\User',4,6,'App\\User','[]','2023-03-29 16:12:41','2023-03-29 16:12:41'),(434,'default','login',15,'App\\User',10,15,'App\\User','[]','2023-03-30 00:53:21','2023-03-30 00:53:21'),(435,'default','login',1,'App\\User',1,1,'App\\User','[]','2023-03-30 01:14:45','2023-03-30 01:14:45');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `barcodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `barcodes` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `width` double(22,4) DEFAULT NULL,
  `height` double(22,4) DEFAULT NULL,
  `paper_width` double(22,4) DEFAULT NULL,
  `paper_height` double(22,4) DEFAULT NULL,
  `top_margin` double(22,4) DEFAULT NULL,
  `left_margin` double(22,4) DEFAULT NULL,
  `row_distance` double(22,4) DEFAULT NULL,
  `col_distance` double(22,4) DEFAULT NULL,
  `stickers_in_one_row` int DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_continuous` tinyint(1) NOT NULL DEFAULT '0',
  `stickers_in_one_sheet` int DEFAULT NULL,
  `business_id` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `barcodes_business_id_foreign` (`business_id`),
  CONSTRAINT `barcodes_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `barcodes` WRITE;
/*!40000 ALTER TABLE `barcodes` DISABLE KEYS */;
INSERT INTO `barcodes` VALUES (1,'20 Labels per Sheet','Sheet Size: 8.5\" x 11\", Label Size: 4\" x 1\", Labels per sheet: 20',4.0000,1.0000,8.5000,11.0000,0.5000,0.1250,0.0000,0.1875,2,0,0,20,NULL,'2017-12-18 06:13:44','2017-12-18 06:13:44'),(2,'30 Labels per sheet','Sheet Size: 8.5\" x 11\", Label Size: 2.625\" x 1\", Labels per sheet: 30',2.6250,1.0000,8.5000,11.0000,0.5000,0.1880,0.0000,0.1250,3,0,0,30,NULL,'2017-12-18 06:04:39','2017-12-18 06:10:40'),(3,'32 Labels per sheet','Sheet Size: 8.5\" x 11\", Label Size: 2\" x 1.25\", Labels per sheet: 32',2.0000,1.2500,8.5000,11.0000,0.5000,0.2500,0.0000,0.0000,4,0,0,32,NULL,'2017-12-18 05:55:40','2017-12-18 05:55:40'),(4,'40 Labels per sheet','Sheet Size: 8.5\" x 11\", Label Size: 2\" x 1\", Labels per sheet: 40',2.0000,1.0000,8.5000,11.0000,0.5000,0.2500,0.0000,0.0000,4,0,0,40,NULL,'2017-12-18 05:58:40','2017-12-18 05:58:40'),(5,'50 Labels per Sheet','Sheet Size: 8.5\" x 11\", Label Size: 1.5\" x 1\", Labels per sheet: 50',1.5000,1.0000,8.5000,11.0000,0.5000,0.5000,0.0000,0.0000,5,0,0,50,NULL,'2017-12-18 05:51:10','2017-12-18 05:51:10'),(6,'Continuous Rolls - 31.75mm x 25.4mm','Label Size: 31.75mm x 25.4mm, Gap: 3.18mm',1.2500,1.0000,1.2500,0.0000,0.1250,0.0000,0.1250,0.0000,1,0,1,NULL,NULL,'2017-12-18 05:51:10','2017-12-18 05:51:10');
/*!40000 ALTER TABLE `barcodes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookings` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `contact_id` int unsigned NOT NULL,
  `waiter_id` int unsigned DEFAULT NULL,
  `table_id` int unsigned DEFAULT NULL,
  `correspondent_id` int DEFAULT NULL,
  `business_id` int unsigned NOT NULL,
  `location_id` int unsigned NOT NULL,
  `booking_start` datetime NOT NULL,
  `booking_end` datetime NOT NULL,
  `created_by` int unsigned NOT NULL,
  `booking_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `booking_note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bookings_contact_id_foreign` (`contact_id`),
  KEY `bookings_business_id_foreign` (`business_id`),
  KEY `bookings_created_by_foreign` (`created_by`),
  KEY `bookings_table_id_index` (`table_id`),
  KEY `bookings_waiter_id_index` (`waiter_id`),
  KEY `bookings_location_id_index` (`location_id`),
  KEY `bookings_booking_status_index` (`booking_status`),
  KEY `bookings_correspondent_id_index` (`correspondent_id`),
  CONSTRAINT `bookings_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookings_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookings_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `brands` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_by` int unsigned NOT NULL,
  `use_for_repair` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'brands to be used on repair module',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `brands_business_id_foreign` (`business_id`),
  KEY `brands_created_by_foreign` (`created_by`),
  CONSTRAINT `brands_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `brands_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` VALUES (1,3,'Xiaomi',NULL,3,0,NULL,'2023-01-26 19:33:47','2023-01-26 19:33:47'),(2,4,'COFAR',NULL,6,0,NULL,'2023-01-26 20:49:46','2023-03-29 10:31:54'),(3,1,'gosystem',NULL,1,0,NULL,'2023-01-28 11:48:20','2023-01-28 11:48:20'),(4,2,'Coca Cola',NULL,2,0,NULL,'2023-01-28 11:55:36','2023-01-28 11:55:36'),(5,5,'Laboratorio 1',NULL,8,0,NULL,'2023-02-13 19:02:36','2023-02-13 19:02:36'),(6,4,'BAGO',NULL,6,0,NULL,'2023-03-29 10:24:44','2023-03-29 10:30:40'),(7,4,'IFA - PRODEXA',NULL,6,0,NULL,'2023-03-29 10:25:49','2023-03-29 10:31:09'),(8,4,'INTI',NULL,6,0,NULL,'2023-03-29 10:32:20','2023-03-29 10:32:20'),(9,4,'ABBOTT',NULL,6,0,NULL,'2023-03-29 10:33:09','2023-03-29 10:33:09'),(10,4,'SAVAL',NULL,6,0,NULL,'2023-03-29 10:33:41','2023-03-29 10:33:41'),(11,4,'SMITH PHARMA',NULL,6,0,NULL,'2023-03-29 10:34:15','2023-03-29 10:34:15'),(12,4,'IFARBO','MEDIPHARMA',6,0,NULL,'2023-03-29 10:35:06','2023-03-29 10:35:57'),(13,4,'UNIVERSAL PHARMA','MEDIPHARMA-NATALY-HOSPITALIA',6,0,NULL,'2023-03-29 10:37:23','2023-03-29 10:37:23'),(14,4,'DISMEDIN','MEDIPHARMA-NATALY-HOSPITALIA-NEMAC',6,0,NULL,'2023-03-29 10:37:53','2023-03-29 10:46:52'),(15,4,'FARMEDICAL',NULL,6,0,NULL,'2023-03-29 10:38:09','2023-03-29 10:38:09'),(16,4,'ALFA',NULL,6,0,NULL,'2023-03-29 10:38:25','2023-03-29 10:38:25'),(17,4,'SAN FERNANDO','REDIMED',6,0,NULL,'2023-03-29 10:38:42','2023-03-29 10:39:16'),(18,4,'LAFAR',NULL,6,0,NULL,'2023-03-29 10:39:34','2023-03-29 10:39:34'),(19,4,'SAE-CHILE',NULL,6,0,NULL,'2023-03-29 10:39:55','2023-03-29 10:39:55'),(20,4,'ALMAGRAN',NULL,6,0,NULL,'2023-03-29 10:40:16','2023-03-29 10:40:16'),(21,4,'TECNOFARMA','SERGON',6,0,NULL,'2023-03-29 10:40:49','2023-03-29 10:40:49'),(22,4,'UNICURE','MEDIPHARMA-NATALY-HOSPITALIA',6,0,NULL,'2023-03-29 10:41:10','2023-03-29 10:41:10'),(23,4,'TERBOL',NULL,6,0,NULL,'2023-03-29 10:41:29','2023-03-29 10:41:29'),(24,4,'MEGALABS','TERBOL',6,0,NULL,'2023-03-29 10:41:48','2023-03-29 10:41:48'),(25,4,'DELTA',NULL,6,0,NULL,'2023-03-29 10:42:03','2023-03-29 10:42:03'),(26,4,'SANAT','MEDIPHARMA',6,0,NULL,'2023-03-29 10:42:31','2023-03-29 10:42:31'),(27,4,'INFAR',NULL,6,0,NULL,'2023-03-29 10:42:43','2023-03-29 10:42:43'),(28,4,'LA SANTE','RAICES',6,0,NULL,'2023-03-29 10:43:13','2023-03-29 10:43:13'),(29,4,'MINTLAB','RAICES',6,0,NULL,'2023-03-29 10:44:03','2023-03-29 10:44:03'),(30,4,'VITA',NULL,6,0,NULL,'2023-03-29 10:44:15','2023-03-29 10:44:15'),(31,4,'ALCOS',NULL,6,0,NULL,'2023-03-29 10:44:35','2023-03-29 10:44:35'),(32,4,'BABYS',NULL,6,0,NULL,'2023-03-29 10:46:34','2023-03-29 10:46:34'),(33,4,'PORTUGAL','NATALY-NEMAC',6,0,NULL,'2023-03-29 10:47:20','2023-03-29 10:47:20'),(34,4,'HAHMEMANN',NULL,6,0,NULL,'2023-03-29 10:49:31','2023-03-29 10:49:31'),(35,4,'ARGEBOL',NULL,6,0,NULL,'2023-03-29 10:50:15','2023-03-29 10:50:15'),(36,4,'VALENCIA',NULL,6,0,NULL,'2023-03-29 10:51:32','2023-03-29 10:51:32'),(37,4,'PRODUCTOS BRAZILEROS',NULL,6,0,NULL,'2023-03-29 10:52:03','2023-03-29 10:52:03');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `business`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `business` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency_id` int unsigned NOT NULL,
  `start_date` date DEFAULT NULL,
  `tax_number_1` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_label_1` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_number_2` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_label_2` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code_label_1` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code_1` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code_label_2` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code_2` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_sales_tax` int unsigned DEFAULT NULL,
  `default_profit_percent` double(5,2) NOT NULL DEFAULT '0.00',
  `owner_id` int unsigned NOT NULL,
  `time_zone` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Asia/Kolkata',
  `fy_start_month` tinyint NOT NULL DEFAULT '1',
  `accounting_method` enum('fifo','lifo','avco') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fifo',
  `default_sales_discount` decimal(5,2) DEFAULT NULL,
  `sell_price_tax` enum('includes','excludes') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'includes',
  `logo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sku_prefix` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enable_product_expiry` tinyint(1) NOT NULL DEFAULT '0',
  `expiry_type` enum('add_expiry','add_manufacturing') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'add_expiry',
  `on_product_expiry` enum('keep_selling','stop_selling','auto_delete') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'keep_selling',
  `stop_selling_before` int NOT NULL COMMENT 'Stop selling expied item n days before expiry',
  `enable_tooltip` tinyint(1) NOT NULL DEFAULT '1',
  `purchase_in_diff_currency` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Allow purchase to be in different currency then the business currency',
  `purchase_currency_id` int unsigned DEFAULT NULL,
  `p_exchange_rate` decimal(20,3) NOT NULL DEFAULT '1.000',
  `transaction_edit_days` int unsigned NOT NULL DEFAULT '30',
  `stock_expiry_alert_days` int unsigned NOT NULL DEFAULT '30',
  `keyboard_shortcuts` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `pos_settings` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `essentials_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `manufacturing_settings` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `woocommerce_api_settings` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `woocommerce_skipped_orders` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `woocommerce_wh_oc_secret` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `woocommerce_wh_ou_secret` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `woocommerce_wh_od_secret` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `woocommerce_wh_or_secret` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weighing_scale_setting` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'used to store the configuration of weighing scale',
  `enable_brand` tinyint(1) NOT NULL DEFAULT '1',
  `enable_category` tinyint(1) NOT NULL DEFAULT '1',
  `enable_sub_category` tinyint(1) NOT NULL DEFAULT '1',
  `enable_price_tax` tinyint(1) NOT NULL DEFAULT '1',
  `enable_purchase_status` tinyint(1) DEFAULT '1',
  `enable_lot_number` tinyint(1) NOT NULL DEFAULT '0',
  `default_unit` int DEFAULT NULL,
  `enable_sub_units` tinyint(1) NOT NULL DEFAULT '0',
  `enable_racks` tinyint(1) NOT NULL DEFAULT '0',
  `enable_row` tinyint(1) NOT NULL DEFAULT '0',
  `enable_position` tinyint(1) NOT NULL DEFAULT '0',
  `enable_editing_product_from_purchase` tinyint(1) NOT NULL DEFAULT '1',
  `sales_cmsn_agnt` enum('logged_in_user','user','cmsn_agnt') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_addition_method` tinyint(1) NOT NULL DEFAULT '1',
  `enable_inline_tax` tinyint(1) NOT NULL DEFAULT '1',
  `currency_symbol_placement` enum('before','after') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'before',
  `enabled_modules` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `date_format` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'm/d/Y',
  `time_format` enum('12','24') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '24',
  `ref_no_prefixes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `theme_color` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `crm_settings` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `repair_settings` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `enable_rp` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'rp is the short form of reward points',
  `rp_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'rp is the short form of reward points',
  `amount_for_unit_rp` decimal(22,4) NOT NULL DEFAULT '1.0000' COMMENT 'rp is the short form of reward points',
  `min_order_total_for_rp` decimal(22,4) NOT NULL DEFAULT '1.0000' COMMENT 'rp is the short form of reward points',
  `max_rp_per_order` int DEFAULT NULL COMMENT 'rp is the short form of reward points',
  `redeem_amount_per_unit_rp` decimal(22,4) NOT NULL DEFAULT '1.0000' COMMENT 'rp is the short form of reward points',
  `min_order_total_for_redeem` decimal(22,4) NOT NULL DEFAULT '1.0000' COMMENT 'rp is the short form of reward points',
  `min_redeem_point` int DEFAULT NULL COMMENT 'rp is the short form of reward points',
  `max_redeem_point` int DEFAULT NULL COMMENT 'rp is the short form of reward points',
  `rp_expiry_period` int DEFAULT NULL COMMENT 'rp is the short form of reward points',
  `rp_expiry_type` enum('month','year') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'year' COMMENT 'rp is the short form of reward points',
  `email_settings` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `sms_settings` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `custom_labels` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `common_settings` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `business_owner_id_foreign` (`owner_id`),
  KEY `business_currency_id_foreign` (`currency_id`),
  KEY `business_default_sales_tax_foreign` (`default_sales_tax`),
  CONSTRAINT `business_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`),
  CONSTRAINT `business_default_sales_tax_foreign` FOREIGN KEY (`default_sales_tax`) REFERENCES `tax_rates` (`id`),
  CONSTRAINT `business_owner_id_foreign` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `business` WRITE;
/*!40000 ALTER TABLE `business` DISABLE KEYS */;
INSERT INTO `business` VALUES (1,'gosystem',14,'2023-01-26',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,25.00,1,'America/La_Paz',1,'fifo',0.00,'includes','1674763625_androidtv2.PNG',NULL,1,'add_expiry','keep_selling',0,1,0,NULL,1.000,30,30,'{\"pos\":{\"express_checkout\":\"shift+e\",\"pay_n_ckeckout\":\"shift+p\",\"draft\":\"shift+d\",\"cancel\":\"shift+c\",\"recent_product_quantity\":\"f2\",\"weighing_scale\":null,\"edit_discount\":\"shift+i\",\"edit_order_tax\":\"shift+t\",\"add_payment_row\":\"shift+r\",\"finalize_payment\":\"shift+f\",\"add_new_product\":\"f4\"}}','{\"cmmsn_calculation_type\":\"invoice_value\",\"amount_rounding_method\":null,\"razor_pay_key_id\":null,\"razor_pay_key_secret\":null,\"stripe_public_key\":null,\"stripe_secret_key\":null,\"disable_draft\":\"1\",\"disable_express_checkout\":\"1\",\"disable_order_tax\":\"1\",\"disable_suspend\":\"1\",\"enable_transaction_date\":\"1\",\"cash_denominations\":\"1,2,5,10,20,50,100,200\",\"disable_pay_checkout\":0,\"hide_product_suggestion\":0,\"hide_recent_trans\":0,\"disable_discount\":0,\"is_pos_subtotal_editable\":0}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"label_prefix\":null,\"product_sku_length\":\"4\",\"qty_length\":\"3\",\"qty_length_decimal\":\"2\"}',1,1,0,1,1,0,1,0,0,0,0,1,NULL,1,0,'before','[\"purchases\",\"add_sale\",\"pos_sale\",\"stock_transfers\",\"stock_adjustment\",\"expenses\",\"account\",\"tables\",\"modifiers\",\"service_staff\",\"booking\",\"kitchen\",\"subscription\",\"types_of_service\"]','m/d/Y','24','{\"purchase\":\"PO\",\"purchase_return\":null,\"purchase_order\":null,\"stock_transfer\":\"ST\",\"stock_adjustment\":\"SA\",\"sell_return\":\"CN\",\"expense\":\"EP\",\"contacts\":\"CO\",\"purchase_payment\":\"PP\",\"sell_payment\":\"SP\",\"expense_payment\":null,\"business_location\":\"BL\",\"username\":null,\"subscription\":null,\"draft\":null,\"sales_order\":null}','black',NULL,NULL,NULL,0,NULL,1.0000,1.0000,NULL,1.0000,1.0000,NULL,NULL,NULL,'year','{\"mail_driver\":\"smtp\",\"mail_host\":null,\"mail_port\":null,\"mail_username\":null,\"mail_password\":null,\"mail_encryption\":null,\"mail_from_address\":null,\"mail_from_name\":null}','{\"sms_service\":\"other\",\"nexmo_key\":null,\"nexmo_secret\":null,\"nexmo_from\":null,\"twilio_sid\":null,\"twilio_token\":null,\"twilio_from\":null,\"url\":null,\"send_to_param_name\":\"to\",\"msg_param_name\":\"text\",\"request_method\":\"post\",\"header_1\":null,\"header_val_1\":null,\"header_2\":null,\"header_val_2\":null,\"header_3\":null,\"header_val_3\":null,\"param_1\":null,\"param_val_1\":null,\"param_2\":null,\"param_val_2\":null,\"param_3\":null,\"param_val_3\":null,\"param_4\":null,\"param_val_4\":null,\"param_5\":null,\"param_val_5\":null,\"param_6\":null,\"param_val_6\":null,\"param_7\":null,\"param_val_7\":null,\"param_8\":null,\"param_val_8\":null,\"param_9\":null,\"param_val_9\":null,\"param_10\":null,\"param_val_10\":null}','{\"payments\":{\"custom_pay_1\":null,\"custom_pay_2\":null,\"custom_pay_3\":null,\"custom_pay_4\":null,\"custom_pay_5\":null,\"custom_pay_6\":null,\"custom_pay_7\":null},\"contact\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null,\"custom_field_7\":null,\"custom_field_8\":null,\"custom_field_9\":null,\"custom_field_10\":null},\"product\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"location\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"user\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase_shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"sell\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"types_of_service\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null}}','{\"default_credit_limit\":null,\"default_datatable_page_entries\":\"25\"}',1,'2023-01-26 15:59:33','2023-03-29 10:21:51'),(2,'Skot Burger',14,'2023-01-26',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,25.00,2,'America/La_Paz',1,'fifo',0.00,'includes','1674765845_skotlogo.jpg',NULL,0,'add_expiry','keep_selling',0,1,0,NULL,1.000,30,7,'{\"pos\":{\"express_checkout\":\"shift+e\",\"pay_n_ckeckout\":\"shift+p\",\"draft\":\"shift+d\",\"cancel\":\"shift+c\",\"recent_product_quantity\":\"f2\",\"weighing_scale\":null,\"edit_discount\":\"shift+i\",\"edit_order_tax\":\"shift+t\",\"add_payment_row\":\"shift+r\",\"finalize_payment\":\"shift+f\",\"add_new_product\":\"f4\"}}','{\"cmmsn_calculation_type\":\"invoice_value\",\"amount_rounding_method\":null,\"razor_pay_key_id\":null,\"razor_pay_key_secret\":null,\"stripe_public_key\":null,\"stripe_secret_key\":null,\"disable_pay_checkout\":\"1\",\"disable_draft\":\"1\",\"disable_order_tax\":\"1\",\"disable_suspend\":\"1\",\"enable_transaction_date\":\"1\",\"cash_denominations\":\"1,2,5,10,20,50,100,500\",\"disable_express_checkout\":0,\"hide_product_suggestion\":0,\"hide_recent_trans\":0,\"disable_discount\":0,\"is_pos_subtotal_editable\":0}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"label_prefix\":null,\"product_sku_length\":\"4\",\"qty_length\":\"3\",\"qty_length_decimal\":\"2\"}',0,1,0,1,1,0,2,0,0,0,0,1,NULL,1,0,'before','[\"purchases\",\"pos_sale\",\"stock_transfers\",\"expenses\",\"tables\",\"kitchen\"]','m/d/Y','24','{\"purchase\":\"PO\",\"purchase_return\":null,\"purchase_order\":null,\"stock_transfer\":\"ST\",\"stock_adjustment\":\"SA\",\"sell_return\":\"CN\",\"expense\":\"EP\",\"contacts\":\"CO\",\"purchase_payment\":\"PP\",\"sell_payment\":\"SP\",\"expense_payment\":null,\"business_location\":\"BL\",\"username\":null,\"subscription\":null,\"draft\":null,\"sales_order\":null}','black',NULL,NULL,NULL,0,NULL,1.0000,1.0000,NULL,1.0000,1.0000,NULL,NULL,NULL,'year','{\"mail_driver\":\"smtp\",\"mail_host\":null,\"mail_port\":null,\"mail_username\":null,\"mail_password\":null,\"mail_encryption\":null,\"mail_from_address\":null,\"mail_from_name\":null}','{\"sms_service\":\"other\",\"nexmo_key\":null,\"nexmo_secret\":null,\"nexmo_from\":null,\"twilio_sid\":null,\"twilio_token\":null,\"twilio_from\":null,\"url\":null,\"send_to_param_name\":\"to\",\"msg_param_name\":\"text\",\"request_method\":\"post\",\"header_1\":null,\"header_val_1\":null,\"header_2\":null,\"header_val_2\":null,\"header_3\":null,\"header_val_3\":null,\"param_1\":null,\"param_val_1\":null,\"param_2\":null,\"param_val_2\":null,\"param_3\":null,\"param_val_3\":null,\"param_4\":null,\"param_val_4\":null,\"param_5\":null,\"param_val_5\":null,\"param_6\":null,\"param_val_6\":null,\"param_7\":null,\"param_val_7\":null,\"param_8\":null,\"param_val_8\":null,\"param_9\":null,\"param_val_9\":null,\"param_10\":null,\"param_val_10\":null}','{\"payments\":{\"custom_pay_1\":null,\"custom_pay_2\":null,\"custom_pay_3\":null,\"custom_pay_4\":null,\"custom_pay_5\":null,\"custom_pay_6\":null,\"custom_pay_7\":null},\"contact\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null,\"custom_field_7\":null,\"custom_field_8\":null,\"custom_field_9\":null,\"custom_field_10\":null},\"product\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"location\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"user\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase_shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"sell\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"types_of_service\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null}}','{\"default_credit_limit\":null,\"default_datatable_page_entries\":\"25\"}',1,'2023-01-26 16:42:31','2023-02-17 18:09:24'),(3,'ShopTec',14,'2023-01-26',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,25.00,3,'America/La_Paz',1,'fifo',0.00,'includes',NULL,NULL,0,'add_expiry','keep_selling',0,1,0,NULL,1.000,30,30,'{\"pos\":{\"express_checkout\":\"shift+e\",\"pay_n_ckeckout\":\"shift+p\",\"draft\":\"shift+d\",\"cancel\":\"shift+c\",\"recent_product_quantity\":\"f2\",\"weighing_scale\":null,\"edit_discount\":\"shift+i\",\"edit_order_tax\":\"shift+t\",\"add_payment_row\":\"shift+r\",\"finalize_payment\":\"shift+f\",\"add_new_product\":\"f4\"}}','{\"cmmsn_calculation_type\":\"invoice_value\",\"amount_rounding_method\":null,\"razor_pay_key_id\":null,\"razor_pay_key_secret\":null,\"stripe_public_key\":null,\"stripe_secret_key\":null,\"cash_denominations\":null,\"disable_pay_checkout\":0,\"disable_draft\":0,\"disable_express_checkout\":0,\"hide_product_suggestion\":0,\"hide_recent_trans\":0,\"disable_discount\":0,\"disable_order_tax\":0,\"is_pos_subtotal_editable\":0}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"label_prefix\":null,\"product_sku_length\":\"4\",\"qty_length\":\"3\",\"qty_length_decimal\":\"2\"}',1,1,0,1,1,0,3,0,0,0,0,1,NULL,1,0,'before','[\"purchases\",\"add_sale\",\"pos_sale\",\"stock_transfers\",\"stock_adjustment\",\"expenses\",\"subscription\"]','d-m-Y','24','{\"purchase\":\"PO\",\"purchase_return\":null,\"purchase_order\":null,\"stock_transfer\":\"ST\",\"stock_adjustment\":\"SA\",\"sell_return\":\"CN\",\"expense\":\"EP\",\"contacts\":\"CO\",\"purchase_payment\":\"PP\",\"sell_payment\":\"SP\",\"expense_payment\":null,\"business_location\":\"BL\",\"username\":null,\"subscription\":null,\"draft\":null,\"sales_order\":null}','black',NULL,NULL,NULL,0,NULL,1.0000,1.0000,NULL,1.0000,1.0000,NULL,NULL,NULL,'year','{\"mail_driver\":\"smtp\",\"mail_host\":null,\"mail_port\":null,\"mail_username\":null,\"mail_password\":null,\"mail_encryption\":null,\"mail_from_address\":null,\"mail_from_name\":null}','{\"sms_service\":\"other\",\"nexmo_key\":null,\"nexmo_secret\":null,\"nexmo_from\":null,\"twilio_sid\":null,\"twilio_token\":null,\"twilio_from\":null,\"url\":null,\"send_to_param_name\":\"to\",\"msg_param_name\":\"text\",\"request_method\":\"post\",\"header_1\":null,\"header_val_1\":null,\"header_2\":null,\"header_val_2\":null,\"header_3\":null,\"header_val_3\":null,\"param_1\":null,\"param_val_1\":null,\"param_2\":null,\"param_val_2\":null,\"param_3\":null,\"param_val_3\":null,\"param_4\":null,\"param_val_4\":null,\"param_5\":null,\"param_val_5\":null,\"param_6\":null,\"param_val_6\":null,\"param_7\":null,\"param_val_7\":null,\"param_8\":null,\"param_val_8\":null,\"param_9\":null,\"param_val_9\":null,\"param_10\":null,\"param_val_10\":null}','{\"payments\":{\"custom_pay_1\":\"Tigo Money\",\"custom_pay_2\":\"Soli\",\"custom_pay_3\":null,\"custom_pay_4\":null,\"custom_pay_5\":null,\"custom_pay_6\":null,\"custom_pay_7\":null},\"contact\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null,\"custom_field_7\":null,\"custom_field_8\":null,\"custom_field_9\":null,\"custom_field_10\":null},\"product\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"location\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"user\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase_shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"sell\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"types_of_service\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null}}','{\"default_credit_limit\":null,\"default_datatable_page_entries\":\"25\"}',1,'2023-01-26 19:20:15','2023-01-31 18:47:52'),(4,'Farmacia Ayleen',14,'2023-01-26',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,25.00,6,'America/La_Paz',1,'fifo',0.00,'includes',NULL,NULL,1,'add_expiry','keep_selling',0,1,0,NULL,1.000,30,30,'{\"pos\":{\"express_checkout\":\"shift+e\",\"pay_n_ckeckout\":\"shift+p\",\"draft\":\"shift+d\",\"cancel\":\"shift+c\",\"recent_product_quantity\":\"f2\",\"weighing_scale\":null,\"edit_discount\":\"shift+i\",\"edit_order_tax\":\"shift+t\",\"add_payment_row\":\"shift+r\",\"finalize_payment\":\"shift+f\",\"add_new_product\":\"f4\"}}','{\"cmmsn_calculation_type\":\"invoice_value\",\"amount_rounding_method\":null,\"razor_pay_key_id\":null,\"razor_pay_key_secret\":null,\"stripe_public_key\":null,\"stripe_secret_key\":null,\"disable_draft\":\"1\",\"disable_express_checkout\":\"1\",\"disable_order_tax\":\"1\",\"disable_suspend\":\"1\",\"enable_transaction_date\":\"1\",\"show_invoice_scheme\":\"1\",\"show_invoice_layout\":\"1\",\"show_pricing_on_product_sugesstion\":\"1\",\"cash_denominations\":\"1,2,5,10,20,50,100,200\",\"disable_pay_checkout\":0,\"hide_product_suggestion\":0,\"hide_recent_trans\":0,\"disable_discount\":0,\"is_pos_subtotal_editable\":0}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"label_prefix\":null,\"product_sku_length\":\"4\",\"qty_length\":\"3\",\"qty_length_decimal\":\"2\"}',1,1,0,0,0,0,4,0,0,0,0,1,NULL,1,0,'before','[\"purchases\",\"add_sale\",\"pos_sale\",\"stock_transfers\",\"stock_adjustment\",\"expenses\"]','m/d/Y','24','{\"purchase\":\"PO\",\"purchase_return\":null,\"purchase_order\":null,\"stock_transfer\":\"ST\",\"stock_adjustment\":\"SA\",\"sell_return\":\"CN\",\"expense\":\"EP\",\"contacts\":\"CO\",\"purchase_payment\":\"PP\",\"sell_payment\":\"SP\",\"expense_payment\":null,\"business_location\":\"BL\",\"username\":null,\"subscription\":null,\"draft\":null,\"sales_order\":null}','black',NULL,NULL,NULL,0,NULL,1.0000,1.0000,NULL,1.0000,1.0000,NULL,NULL,NULL,'year','{\"mail_driver\":\"smtp\",\"mail_host\":null,\"mail_port\":null,\"mail_username\":null,\"mail_password\":null,\"mail_encryption\":null,\"mail_from_address\":null,\"mail_from_name\":null}','{\"sms_service\":\"other\",\"nexmo_key\":null,\"nexmo_secret\":null,\"nexmo_from\":null,\"twilio_sid\":null,\"twilio_token\":null,\"twilio_from\":null,\"url\":null,\"send_to_param_name\":\"to\",\"msg_param_name\":\"text\",\"request_method\":\"post\",\"header_1\":null,\"header_val_1\":null,\"header_2\":null,\"header_val_2\":null,\"header_3\":null,\"header_val_3\":null,\"param_1\":null,\"param_val_1\":null,\"param_2\":null,\"param_val_2\":null,\"param_3\":null,\"param_val_3\":null,\"param_4\":null,\"param_val_4\":null,\"param_5\":null,\"param_val_5\":null,\"param_6\":null,\"param_val_6\":null,\"param_7\":null,\"param_val_7\":null,\"param_8\":null,\"param_val_8\":null,\"param_9\":null,\"param_val_9\":null,\"param_10\":null,\"param_val_10\":null}','{\"payments\":{\"custom_pay_1\":null,\"custom_pay_2\":null,\"custom_pay_3\":null,\"custom_pay_4\":null,\"custom_pay_5\":null,\"custom_pay_6\":null,\"custom_pay_7\":null},\"contact\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null,\"custom_field_7\":null,\"custom_field_8\":null,\"custom_field_9\":null,\"custom_field_10\":null},\"product\":{\"custom_field_1\":\"Etiqueta 1\",\"custom_field_2\":\"Etiqueta 2\",\"custom_field_3\":\"Etiqueta 3\",\"custom_field_4\":\"Etiqueta 4\"},\"location\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"user\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase_shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"sell\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"types_of_service\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null}}','{\"default_credit_limit\":null,\"default_datatable_page_entries\":\"25\"}',1,'2023-01-26 20:28:14','2023-03-29 13:58:33'),(5,'Farmacia Rocha',14,'2023-01-28',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,25.00,8,'America/La_Paz',1,'fifo',0.00,'includes',NULL,NULL,1,'add_expiry','keep_selling',0,1,0,NULL,1.000,30,30,'{\"pos\":{\"express_checkout\":\"shift+e\",\"pay_n_ckeckout\":\"shift+p\",\"draft\":\"shift+d\",\"cancel\":\"shift+c\",\"recent_product_quantity\":\"f2\",\"weighing_scale\":null,\"edit_discount\":\"shift+i\",\"edit_order_tax\":\"shift+t\",\"add_payment_row\":\"shift+r\",\"finalize_payment\":\"shift+f\",\"add_new_product\":\"f4\"}}','{\"cmmsn_calculation_type\":\"invoice_value\",\"amount_rounding_method\":null,\"razor_pay_key_id\":null,\"razor_pay_key_secret\":null,\"stripe_public_key\":null,\"stripe_secret_key\":null,\"disable_draft\":\"1\",\"disable_express_checkout\":\"1\",\"disable_order_tax\":\"1\",\"disable_suspend\":\"1\",\"enable_transaction_date\":\"1\",\"show_invoice_scheme\":\"1\",\"show_invoice_layout\":\"1\",\"show_pricing_on_product_sugesstion\":\"1\",\"cash_denominations\":\"1,2,5,10,20,50,100,200\",\"disable_pay_checkout\":0,\"hide_product_suggestion\":0,\"hide_recent_trans\":0,\"disable_discount\":0,\"is_pos_subtotal_editable\":0}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"label_prefix\":null,\"product_sku_length\":\"4\",\"qty_length\":\"3\",\"qty_length_decimal\":\"2\"}',1,1,0,1,1,0,5,0,0,0,0,1,NULL,1,0,'before','[\"purchases\",\"add_sale\",\"pos_sale\",\"stock_transfers\",\"stock_adjustment\",\"expenses\",\"modifiers\"]','m/d/Y','24','{\"purchase\":\"PO\",\"purchase_return\":null,\"purchase_order\":null,\"stock_transfer\":\"ST\",\"stock_adjustment\":\"SA\",\"sell_return\":\"CN\",\"expense\":\"EP\",\"contacts\":\"CO\",\"purchase_payment\":\"PP\",\"sell_payment\":\"SP\",\"expense_payment\":null,\"business_location\":\"BL\",\"username\":null,\"subscription\":null,\"draft\":null,\"sales_order\":null}','black',1,NULL,NULL,0,NULL,1.0000,1.0000,NULL,1.0000,1.0000,NULL,NULL,NULL,'year','{\"mail_driver\":\"smtp\",\"mail_host\":null,\"mail_port\":null,\"mail_username\":null,\"mail_password\":null,\"mail_encryption\":null,\"mail_from_address\":null,\"mail_from_name\":null}','{\"sms_service\":\"other\",\"nexmo_key\":null,\"nexmo_secret\":null,\"nexmo_from\":null,\"twilio_sid\":null,\"twilio_token\":null,\"twilio_from\":null,\"url\":null,\"send_to_param_name\":\"to\",\"msg_param_name\":\"text\",\"request_method\":\"post\",\"header_1\":null,\"header_val_1\":null,\"header_2\":null,\"header_val_2\":null,\"header_3\":null,\"header_val_3\":null,\"param_1\":null,\"param_val_1\":null,\"param_2\":null,\"param_val_2\":null,\"param_3\":null,\"param_val_3\":null,\"param_4\":null,\"param_val_4\":null,\"param_5\":null,\"param_val_5\":null,\"param_6\":null,\"param_val_6\":null,\"param_7\":null,\"param_val_7\":null,\"param_8\":null,\"param_val_8\":null,\"param_9\":null,\"param_val_9\":null,\"param_10\":null,\"param_val_10\":null}','{\"payments\":{\"custom_pay_1\":null,\"custom_pay_2\":null,\"custom_pay_3\":null,\"custom_pay_4\":null,\"custom_pay_5\":null,\"custom_pay_6\":null,\"custom_pay_7\":null},\"contact\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null,\"custom_field_7\":null,\"custom_field_8\":null,\"custom_field_9\":null,\"custom_field_10\":null},\"product\":{\"custom_field_1\":\"Etiqueta 1\",\"custom_field_2\":\"Etiqueta 2\",\"custom_field_3\":\"Etiqueta 3\",\"custom_field_4\":\"Etiqueta 4\"},\"location\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"user\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase_shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"sell\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"types_of_service\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null}}','{\"default_credit_limit\":null,\"default_datatable_page_entries\":\"25\"}',1,'2023-01-28 21:05:09','2023-03-29 11:09:32'),(6,'Ecopharma',14,'2023-01-30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,25.00,9,'America/La_Paz',1,'fifo',0.00,'includes',NULL,NULL,0,'add_expiry','keep_selling',0,1,0,NULL,1.000,30,30,'{\"pos\":{\"express_checkout\":\"shift+e\",\"pay_n_ckeckout\":\"shift+p\",\"draft\":\"shift+d\",\"cancel\":\"shift+c\",\"recent_product_quantity\":\"f2\",\"weighing_scale\":null,\"edit_discount\":\"shift+i\",\"edit_order_tax\":\"shift+t\",\"add_payment_row\":\"shift+r\",\"finalize_payment\":\"shift+f\",\"add_new_product\":\"f4\"}}','{\"cmmsn_calculation_type\":\"invoice_value\",\"amount_rounding_method\":null,\"razor_pay_key_id\":null,\"razor_pay_key_secret\":null,\"stripe_public_key\":null,\"stripe_secret_key\":null,\"cash_denominations\":null,\"disable_pay_checkout\":0,\"disable_draft\":0,\"disable_express_checkout\":0,\"hide_product_suggestion\":0,\"hide_recent_trans\":0,\"disable_discount\":0,\"disable_order_tax\":0,\"is_pos_subtotal_editable\":0}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"label_prefix\":null,\"product_sku_length\":\"4\",\"qty_length\":\"3\",\"qty_length_decimal\":\"2\"}',1,1,1,1,1,0,NULL,0,0,0,0,1,NULL,1,0,'before','[\"purchases\",\"add_sale\",\"pos_sale\",\"stock_transfers\",\"stock_adjustment\",\"expenses\"]','m/d/Y','24','{\"purchase\":\"PO\",\"purchase_return\":null,\"purchase_order\":null,\"stock_transfer\":\"ST\",\"stock_adjustment\":\"SA\",\"sell_return\":\"CN\",\"expense\":\"EP\",\"contacts\":\"CO\",\"purchase_payment\":\"PP\",\"sell_payment\":\"SP\",\"expense_payment\":null,\"business_location\":\"BL\",\"username\":null,\"subscription\":null,\"draft\":null,\"sales_order\":null}','black',NULL,NULL,NULL,0,NULL,1.0000,1.0000,NULL,1.0000,1.0000,NULL,NULL,NULL,'year','{\"mail_driver\":\"smtp\",\"mail_host\":null,\"mail_port\":null,\"mail_username\":null,\"mail_password\":null,\"mail_encryption\":null,\"mail_from_address\":null,\"mail_from_name\":null}','{\"sms_service\":\"other\",\"nexmo_key\":null,\"nexmo_secret\":null,\"nexmo_from\":null,\"twilio_sid\":null,\"twilio_token\":null,\"twilio_from\":null,\"url\":null,\"send_to_param_name\":\"to\",\"msg_param_name\":\"text\",\"request_method\":\"post\",\"header_1\":null,\"header_val_1\":null,\"header_2\":null,\"header_val_2\":null,\"header_3\":null,\"header_val_3\":null,\"param_1\":null,\"param_val_1\":null,\"param_2\":null,\"param_val_2\":null,\"param_3\":null,\"param_val_3\":null,\"param_4\":null,\"param_val_4\":null,\"param_5\":null,\"param_val_5\":null,\"param_6\":null,\"param_val_6\":null,\"param_7\":null,\"param_val_7\":null,\"param_8\":null,\"param_val_8\":null,\"param_9\":null,\"param_val_9\":null,\"param_10\":null,\"param_val_10\":null}','{\"payments\":{\"custom_pay_1\":null,\"custom_pay_2\":null,\"custom_pay_3\":null,\"custom_pay_4\":null,\"custom_pay_5\":null,\"custom_pay_6\":null,\"custom_pay_7\":null},\"contact\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null,\"custom_field_7\":null,\"custom_field_8\":null,\"custom_field_9\":null,\"custom_field_10\":null},\"product\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"location\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"user\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase_shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"sell\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"types_of_service\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null}}','{\"default_credit_limit\":null,\"default_datatable_page_entries\":\"25\"}',1,'2023-01-30 16:12:22','2023-02-13 18:46:08'),(7,'The Jonnes Burguer',14,'1969-12-31',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,25.00,10,'America/La_Paz',1,'fifo',0.00,'includes',NULL,NULL,0,'add_expiry','keep_selling',0,1,0,NULL,1.000,30,30,'{\"pos\":{\"express_checkout\":\"shift+e\",\"pay_n_ckeckout\":\"shift+p\",\"draft\":\"shift+d\",\"cancel\":\"shift+c\",\"recent_product_quantity\":\"f2\",\"weighing_scale\":null,\"edit_discount\":\"shift+i\",\"edit_order_tax\":\"shift+t\",\"add_payment_row\":\"shift+r\",\"finalize_payment\":\"shift+f\",\"add_new_product\":\"f4\"}}','{\"cmmsn_calculation_type\":\"invoice_value\",\"amount_rounding_method\":null,\"razor_pay_key_id\":null,\"razor_pay_key_secret\":null,\"stripe_public_key\":null,\"stripe_secret_key\":null,\"cash_denominations\":null,\"disable_pay_checkout\":0,\"disable_draft\":0,\"disable_express_checkout\":0,\"hide_product_suggestion\":0,\"hide_recent_trans\":0,\"disable_discount\":0,\"disable_order_tax\":0,\"is_pos_subtotal_editable\":0}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"label_prefix\":null,\"product_sku_length\":\"4\",\"qty_length\":\"3\",\"qty_length_decimal\":\"2\"}',0,1,0,1,1,0,7,0,0,0,0,1,NULL,1,0,'after','[\"purchases\",\"add_sale\",\"pos_sale\",\"stock_transfers\",\"stock_adjustment\",\"expenses\",\"tables\",\"kitchen\"]','d-m-Y','24','{\"purchase\":\"PO\",\"purchase_return\":null,\"purchase_order\":null,\"stock_transfer\":\"ST\",\"stock_adjustment\":\"SA\",\"sell_return\":\"CN\",\"expense\":\"EP\",\"contacts\":\"CO\",\"purchase_payment\":\"PP\",\"sell_payment\":\"SP\",\"expense_payment\":null,\"business_location\":\"BL\",\"username\":null,\"subscription\":null,\"draft\":null,\"sales_order\":null}',NULL,1,NULL,NULL,0,NULL,1.0000,1.0000,NULL,1.0000,1.0000,NULL,NULL,NULL,'year','{\"mail_driver\":\"smtp\",\"mail_host\":null,\"mail_port\":null,\"mail_username\":null,\"mail_password\":null,\"mail_encryption\":null,\"mail_from_address\":null,\"mail_from_name\":null}','{\"sms_service\":\"other\",\"nexmo_key\":null,\"nexmo_secret\":null,\"nexmo_from\":null,\"twilio_sid\":null,\"twilio_token\":null,\"twilio_from\":null,\"url\":null,\"send_to_param_name\":\"to\",\"msg_param_name\":\"text\",\"request_method\":\"post\",\"header_1\":null,\"header_val_1\":null,\"header_2\":null,\"header_val_2\":null,\"header_3\":null,\"header_val_3\":null,\"param_1\":null,\"param_val_1\":null,\"param_2\":null,\"param_val_2\":null,\"param_3\":null,\"param_val_3\":null,\"param_4\":null,\"param_val_4\":null,\"param_5\":null,\"param_val_5\":null,\"param_6\":null,\"param_val_6\":null,\"param_7\":null,\"param_val_7\":null,\"param_8\":null,\"param_val_8\":null,\"param_9\":null,\"param_val_9\":null,\"param_10\":null,\"param_val_10\":null}','{\"payments\":{\"custom_pay_1\":\"Tigo Money\",\"custom_pay_2\":\"Soli Billetera Movil\",\"custom_pay_3\":null,\"custom_pay_4\":null,\"custom_pay_5\":null,\"custom_pay_6\":null,\"custom_pay_7\":null},\"contact\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null,\"custom_field_7\":null,\"custom_field_8\":null,\"custom_field_9\":null,\"custom_field_10\":null},\"product\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"location\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"user\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase_shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"sell\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"types_of_service\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null}}','{\"default_credit_limit\":null,\"default_datatable_page_entries\":\"25\"}',1,'2023-02-01 10:48:07','2023-02-01 11:19:51'),(8,'Riberfarma',14,'2023-02-15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,25.00,12,'America/La_Paz',1,'fifo',0.00,'includes',NULL,NULL,1,'add_expiry','keep_selling',0,1,0,NULL,1.000,30,30,'{\"pos\":{\"express_checkout\":\"shift+e\",\"pay_n_ckeckout\":\"shift+p\",\"draft\":\"shift+d\",\"cancel\":\"shift+c\",\"recent_product_quantity\":\"f2\",\"weighing_scale\":null,\"edit_discount\":\"shift+i\",\"edit_order_tax\":\"shift+t\",\"add_payment_row\":\"shift+r\",\"finalize_payment\":\"shift+f\",\"add_new_product\":\"f4\"}}','{\"cmmsn_calculation_type\":\"invoice_value\",\"amount_rounding_method\":null,\"razor_pay_key_id\":null,\"razor_pay_key_secret\":null,\"stripe_public_key\":null,\"stripe_secret_key\":null,\"cash_denominations\":null,\"disable_pay_checkout\":0,\"disable_draft\":0,\"disable_express_checkout\":0,\"hide_product_suggestion\":0,\"hide_recent_trans\":0,\"disable_discount\":0,\"disable_order_tax\":0,\"is_pos_subtotal_editable\":0}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"label_prefix\":null,\"product_sku_length\":\"4\",\"qty_length\":\"3\",\"qty_length_decimal\":\"2\"}',1,1,0,1,1,0,8,0,0,0,0,1,NULL,1,0,'before','[\"purchases\",\"add_sale\",\"pos_sale\",\"stock_transfers\",\"stock_adjustment\",\"expenses\"]','m/d/Y','24','{\"purchase\":\"PO\",\"purchase_return\":null,\"purchase_order\":null,\"stock_transfer\":\"ST\",\"stock_adjustment\":\"SA\",\"sell_return\":\"CN\",\"expense\":\"EP\",\"contacts\":\"CO\",\"purchase_payment\":\"PP\",\"sell_payment\":\"SP\",\"expense_payment\":null,\"business_location\":\"BL\",\"username\":null,\"subscription\":null,\"draft\":null,\"sales_order\":null}','black',NULL,NULL,NULL,0,NULL,1.0000,1.0000,NULL,1.0000,1.0000,NULL,NULL,NULL,'year','{\"mail_driver\":\"smtp\",\"mail_host\":null,\"mail_port\":null,\"mail_username\":\"riberfarma\",\"mail_password\":\"123456\",\"mail_encryption\":null,\"mail_from_address\":null,\"mail_from_name\":null}','{\"sms_service\":\"other\",\"nexmo_key\":null,\"nexmo_secret\":null,\"nexmo_from\":null,\"twilio_sid\":null,\"twilio_token\":null,\"twilio_from\":null,\"url\":null,\"send_to_param_name\":\"to\",\"msg_param_name\":\"text\",\"request_method\":\"post\",\"header_1\":null,\"header_val_1\":null,\"header_2\":null,\"header_val_2\":null,\"header_3\":null,\"header_val_3\":null,\"param_1\":null,\"param_val_1\":null,\"param_2\":null,\"param_val_2\":null,\"param_3\":null,\"param_val_3\":null,\"param_4\":null,\"param_val_4\":null,\"param_5\":null,\"param_val_5\":null,\"param_6\":null,\"param_val_6\":null,\"param_7\":null,\"param_val_7\":null,\"param_8\":null,\"param_val_8\":null,\"param_9\":null,\"param_val_9\":null,\"param_10\":null,\"param_val_10\":null}','{\"payments\":{\"custom_pay_1\":null,\"custom_pay_2\":null,\"custom_pay_3\":null,\"custom_pay_4\":null,\"custom_pay_5\":null,\"custom_pay_6\":null,\"custom_pay_7\":null},\"contact\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null,\"custom_field_7\":null,\"custom_field_8\":null,\"custom_field_9\":null,\"custom_field_10\":null},\"product\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"location\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"user\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase_shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"sell\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"types_of_service\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null}}','{\"default_credit_limit\":null,\"default_datatable_page_entries\":\"25\"}',1,'2023-02-15 09:06:18','2023-02-15 09:10:03'),(9,'Farmacia Central',14,'2023-03-06',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,25.00,14,'America/La_Paz',1,'fifo',0.00,'includes',NULL,NULL,0,'add_expiry','keep_selling',0,1,0,NULL,1.000,30,30,'{\"pos\":{\"express_checkout\":\"shift+e\",\"pay_n_ckeckout\":\"shift+p\",\"draft\":\"shift+d\",\"cancel\":\"shift+c\",\"recent_product_quantity\":\"f2\",\"weighing_scale\":null,\"edit_discount\":\"shift+i\",\"edit_order_tax\":\"shift+t\",\"add_payment_row\":\"shift+r\",\"finalize_payment\":\"shift+f\",\"add_new_product\":\"f4\"}}','{\"cmmsn_calculation_type\":\"invoice_value\",\"amount_rounding_method\":null,\"razor_pay_key_id\":null,\"razor_pay_key_secret\":null,\"stripe_public_key\":null,\"stripe_secret_key\":null,\"cash_denominations\":null,\"disable_pay_checkout\":0,\"disable_draft\":0,\"disable_express_checkout\":0,\"hide_product_suggestion\":0,\"hide_recent_trans\":0,\"disable_discount\":0,\"disable_order_tax\":0,\"is_pos_subtotal_editable\":0}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"label_prefix\":null,\"product_sku_length\":\"4\",\"qty_length\":\"3\",\"qty_length_decimal\":\"2\"}',1,1,1,1,1,0,NULL,0,0,0,0,1,NULL,1,0,'before','[\"purchases\",\"add_sale\",\"pos_sale\",\"stock_transfers\",\"stock_adjustment\",\"expenses\",\"tables\"]','m/d/Y','24','{\"purchase\":\"PO\",\"purchase_return\":null,\"purchase_order\":null,\"stock_transfer\":\"ST\",\"stock_adjustment\":\"SA\",\"sell_return\":\"CN\",\"expense\":\"EP\",\"contacts\":\"CO\",\"purchase_payment\":\"PP\",\"sell_payment\":\"SP\",\"expense_payment\":null,\"business_location\":\"BL\",\"username\":null,\"subscription\":null,\"draft\":null,\"sales_order\":null}','black',NULL,NULL,NULL,0,NULL,1.0000,1.0000,NULL,1.0000,1.0000,NULL,NULL,NULL,'year','{\"mail_driver\":\"smtp\",\"mail_host\":null,\"mail_port\":null,\"mail_username\":null,\"mail_password\":null,\"mail_encryption\":null,\"mail_from_address\":null,\"mail_from_name\":null}','{\"sms_service\":\"other\",\"nexmo_key\":null,\"nexmo_secret\":null,\"nexmo_from\":null,\"twilio_sid\":null,\"twilio_token\":null,\"twilio_from\":null,\"url\":null,\"send_to_param_name\":\"to\",\"msg_param_name\":\"text\",\"request_method\":\"post\",\"header_1\":null,\"header_val_1\":null,\"header_2\":null,\"header_val_2\":null,\"header_3\":null,\"header_val_3\":null,\"param_1\":null,\"param_val_1\":null,\"param_2\":null,\"param_val_2\":null,\"param_3\":null,\"param_val_3\":null,\"param_4\":null,\"param_val_4\":null,\"param_5\":null,\"param_val_5\":null,\"param_6\":null,\"param_val_6\":null,\"param_7\":null,\"param_val_7\":null,\"param_8\":null,\"param_val_8\":null,\"param_9\":null,\"param_val_9\":null,\"param_10\":null,\"param_val_10\":null}','{\"payments\":{\"custom_pay_1\":null,\"custom_pay_2\":null,\"custom_pay_3\":null,\"custom_pay_4\":null,\"custom_pay_5\":null,\"custom_pay_6\":null,\"custom_pay_7\":null},\"contact\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null,\"custom_field_7\":null,\"custom_field_8\":null,\"custom_field_9\":null,\"custom_field_10\":null},\"product\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"location\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"user\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase_shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"sell\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"types_of_service\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null}}','{\"default_credit_limit\":null,\"default_datatable_page_entries\":\"25\"}',1,'2023-03-06 13:58:51','2023-03-06 20:41:42'),(10,'TILUCHI',14,'2023-03-21','7926141018','NIT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,25.00,15,'America/La_Paz',1,'fifo',0.00,'includes','1680058555_Sin título.jpg',NULL,0,'add_expiry','keep_selling',0,1,0,NULL,1.000,30,30,'{\"pos\":{\"express_checkout\":\"shift+e\",\"pay_n_ckeckout\":\"shift+p\",\"draft\":\"shift+d\",\"cancel\":\"shift+c\",\"recent_product_quantity\":\"f2\",\"weighing_scale\":null,\"edit_discount\":\"shift+i\",\"edit_order_tax\":\"shift+t\",\"add_payment_row\":\"shift+r\",\"finalize_payment\":\"shift+f\",\"add_new_product\":\"f4\"}}','{\"cmmsn_calculation_type\":\"invoice_value\",\"amount_rounding_method\":null,\"razor_pay_key_id\":null,\"razor_pay_key_secret\":null,\"stripe_public_key\":null,\"stripe_secret_key\":null,\"disable_draft\":\"1\",\"disable_express_checkout\":\"1\",\"disable_suspend\":\"1\",\"enable_transaction_date\":\"1\",\"disable_credit_sale_button\":\"1\",\"enable_weighing_scale\":\"1\",\"show_invoice_scheme\":\"1\",\"show_invoice_layout\":\"1\",\"show_pricing_on_product_sugesstion\":\"1\",\"cash_denominations\":\"1,2,5,10,20,50,100,200\",\"disable_pay_checkout\":0,\"hide_product_suggestion\":0,\"hide_recent_trans\":0,\"disable_discount\":0,\"disable_order_tax\":0,\"is_pos_subtotal_editable\":0}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"label_prefix\":null,\"product_sku_length\":\"4\",\"qty_length\":\"3\",\"qty_length_decimal\":\"2\"}',1,1,0,1,1,0,10,0,0,0,0,1,NULL,1,1,'after','[\"purchases\",\"add_sale\",\"pos_sale\",\"stock_transfers\",\"stock_adjustment\",\"expenses\"]','m/d/Y','24','{\"purchase\":\"PO\",\"purchase_return\":null,\"purchase_order\":null,\"stock_transfer\":\"ST\",\"stock_adjustment\":\"SA\",\"sell_return\":\"CN\",\"expense\":\"EP\",\"contacts\":\"CO\",\"purchase_payment\":\"PP\",\"sell_payment\":\"SP\",\"expense_payment\":null,\"business_location\":\"BL\",\"username\":null,\"subscription\":null,\"draft\":null,\"sales_order\":null}','black',NULL,NULL,NULL,0,NULL,1.0000,1.0000,NULL,1.0000,1.0000,NULL,NULL,NULL,'year','{\"mail_driver\":\"smtp\",\"mail_host\":null,\"mail_port\":null,\"mail_username\":null,\"mail_password\":null,\"mail_encryption\":null,\"mail_from_address\":null,\"mail_from_name\":null}','{\"sms_service\":\"other\",\"nexmo_key\":null,\"nexmo_secret\":null,\"nexmo_from\":null,\"twilio_sid\":null,\"twilio_token\":null,\"twilio_from\":null,\"url\":null,\"send_to_param_name\":\"to\",\"msg_param_name\":\"text\",\"request_method\":\"post\",\"header_1\":null,\"header_val_1\":null,\"header_2\":null,\"header_val_2\":null,\"header_3\":null,\"header_val_3\":null,\"param_1\":null,\"param_val_1\":null,\"param_2\":null,\"param_val_2\":null,\"param_3\":null,\"param_val_3\":null,\"param_4\":null,\"param_val_4\":null,\"param_5\":null,\"param_val_5\":null,\"param_6\":null,\"param_val_6\":null,\"param_7\":null,\"param_val_7\":null,\"param_8\":null,\"param_val_8\":null,\"param_9\":null,\"param_val_9\":null,\"param_10\":null,\"param_val_10\":null}','{\"payments\":{\"custom_pay_1\":null,\"custom_pay_2\":null,\"custom_pay_3\":null,\"custom_pay_4\":null,\"custom_pay_5\":null,\"custom_pay_6\":null,\"custom_pay_7\":null},\"contact\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null,\"custom_field_7\":null,\"custom_field_8\":null,\"custom_field_9\":null,\"custom_field_10\":null},\"product\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"location\":{\"custom_field_1\":\"Siat Url\",\"custom_field_2\":\"Siat User\",\"custom_field_3\":\"Siat Password\",\"custom_field_4\":\"Siat Nit\"},\"user\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase_shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"sell\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"types_of_service\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null}}','{\"default_credit_limit\":null,\"default_datatable_page_entries\":\"25\"}',1,'2023-03-21 16:07:24','2023-03-28 23:37:18'),(11,'Comercial Maxi Ahorro',14,'2023-03-22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,25.00,16,'America/La_Paz',1,'fifo',0.00,'includes',NULL,NULL,0,'add_expiry','keep_selling',0,1,0,NULL,1.000,30,30,'{\"pos\":{\"express_checkout\":\"shift+e\",\"pay_n_ckeckout\":\"shift+p\",\"draft\":\"shift+d\",\"cancel\":\"shift+c\",\"recent_product_quantity\":\"f2\",\"weighing_scale\":null,\"edit_discount\":\"shift+i\",\"edit_order_tax\":\"shift+t\",\"add_payment_row\":\"shift+r\",\"finalize_payment\":\"shift+f\",\"add_new_product\":\"f4\"}}','{\"cmmsn_calculation_type\":\"invoice_value\",\"amount_rounding_method\":null,\"razor_pay_key_id\":null,\"razor_pay_key_secret\":null,\"stripe_public_key\":null,\"stripe_secret_key\":null,\"disable_draft\":\"1\",\"disable_express_checkout\":\"1\",\"show_invoice_scheme\":\"1\",\"show_invoice_layout\":\"1\",\"show_pricing_on_product_sugesstion\":\"1\",\"cash_denominations\":\"1,2,5,10,20,50,100,200\",\"disable_pay_checkout\":0,\"hide_product_suggestion\":0,\"hide_recent_trans\":0,\"disable_discount\":0,\"disable_order_tax\":0,\"is_pos_subtotal_editable\":0}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"label_prefix\":null,\"product_sku_length\":\"4\",\"qty_length\":\"3\",\"qty_length_decimal\":\"2\"}',1,1,0,0,1,0,11,0,0,0,0,1,NULL,1,0,'before','[\"purchases\",\"add_sale\",\"pos_sale\",\"stock_transfers\",\"stock_adjustment\",\"expenses\"]','m/d/Y','24','{\"purchase\":\"PO\",\"purchase_return\":null,\"purchase_order\":null,\"stock_transfer\":\"ST\",\"stock_adjustment\":\"SA\",\"sell_return\":\"CN\",\"expense\":\"EP\",\"contacts\":\"CO\",\"purchase_payment\":\"PP\",\"sell_payment\":\"SP\",\"expense_payment\":null,\"business_location\":\"BL\",\"username\":null,\"subscription\":null,\"draft\":null,\"sales_order\":null}','black',NULL,NULL,NULL,0,NULL,1.0000,1.0000,NULL,1.0000,1.0000,NULL,NULL,NULL,'year','{\"mail_driver\":\"smtp\",\"mail_host\":null,\"mail_port\":null,\"mail_username\":null,\"mail_password\":null,\"mail_encryption\":null,\"mail_from_address\":null,\"mail_from_name\":null}','{\"sms_service\":\"other\",\"nexmo_key\":null,\"nexmo_secret\":null,\"nexmo_from\":null,\"twilio_sid\":null,\"twilio_token\":null,\"twilio_from\":null,\"url\":null,\"send_to_param_name\":\"to\",\"msg_param_name\":\"text\",\"request_method\":\"post\",\"header_1\":null,\"header_val_1\":null,\"header_2\":null,\"header_val_2\":null,\"header_3\":null,\"header_val_3\":null,\"param_1\":null,\"param_val_1\":null,\"param_2\":null,\"param_val_2\":null,\"param_3\":null,\"param_val_3\":null,\"param_4\":null,\"param_val_4\":null,\"param_5\":null,\"param_val_5\":null,\"param_6\":null,\"param_val_6\":null,\"param_7\":null,\"param_val_7\":null,\"param_8\":null,\"param_val_8\":null,\"param_9\":null,\"param_val_9\":null,\"param_10\":null,\"param_val_10\":null}','{\"payments\":{\"custom_pay_1\":null,\"custom_pay_2\":null,\"custom_pay_3\":null,\"custom_pay_4\":null,\"custom_pay_5\":null,\"custom_pay_6\":null,\"custom_pay_7\":null},\"contact\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null,\"custom_field_7\":null,\"custom_field_8\":null,\"custom_field_9\":null,\"custom_field_10\":null},\"product\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"location\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"user\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase_shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"sell\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"types_of_service\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null}}','{\"default_credit_limit\":null,\"default_datatable_page_entries\":\"25\"}',1,'2023-03-22 12:12:28','2023-03-22 14:53:01');
/*!40000 ALTER TABLE `business` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `business_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `business_locations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int unsigned NOT NULL,
  `location_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `landmark` text COLLATE utf8mb4_unicode_ci,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zip_code` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice_scheme_id` int unsigned NOT NULL,
  `invoice_layout_id` int unsigned NOT NULL,
  `sale_invoice_layout_id` int DEFAULT NULL,
  `selling_price_group_id` int DEFAULT NULL,
  `print_receipt_on_invoice` tinyint(1) DEFAULT '1',
  `receipt_printer_type` enum('browser','printer') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'browser',
  `printer_id` int DEFAULT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alternate_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `featured_products` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `default_payment_accounts` text COLLATE utf8mb4_unicode_ci,
  `custom_field1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `business_locations_business_id_index` (`business_id`),
  KEY `business_locations_invoice_scheme_id_foreign` (`invoice_scheme_id`),
  KEY `business_locations_invoice_layout_id_foreign` (`invoice_layout_id`),
  KEY `business_locations_sale_invoice_layout_id_index` (`sale_invoice_layout_id`),
  KEY `business_locations_selling_price_group_id_index` (`selling_price_group_id`),
  KEY `business_locations_receipt_printer_type_index` (`receipt_printer_type`),
  KEY `business_locations_printer_id_index` (`printer_id`),
  CONSTRAINT `business_locations_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `business_locations_invoice_layout_id_foreign` FOREIGN KEY (`invoice_layout_id`) REFERENCES `invoice_layouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `business_locations_invoice_scheme_id_foreign` FOREIGN KEY (`invoice_scheme_id`) REFERENCES `invoice_schemes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `business_locations` WRITE;
/*!40000 ALTER TABLE `business_locations` DISABLE KEYS */;
INSERT INTO `business_locations` VALUES (1,1,'BL0001','gosystem','0','Bolivia','Beni','Trinidad','0',1,1,1,NULL,1,'browser',NULL,'','','','',NULL,1,'{\"cash\":{\"is_enabled\":1,\"account\":null},\"card\":{\"is_enabled\":1,\"account\":null},\"cheque\":{\"is_enabled\":1,\"account\":null},\"bank_transfer\":{\"is_enabled\":1,\"account\":null},\"other\":{\"is_enabled\":1,\"account\":null},\"custom_pay_1\":{\"is_enabled\":1,\"account\":null},\"custom_pay_2\":{\"is_enabled\":1,\"account\":null},\"custom_pay_3\":{\"is_enabled\":1,\"account\":null},\"custom_pay_4\":{\"is_enabled\":1,\"account\":null},\"custom_pay_5\":{\"is_enabled\":1,\"account\":null},\"custom_pay_6\":{\"is_enabled\":1,\"account\":null},\"custom_pay_7\":{\"is_enabled\":1,\"account\":null}}',NULL,NULL,NULL,NULL,NULL,'2023-01-26 15:59:33','2023-01-26 15:59:33'),(2,2,'BL0001','Fabrica','0','Bolivia','Beni','Trinidad','0',2,2,2,NULL,1,'browser',NULL,'67271431',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-26 16:42:31','2023-01-26 17:31:33'),(3,2,'BL0002','27 de Mayo',NULL,'Bolivia','Beni','Trinidad','0',2,2,2,NULL,1,'browser',NULL,NULL,NULL,NULL,NULL,NULL,1,'{\"cash\":{\"is_enabled\":\"1\"},\"card\":{\"is_enabled\":\"1\"},\"bank_transfer\":{\"is_enabled\":\"1\"}}',NULL,NULL,NULL,NULL,NULL,'2023-01-26 17:29:10','2023-01-26 17:32:11'),(4,2,'BL0003','Plazuela de la Tradicion',NULL,'Bolivia','Beni','Trinidad','0',2,2,2,NULL,1,'browser',NULL,NULL,NULL,NULL,NULL,NULL,1,'{\"cash\":{\"is_enabled\":\"1\"},\"card\":{\"is_enabled\":\"1\"},\"bank_transfer\":{\"is_enabled\":\"1\"}}',NULL,NULL,NULL,NULL,NULL,'2023-01-26 17:31:14','2023-01-26 17:31:14'),(5,3,'BL0001','ShopTec','Calle Sucre #167','Bolivia','Beni','Trinidad','0000',3,3,3,NULL,1,'browser',NULL,NULL,NULL,NULL,NULL,NULL,1,'{\"cash\":{\"is_enabled\":\"1\"},\"card\":{\"is_enabled\":\"1\"},\"cheque\":{\"is_enabled\":\"1\"},\"bank_transfer\":{\"is_enabled\":\"1\"},\"custom_pay_1\":{\"is_enabled\":\"1\"},\"custom_pay_2\":{\"is_enabled\":\"1\"}}',NULL,NULL,NULL,NULL,NULL,'2023-01-26 19:20:15','2023-01-30 11:31:51'),(6,4,'BL0001','Farmacia Ayleen','0','Bolivia','Beni','Guayaramerin','0',4,4,4,NULL,1,'browser',NULL,'69403136','','','',NULL,1,'{\"cash\":{\"is_enabled\":1,\"account\":null},\"card\":{\"is_enabled\":1,\"account\":null},\"cheque\":{\"is_enabled\":1,\"account\":null},\"bank_transfer\":{\"is_enabled\":1,\"account\":null},\"other\":{\"is_enabled\":1,\"account\":null},\"custom_pay_1\":{\"is_enabled\":1,\"account\":null},\"custom_pay_2\":{\"is_enabled\":1,\"account\":null},\"custom_pay_3\":{\"is_enabled\":1,\"account\":null},\"custom_pay_4\":{\"is_enabled\":1,\"account\":null},\"custom_pay_5\":{\"is_enabled\":1,\"account\":null},\"custom_pay_6\":{\"is_enabled\":1,\"account\":null},\"custom_pay_7\":{\"is_enabled\":1,\"account\":null}}',NULL,NULL,NULL,NULL,NULL,'2023-01-26 20:28:14','2023-01-26 20:28:14'),(7,5,'BL0001','Farmacia Rocha','0','Bolivia','Beni','Trinidad','0',5,5,5,NULL,1,'browser',NULL,'73917889',NULL,NULL,NULL,NULL,1,'{\"cash\":{\"is_enabled\":\"1\",\"account\":null},\"card\":{\"account\":null},\"cheque\":{\"account\":null},\"bank_transfer\":{\"is_enabled\":\"1\",\"account\":null},\"other\":{\"account\":null},\"custom_pay_1\":{\"account\":null},\"custom_pay_2\":{\"account\":null},\"custom_pay_3\":{\"account\":null},\"custom_pay_4\":{\"account\":null},\"custom_pay_5\":{\"account\":null},\"custom_pay_6\":{\"account\":null},\"custom_pay_7\":{\"account\":null}}',NULL,NULL,NULL,NULL,NULL,'2023-01-28 21:05:09','2023-02-13 20:22:01'),(8,6,'BL0001','Ecopharma','0','Bolivia','Beni','Trinidad','0',6,6,6,NULL,1,'browser',NULL,'78528582','','','',NULL,1,'{\"cash\":{\"is_enabled\":1,\"account\":null},\"card\":{\"is_enabled\":1,\"account\":null},\"cheque\":{\"is_enabled\":1,\"account\":null},\"bank_transfer\":{\"is_enabled\":1,\"account\":null},\"other\":{\"is_enabled\":1,\"account\":null},\"custom_pay_1\":{\"is_enabled\":1,\"account\":null},\"custom_pay_2\":{\"is_enabled\":1,\"account\":null},\"custom_pay_3\":{\"is_enabled\":1,\"account\":null},\"custom_pay_4\":{\"is_enabled\":1,\"account\":null},\"custom_pay_5\":{\"is_enabled\":1,\"account\":null},\"custom_pay_6\":{\"is_enabled\":1,\"account\":null},\"custom_pay_7\":{\"is_enabled\":1,\"account\":null}}',NULL,NULL,NULL,NULL,NULL,'2023-01-30 16:12:22','2023-01-30 16:12:22'),(9,7,'BL0001','The Jonnes Burguer','0','Bolivia','Beni','Trinidad','0',7,7,7,NULL,1,'browser',NULL,'78572721','','','',NULL,1,'{\"cash\":{\"is_enabled\":1,\"account\":null},\"card\":{\"is_enabled\":1,\"account\":null},\"cheque\":{\"is_enabled\":1,\"account\":null},\"bank_transfer\":{\"is_enabled\":1,\"account\":null},\"other\":{\"is_enabled\":1,\"account\":null},\"custom_pay_1\":{\"is_enabled\":1,\"account\":null},\"custom_pay_2\":{\"is_enabled\":1,\"account\":null},\"custom_pay_3\":{\"is_enabled\":1,\"account\":null},\"custom_pay_4\":{\"is_enabled\":1,\"account\":null},\"custom_pay_5\":{\"is_enabled\":1,\"account\":null},\"custom_pay_6\":{\"is_enabled\":1,\"account\":null},\"custom_pay_7\":{\"is_enabled\":1,\"account\":null}}',NULL,NULL,NULL,NULL,NULL,'2023-02-01 10:48:07','2023-02-01 10:48:07'),(10,8,'BL0001','Riberfarma','0','Bolivia','Beni','Riberalta','0',8,8,8,NULL,1,'browser',NULL,'','','','',NULL,1,'{\"cash\":{\"is_enabled\":1,\"account\":null},\"card\":{\"is_enabled\":1,\"account\":null},\"cheque\":{\"is_enabled\":1,\"account\":null},\"bank_transfer\":{\"is_enabled\":1,\"account\":null},\"other\":{\"is_enabled\":1,\"account\":null},\"custom_pay_1\":{\"is_enabled\":1,\"account\":null},\"custom_pay_2\":{\"is_enabled\":1,\"account\":null},\"custom_pay_3\":{\"is_enabled\":1,\"account\":null},\"custom_pay_4\":{\"is_enabled\":1,\"account\":null},\"custom_pay_5\":{\"is_enabled\":1,\"account\":null},\"custom_pay_6\":{\"is_enabled\":1,\"account\":null},\"custom_pay_7\":{\"is_enabled\":1,\"account\":null}}',NULL,NULL,NULL,NULL,NULL,'2023-02-15 09:06:18','2023-02-15 09:06:18'),(11,9,'BL0001','Farmacia Central','0','Bolivia','Beni','Trinidad','0000',9,9,9,NULL,1,'browser',NULL,'72880553','','','',NULL,1,'{\"cash\":{\"is_enabled\":1,\"account\":null},\"card\":{\"is_enabled\":1,\"account\":null},\"cheque\":{\"is_enabled\":1,\"account\":null},\"bank_transfer\":{\"is_enabled\":1,\"account\":null},\"other\":{\"is_enabled\":1,\"account\":null},\"custom_pay_1\":{\"is_enabled\":1,\"account\":null},\"custom_pay_2\":{\"is_enabled\":1,\"account\":null},\"custom_pay_3\":{\"is_enabled\":1,\"account\":null},\"custom_pay_4\":{\"is_enabled\":1,\"account\":null},\"custom_pay_5\":{\"is_enabled\":1,\"account\":null},\"custom_pay_6\":{\"is_enabled\":1,\"account\":null},\"custom_pay_7\":{\"is_enabled\":1,\"account\":null}}',NULL,NULL,NULL,NULL,NULL,'2023-03-06 13:58:51','2023-03-06 13:58:51'),(12,10,'BL0001','LA CASA DEL TILUCHI','0','Bolivia','Beni','Trinidad','0',11,11,11,NULL,1,'browser',NULL,'77988343',NULL,NULL,NULL,'[\"38\"]',1,'{\"cash\":{\"is_enabled\":\"1\"},\"bank_transfer\":{\"is_enabled\":\"1\"},\"other\":{\"is_enabled\":\"1\"}}','https://pweb.impuestos.gob.bo','Lsaavedra79','LSaavedra18','7926141018',NULL,'2023-03-21 16:07:24','2023-03-22 11:19:48'),(13,11,'BL0001','Comercial Maxi Ahorro','0','Bolivia','Beni','Cercado','0',12,12,12,NULL,1,'browser',NULL,'72838376',NULL,NULL,NULL,NULL,1,'{\"cash\":{\"is_enabled\":\"1\"},\"bank_transfer\":{\"is_enabled\":\"1\"},\"other\":{\"is_enabled\":\"1\"}}','https://pweb.impuestos.gob.bo',NULL,NULL,NULL,NULL,'2023-03-22 12:12:28','2023-03-22 12:16:50');
/*!40000 ALTER TABLE `business_locations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cash_register_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cash_register_transactions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `cash_register_id` int unsigned NOT NULL,
  `amount` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `pay_method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('debit','credit') COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cash_register_transactions_cash_register_id_foreign` (`cash_register_id`),
  KEY `cash_register_transactions_transaction_id_index` (`transaction_id`),
  KEY `cash_register_transactions_type_index` (`type`),
  KEY `cash_register_transactions_transaction_type_index` (`transaction_type`),
  CONSTRAINT `cash_register_transactions_cash_register_id_foreign` FOREIGN KEY (`cash_register_id`) REFERENCES `cash_registers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cash_register_transactions` WRITE;
/*!40000 ALTER TABLE `cash_register_transactions` DISABLE KEYS */;
INSERT INTO `cash_register_transactions` VALUES (1,4,500.0000,'cash','credit','sell',4,'2023-01-26 19:58:47','2023-01-26 19:58:47'),(2,4,566.0000,'custom_pay_2','credit','sell',4,'2023-01-26 19:58:47','2023-01-26 19:58:47'),(3,3,1916.1200,'other','credit','sell',5,'2023-01-26 19:58:47','2023-01-26 19:58:47'),(4,3,950.0000,'cash','credit','sell',6,'2023-01-26 20:10:43','2023-01-26 20:10:43'),(5,3,950.0000,'cash','debit','refund',6,'2023-01-26 20:14:12','2023-01-26 20:14:12'),(6,3,1396.0000,'bank_transfer','credit','sell',9,'2023-01-27 10:28:52','2023-01-27 10:28:52'),(7,3,50.0000,'custom_pay_2','credit','sell',12,'2023-01-30 10:19:19','2023-01-30 10:19:19'),(8,3,340.0000,'custom_pay_2','credit','sell',13,'2023-01-31 10:23:25','2023-01-31 10:23:25'),(9,4,300.0000,'cash','credit','sell',14,'2023-01-31 10:24:36','2023-01-31 10:24:36'),(10,3,60.0000,'custom_pay_2','credit','sell',15,'2023-01-31 10:25:14','2023-01-31 10:25:14'),(11,3,500.0000,'custom_pay_2','debit','expense',17,'2023-01-31 10:37:27','2023-01-31 10:37:27'),(12,3,340.0000,'cash','credit','sell',18,'2023-02-03 10:52:34','2023-02-03 10:52:34'),(14,4,423.0000,'cash','credit','sell',20,'2023-02-03 14:20:59','2023-02-03 14:20:59'),(15,4,1100.0000,'cash','credit','sell',21,'2023-02-10 19:36:01','2023-02-10 19:36:01'),(16,4,250.0000,'cash','credit','sell',22,'2023-02-10 19:40:09','2023-02-10 19:40:09'),(17,8,300.0000,'cash','credit','initial',NULL,'2023-02-14 11:21:29','2023-02-14 11:21:29'),(18,9,100.0000,'cash','credit','initial',NULL,'2023-02-17 10:19:07','2023-02-17 10:19:07'),(19,8,10.0000,'cash','debit','expense',64,'2023-02-17 16:37:11','2023-02-17 16:37:11'),(39,9,15.0000,'cash','credit','sell',86,'2023-02-17 18:38:46','2023-02-17 18:38:46'),(40,10,100.0000,'cash','credit','initial',NULL,'2023-03-21 16:38:57','2023-03-21 16:38:57'),(58,11,100.0000,'cash','credit','initial',NULL,'2023-03-22 15:00:04','2023-03-22 15:00:04'),(59,7,14.0000,'cash','credit','sell',103,'2023-03-28 12:36:19','2023-03-28 12:36:19'),(60,7,15.0000,'cash','credit','sell',104,'2023-03-28 12:40:19','2023-03-28 12:40:19'),(63,5,20.0000,'cash','credit','sell',121,'2023-03-29 14:11:27','2023-03-29 14:11:27'),(64,5,-6.0000,'cash','credit','sell',121,'2023-03-29 14:11:27','2023-03-29 14:11:27');
/*!40000 ALTER TABLE `cash_register_transactions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cash_registers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cash_registers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int unsigned NOT NULL,
  `location_id` int DEFAULT NULL,
  `user_id` int unsigned DEFAULT NULL,
  `status` enum('close','open') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `closed_at` datetime DEFAULT NULL,
  `closing_amount` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `total_card_slips` int NOT NULL DEFAULT '0',
  `total_cheques` int NOT NULL DEFAULT '0',
  `denominations` text COLLATE utf8mb4_unicode_ci,
  `closing_note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cash_registers_business_id_foreign` (`business_id`),
  KEY `cash_registers_user_id_foreign` (`user_id`),
  KEY `cash_registers_location_id_index` (`location_id`),
  CONSTRAINT `cash_registers_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cash_registers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cash_registers` WRITE;
/*!40000 ALTER TABLE `cash_registers` DISABLE KEYS */;
INSERT INTO `cash_registers` VALUES (1,1,1,1,'open',NULL,0.0000,0,0,NULL,NULL,'2023-01-26 16:36:00','2023-01-26 16:36:50'),(2,2,2,2,'close','2023-02-14 11:20:46',0.0000,0,0,'{\"1\":null,\"2\":null,\"5\":null,\"10\":null,\"20\":null,\"50\":null,\"100\":null,\"500\":null}',NULL,'2023-01-26 16:49:00','2023-02-14 11:20:46'),(3,3,5,5,'open',NULL,0.0000,0,0,NULL,NULL,'2023-01-26 19:57:00','2023-01-26 19:57:29'),(4,3,5,4,'open',NULL,0.0000,0,0,NULL,NULL,'2023-01-26 19:57:00','2023-01-26 19:57:30'),(5,4,6,6,'open',NULL,0.0000,0,0,NULL,NULL,'2023-01-26 20:50:00','2023-01-26 20:50:35'),(6,4,6,7,'open',NULL,0.0000,0,0,NULL,NULL,'2023-01-26 21:00:00','2023-01-26 21:00:30'),(7,5,7,8,'open',NULL,0.0000,0,0,NULL,NULL,'2023-02-13 19:04:00','2023-02-13 19:04:41'),(8,2,3,2,'open',NULL,0.0000,0,0,NULL,NULL,'2023-02-14 11:21:00','2023-02-14 11:21:29'),(9,2,3,11,'open',NULL,0.0000,0,0,NULL,NULL,'2023-02-17 10:19:00','2023-02-17 10:19:07'),(10,10,12,15,'open',NULL,0.0000,0,0,NULL,NULL,'2023-03-21 16:38:00','2023-03-21 16:38:57'),(11,11,13,16,'open',NULL,0.0000,0,0,NULL,NULL,'2023-03-22 15:00:00','2023-03-22 15:00:03');
/*!40000 ALTER TABLE `cash_registers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int unsigned NOT NULL,
  `short_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int NOT NULL,
  `created_by` int unsigned NOT NULL,
  `category_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `woocommerce_cat_id` int DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categories_business_id_foreign` (`business_id`),
  KEY `categories_created_by_foreign` (`created_by`),
  KEY `categories_parent_id_index` (`parent_id`),
  KEY `categories_woocommerce_cat_id_index` (`woocommerce_cat_id`),
  CONSTRAINT `categories_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categories_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Menu Principal',2,NULL,0,2,'product',NULL,NULL,NULL,NULL,'2023-01-26 17:43:27','2023-01-26 17:43:27'),(2,'Ingrediente',2,NULL,0,2,'product',NULL,NULL,NULL,NULL,'2023-01-26 17:48:18','2023-01-26 17:48:18'),(3,'Extras',2,NULL,0,2,'product',NULL,NULL,NULL,NULL,'2023-01-26 17:48:25','2023-01-26 17:48:25'),(4,'Gama media',3,NULL,0,3,'product',NULL,NULL,NULL,NULL,'2023-01-26 19:34:24','2023-01-26 19:34:24'),(5,'AMPOLLAS',4,NULL,0,6,'product',NULL,NULL,NULL,NULL,'2023-01-26 20:48:43','2023-03-29 10:53:03'),(6,'Software',3,NULL,0,4,'product',NULL,NULL,NULL,NULL,'2023-01-27 10:27:58','2023-01-27 10:27:58'),(7,'Sin categoria',5,NULL,0,8,'product',NULL,NULL,NULL,NULL,'2023-02-13 19:03:17','2023-02-13 19:03:17'),(8,'Comprimidos',5,NULL,0,8,'product',NULL,NULL,NULL,NULL,'2023-02-13 20:08:16','2023-02-13 20:08:16'),(9,'PLAMAT ROSCA',10,NULL,0,15,'product',NULL,NULL,NULL,NULL,'2023-03-21 16:19:34','2023-03-21 16:19:34'),(10,'PLAMAT DESAGUE',10,NULL,0,15,'product',NULL,NULL,NULL,NULL,'2023-03-22 10:12:14','2023-03-22 10:12:14'),(15,'PLAMAT ELECTRICIDAD',10,NULL,0,15,'product',NULL,NULL,NULL,NULL,'2023-03-22 10:55:26','2023-03-22 10:55:26'),(16,'TIGRE ROSCA',10,NULL,0,15,'product',NULL,NULL,NULL,NULL,'2023-03-22 10:55:26','2023-03-22 10:55:26'),(17,'ART. PLOMERIA',10,NULL,0,15,'product',NULL,NULL,NULL,NULL,'2023-03-22 10:55:27','2023-03-22 10:55:27'),(18,'MAXI RUBBER',10,NULL,0,15,'product',NULL,NULL,NULL,NULL,'2023-03-28 23:04:38','2023-03-28 23:04:38'),(19,'SINTEPLAST',10,NULL,0,15,'product',NULL,NULL,NULL,NULL,'2023-03-28 23:13:35','2023-03-28 23:13:35'),(20,'VIAL',4,NULL,0,6,'product',NULL,NULL,NULL,NULL,'2023-03-29 10:54:17','2023-03-29 10:54:17'),(21,'JARABE',4,NULL,0,6,'product',NULL,NULL,NULL,NULL,'2023-03-29 10:54:34','2023-03-29 10:54:34'),(22,'SUSPENSIÒN',4,NULL,0,6,'product',NULL,NULL,NULL,NULL,'2023-03-29 10:54:48','2023-03-29 10:54:48'),(23,'COMPRIMIDOS',4,NULL,0,6,'product',NULL,NULL,NULL,NULL,'2023-03-29 10:55:00','2023-03-29 10:55:00'),(24,'CAPSULAS',4,NULL,0,6,'product',NULL,NULL,NULL,NULL,'2023-03-29 10:55:13','2023-03-29 10:55:13'),(25,'POMADA',4,NULL,0,6,'product',NULL,NULL,NULL,NULL,'2023-03-29 10:55:34','2023-03-29 10:55:34'),(26,'CREMA',4,NULL,0,6,'product',NULL,NULL,NULL,NULL,'2023-03-29 10:55:43','2023-03-29 10:55:43'),(27,'SACHET',4,NULL,0,6,'product',NULL,NULL,NULL,NULL,'2023-03-29 10:56:31','2023-03-29 10:56:31'),(28,'HILOS',4,NULL,0,6,'product',NULL,NULL,NULL,NULL,'2023-03-29 10:58:18','2023-03-29 10:58:18'),(29,'MAMADERA',4,NULL,0,6,'product',NULL,NULL,NULL,NULL,'2023-03-29 10:59:01','2023-03-29 10:59:01'),(30,'AEROSOL',4,NULL,0,6,'product',NULL,NULL,NULL,NULL,'2023-03-29 10:59:40','2023-03-29 10:59:40'),(31,'LOCION',4,NULL,0,6,'product',NULL,NULL,NULL,NULL,'2023-03-29 10:59:54','2023-03-29 10:59:54'),(32,'SOLUCION',4,NULL,0,6,'product',NULL,NULL,NULL,NULL,'2023-03-29 11:01:07','2023-03-29 11:01:07'),(33,'INFUSOR',4,NULL,0,6,'product',NULL,NULL,NULL,NULL,'2023-03-29 11:01:18','2023-03-29 11:01:18'),(34,'BRANULAS',4,NULL,0,6,'product',NULL,NULL,NULL,'2023-03-29 11:05:19','2023-03-29 11:01:32','2023-03-29 11:05:19'),(35,'OVULOS',4,NULL,0,6,'product',NULL,NULL,NULL,NULL,'2023-03-29 11:01:44','2023-03-29 11:01:44'),(36,'CREMA VAGINAL',4,NULL,0,6,'product',NULL,NULL,NULL,NULL,'2023-03-29 11:01:57','2023-03-29 11:01:57'),(37,'SUPOSITORIO',4,NULL,0,6,'product',NULL,NULL,NULL,NULL,'2023-03-29 11:02:11','2023-03-29 11:02:11'),(38,'JERINGAS',4,NULL,0,6,'product',NULL,NULL,NULL,NULL,'2023-03-29 11:02:34','2023-03-29 11:02:34'),(39,'EQUIPO DE SUERO',4,NULL,0,6,'product',NULL,NULL,NULL,NULL,'2023-03-29 11:02:59','2023-03-29 11:02:59'),(40,'PIEZAS',4,NULL,0,6,'product',NULL,NULL,NULL,NULL,'2023-03-29 11:03:12','2023-03-29 11:03:12'),(41,'UNIDAD',4,NULL,0,6,'product',NULL,NULL,NULL,NULL,'2023-03-29 11:05:51','2023-03-29 11:05:51'),(42,'GLADIADOR',10,NULL,0,15,'product',NULL,NULL,NULL,NULL,'2023-03-30 00:58:48','2023-03-30 00:58:48');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categorizables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorizables` (
  `category_id` int NOT NULL,
  `categorizable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `categorizable_id` bigint unsigned NOT NULL,
  KEY `categorizables_categorizable_type_categorizable_id_index` (`categorizable_type`,`categorizable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categorizables` WRITE;
/*!40000 ALTER TABLE `categorizables` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorizables` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int unsigned NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_business_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prefix` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `middle_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `tax_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_line_1` text COLLATE utf8mb4_unicode_ci,
  `address_line_2` text COLLATE utf8mb4_unicode_ci,
  `zip_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `landline` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alternate_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pay_term_number` int DEFAULT NULL,
  `pay_term_type` enum('days','months') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `credit_limit` decimal(22,4) DEFAULT NULL,
  `created_by` int unsigned NOT NULL,
  `converted_by` int DEFAULT NULL,
  `converted_on` datetime DEFAULT NULL,
  `balance` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `total_rp` int NOT NULL DEFAULT '0' COMMENT 'rp is the short form of reward points',
  `total_rp_used` int NOT NULL DEFAULT '0' COMMENT 'rp is the short form of reward points',
  `total_rp_expired` int NOT NULL DEFAULT '0' COMMENT 'rp is the short form of reward points',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `shipping_address` text COLLATE utf8mb4_unicode_ci,
  `shipping_custom_field_details` longtext COLLATE utf8mb4_unicode_ci,
  `is_export` tinyint(1) NOT NULL DEFAULT '0',
  `export_custom_field_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `export_custom_field_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `export_custom_field_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `export_custom_field_4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `export_custom_field_5` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `export_custom_field_6` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_group_id` int DEFAULT NULL,
  `crm_source` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crm_life_stage` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field5` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field6` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field7` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field8` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field9` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field10` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contacts_business_id_foreign` (`business_id`),
  KEY `contacts_created_by_foreign` (`created_by`),
  KEY `contacts_type_index` (`type`),
  KEY `contacts_contact_status_index` (`contact_status`),
  KEY `contacts_crm_source_index` (`crm_source`),
  KEY `contacts_crm_life_stage_index` (`crm_life_stage`),
  KEY `contacts_converted_by_index` (`converted_by`),
  CONSTRAINT `contacts_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contacts_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` VALUES (1,1,'customer',NULL,'Walk-In Customer',NULL,NULL,NULL,NULL,NULL,'CO0001','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,0.0000,1,NULL,NULL,0.0000,0,0,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-26 15:59:33','2023-01-26 15:59:33'),(2,2,'customer',NULL,'Walk-In Customer',NULL,NULL,NULL,NULL,NULL,'CO0001','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,0.0000,2,NULL,NULL,0.0000,0,0,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-26 16:42:31','2023-01-26 16:42:31'),(3,3,'customer',NULL,'Walk-In Customer',NULL,NULL,NULL,NULL,NULL,'CO0001','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,0.0000,3,NULL,NULL,0.0000,0,0,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-26 19:20:15','2023-01-26 19:20:15'),(4,3,'customer',NULL,'Rolando Espinosa',NULL,'Rolando','Espinosa',NULL,NULL,'CO0002','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'61947787',NULL,NULL,NULL,NULL,NULL,5,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-26 20:10:30','2023-01-26 20:10:30'),(5,3,'customer',NULL,'Pablo Avila',NULL,'Pablo Avila',NULL,NULL,NULL,'CO0003','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'72811380',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-26 20:12:32','2023-01-26 20:12:32'),(6,4,'customer',NULL,'Sin Cliente',NULL,'Sin Cliente',NULL,NULL,NULL,'CO0001','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,0.0000,6,NULL,NULL,0.0000,0,0,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-26 20:28:14','2023-03-29 11:41:32'),(7,3,'customer',NULL,'Claudia',NULL,'Claudia',NULL,NULL,NULL,'CO0004','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'69403136',NULL,NULL,NULL,NULL,NULL,5,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 10:29:25','2023-01-27 10:29:25'),(8,3,'customer',NULL,'Jorge',NULL,'Jorge',NULL,NULL,NULL,'CO0005','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'72632128',NULL,NULL,NULL,NULL,NULL,5,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:01:32','2023-01-27 16:01:32'),(9,3,'customer',NULL,' cliente 4 febrero  ',NULL,'cliente 4 febrero',NULL,NULL,NULL,'CO0006','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'72830309',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(10,3,'customer',NULL,' jose antelo  ',NULL,'jose antelo',NULL,NULL,NULL,'CO0007','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'69392900',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(11,3,'customer',NULL,' Erick Mauricio  ',NULL,'Erick Mauricio',NULL,NULL,NULL,'CO0008','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'77849500',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(12,3,'customer',NULL,' Silvestre Ende  ',NULL,'Silvestre Ende',NULL,NULL,NULL,'CO0009','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'60720524',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(13,3,'customer',NULL,' Luis Callau  ',NULL,'Luis Callau',NULL,NULL,NULL,'CO0010','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'69368956',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(14,3,'customer',NULL,' paul  ',NULL,'paul',NULL,NULL,NULL,'CO0011','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'69388188',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(15,3,'customer',NULL,' Eduardo Melgar  ',NULL,'Eduardo Melgar',NULL,NULL,NULL,'CO0012','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'71147572',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(16,3,'customer',NULL,' Jcell  ',NULL,'Jcell',NULL,NULL,NULL,'CO0013','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'72819000',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(17,3,'customer',NULL,' Kevin  ',NULL,'Kevin',NULL,NULL,NULL,'CO0014','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'76853626',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(18,3,'customer',NULL,' Andres Menacho  ',NULL,'Andres Menacho',NULL,NULL,NULL,'CO0015','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'73605848',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(19,3,'customer',NULL,' Paris Guzman  ',NULL,'Paris Guzman',NULL,NULL,NULL,'CO0016','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'70857375',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(20,3,'customer',NULL,' Chichito  ',NULL,'Chichito',NULL,NULL,NULL,'CO0017','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'78742228',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(21,3,'customer',NULL,' Copernico  ',NULL,'Copernico',NULL,NULL,NULL,'CO0018','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'76106148',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(22,3,'customer',NULL,' Eduardo  ',NULL,'Eduardo',NULL,NULL,NULL,'CO0019','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'78285174',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(23,3,'customer',NULL,' Zamarita  ',NULL,'Zamarita',NULL,NULL,NULL,'CO0020','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'73909698',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(24,3,'customer',NULL,' Silvia  ',NULL,'Silvia',NULL,NULL,NULL,'CO0021','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'75890777',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(25,3,'customer',NULL,' Mauri  ',NULL,'Mauri',NULL,NULL,NULL,'CO0022','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'70261501',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(26,3,'customer',NULL,' LISAD  ',NULL,'LISAD',NULL,NULL,NULL,'CO0023','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'75055133',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(27,3,'customer',NULL,' Richard Cambara  ',NULL,'Richard Cambara',NULL,NULL,NULL,'CO0024','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'72825701',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(28,3,'customer',NULL,' Luis Salvador  ',NULL,'Luis Salvador',NULL,NULL,NULL,'CO0025','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'72838376',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(29,3,'customer',NULL,' Jarandilla  ',NULL,'Jarandilla',NULL,NULL,NULL,'CO0026','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'77834290',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(30,3,'customer',NULL,' Rodríguez  ',NULL,'Rodríguez',NULL,NULL,NULL,'CO0027','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'75063696',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(31,3,'customer',NULL,' Samuel Rodriguez  ',NULL,'Samuel Rodriguez',NULL,NULL,NULL,'CO0028','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'70276844',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(32,3,'customer',NULL,' Edward Bruckner  ',NULL,'Edward Bruckner',NULL,NULL,NULL,'CO0029','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'72844032',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(33,3,'customer',NULL,' Jonathan Chavez  ',NULL,'Jonathan Chavez',NULL,NULL,NULL,'CO0030','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'70269362',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(34,3,'customer',NULL,' Jaime Carvalho Villavicencio  ',NULL,'Jaime Carvalho Villavicencio',NULL,NULL,NULL,'CO0031','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'72841190',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(35,3,'customer',NULL,' Silvio  ',NULL,'Silvio',NULL,NULL,NULL,'CO0032','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'76861689',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(36,3,'customer',NULL,' Gardenia  ',NULL,'Gardenia',NULL,NULL,NULL,'CO0033','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'69398111',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(37,3,'customer',NULL,' Janaina Aguilera  ',NULL,'Janaina Aguilera',NULL,NULL,NULL,'CO0034','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'78652462',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(38,3,'customer',NULL,' Andres Alvarado  ',NULL,'Andres Alvarado',NULL,NULL,NULL,'CO0035','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'71118220',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(39,3,'customer',NULL,' Nicolás Vargas Falso  ',NULL,'Nicolás Vargas Falso',NULL,NULL,NULL,'CO0036','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'71128748',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(40,3,'customer',NULL,' Favio Emerson Honda  ',NULL,'Favio Emerson Honda',NULL,NULL,NULL,'CO0037','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'71130523',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(41,3,'customer',NULL,' Frause  ',NULL,'Frause',NULL,NULL,NULL,'CO0038','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'72810560',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(42,3,'customer',NULL,' Katy Aranibar  ',NULL,'Katy Aranibar',NULL,NULL,NULL,'CO0039','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'77075524',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(43,3,'customer',NULL,' Boutique Caramelo  ',NULL,'Boutique Caramelo',NULL,NULL,NULL,'CO0040','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'71130523',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(44,3,'customer',NULL,' Ariel  ',NULL,'Ariel',NULL,NULL,NULL,'CO0041','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'72555556',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(45,3,'customer',NULL,' Gonzalo  ',NULL,'Gonzalo',NULL,NULL,NULL,'CO0042','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'65324029',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(46,3,'customer',NULL,' Melo  ',NULL,'Melo',NULL,NULL,NULL,'CO0043','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'76662480',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(47,3,'customer',NULL,' Angel  ',NULL,'Angel',NULL,NULL,NULL,'CO0044','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'75013600',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(48,3,'customer',NULL,' Glenar - Prada  ',NULL,'Glenar - Prada',NULL,NULL,NULL,'CO0045','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'77466577',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(49,3,'customer',NULL,' DRM  ',NULL,'DRM',NULL,NULL,NULL,'CO0046','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'63779005',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(50,3,'customer',NULL,' GUADUAY  ',NULL,'GUADUAY',NULL,NULL,NULL,'CO0047','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'67869568',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(51,3,'customer',NULL,' Dixon  ',NULL,'Dixon',NULL,NULL,NULL,'CO0048','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'72830404',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(52,3,'customer',NULL,' El Buen Samaritano  ',NULL,'El Buen Samaritano',NULL,NULL,NULL,'CO0049','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'78746621',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(53,3,'customer',NULL,' Boutique Caramelo  ',NULL,'Boutique Caramelo',NULL,NULL,NULL,'CO0050','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'77840456',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(54,3,'customer',NULL,' José Carlos Melgar  ',NULL,'José Carlos Melgar',NULL,NULL,NULL,'CO0051','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'72839452',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(55,3,'customer',NULL,' Guzmán  ',NULL,'Guzmán',NULL,NULL,NULL,'CO0052','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'70857375',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(56,3,'customer',NULL,' Dario Aponte  ',NULL,'Dario Aponte',NULL,NULL,NULL,'CO0053','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'70270755',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(57,3,'customer',NULL,' Camila  ',NULL,'Camila',NULL,NULL,NULL,'CO0054','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'75896532',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(58,3,'customer',NULL,' willy  ',NULL,'willy',NULL,NULL,NULL,'CO0055','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'70871268',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(59,3,'customer',NULL,' Ricardo  ',NULL,'Ricardo',NULL,NULL,NULL,'CO0056','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'72843418',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(60,3,'customer',NULL,' Yulisa Cuellar Becerra  ',NULL,'Yulisa Cuellar Becerra',NULL,NULL,NULL,'CO0057','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'69870334',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(61,3,'customer',NULL,' Luana Aguilera  ',NULL,'Luana Aguilera',NULL,NULL,NULL,'CO0058','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'645730355',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(62,3,'customer',NULL,' Raul Alejandro Rodriguez  ',NULL,'Raul Alejandro Rodriguez',NULL,NULL,NULL,'CO0059','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'71331001',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(63,3,'customer',NULL,' Elias  ',NULL,'Elias',NULL,NULL,NULL,'CO0060','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'67088630',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(64,3,'customer',NULL,' Coco Univ Civil  ',NULL,'Coco Univ Civil',NULL,NULL,NULL,'CO0061','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'76860035',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(65,3,'customer',NULL,' Dario  ',NULL,'Dario',NULL,NULL,NULL,'CO0062','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'75899900',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(66,3,'customer',NULL,' Jose  ',NULL,'Jose',NULL,NULL,NULL,'CO0063','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'62930187',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(67,3,'customer',NULL,' Ines  ',NULL,'Ines',NULL,NULL,NULL,'CO0064','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'67891847',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(68,3,'customer',NULL,' Lopez  ',NULL,'Lopez',NULL,NULL,NULL,'CO0065','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'70262422',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(69,3,'customer',NULL,' Richy  ',NULL,'Richy',NULL,NULL,NULL,'CO0066','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'62980188',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(70,3,'customer',NULL,' Rodolfo (Chingolas)  ',NULL,'Rodolfo (Chingolas)',NULL,NULL,NULL,'CO0067','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'73160709',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(71,3,'customer',NULL,' Luis Erik  ',NULL,'Luis Erik',NULL,NULL,NULL,'CO0068','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'70269324',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:35:10','2023-01-27 16:35:10'),(72,5,'customer',NULL,'Sin Cliente',NULL,'Sin Cliente',NULL,NULL,NULL,'CO0001','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,0.0000,8,NULL,NULL,0.0000,0,0,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-28 21:05:09','2023-03-28 23:52:49'),(73,3,'customer',NULL,'Intiruas',NULL,'Intiruas',NULL,NULL,NULL,'CO0069','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'71400471',NULL,NULL,NULL,NULL,NULL,5,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-30 10:17:46','2023-01-30 10:17:46'),(74,6,'customer',NULL,'Walk-In Customer',NULL,NULL,NULL,NULL,NULL,'CO0001','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,0.0000,9,NULL,NULL,0.0000,0,0,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-30 16:12:22','2023-01-30 16:12:22'),(75,3,'customer',NULL,'Gabriel',NULL,'Gabriel',NULL,NULL,NULL,'CO0070','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'72106864',NULL,NULL,NULL,NULL,NULL,5,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-31 10:24:39','2023-01-31 10:24:39'),(76,7,'customer',NULL,'Walk-In Customer',NULL,NULL,NULL,NULL,NULL,'CO0001','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,0.0000,10,NULL,NULL,0.0000,0,0,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-01 10:48:07','2023-02-01 10:48:07'),(77,3,'customer',NULL,'Apolo',NULL,'Apolo',NULL,NULL,NULL,'CO0071','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'63799006',NULL,NULL,NULL,NULL,NULL,5,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-03 10:48:11','2023-02-03 10:48:11'),(78,3,'customer',NULL,'Carlos Hugo Gauna',NULL,'Carlos Hugo Gauna',NULL,NULL,NULL,'CO0072','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'72814501',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-10 19:35:38','2023-02-10 19:35:38'),(79,3,'customer',NULL,'Roberto Ende',NULL,'Roberto Ende',NULL,NULL,NULL,'CO0073','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'71147407',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-10 19:39:23','2023-02-10 19:39:23'),(80,5,'customer',NULL,'luis.flores luis flores',NULL,'luis.flores','luis','flores',NULL,'CO0002','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'72823861',NULL,NULL,NULL,NULL,NULL,8,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-13 20:25:41','2023-02-13 20:25:41'),(81,5,'customer',NULL,'juan.perez',NULL,'juan.perez',NULL,NULL,NULL,'CO0003','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'71130523',NULL,NULL,NULL,NULL,NULL,8,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-13 20:48:47','2023-02-13 20:48:47'),(82,8,'customer',NULL,'Walk-In Customer',NULL,NULL,NULL,NULL,NULL,'CO0001','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,0.0000,12,NULL,NULL,0.0000,0,0,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-15 09:06:18','2023-02-15 09:06:18'),(83,9,'customer',NULL,'Walk-In Customer',NULL,NULL,NULL,NULL,NULL,'CO0001','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,0.0000,14,NULL,NULL,0.0000,0,0,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-06 13:58:51','2023-03-06 13:58:51'),(84,10,'customer',NULL,'Sin Cliente',NULL,'Sin Cliente',NULL,NULL,NULL,'CO0001','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,0.0000,15,NULL,NULL,0.0000,0,0,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-21 16:07:24','2023-03-28 23:29:36'),(85,10,'customer',NULL,'Percy Alvarez',NULL,'Percy',NULL,'Alvarez',NULL,'CO0002','active','5619016018',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'71130523',NULL,NULL,NULL,NULL,NULL,15,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-21 16:46:26','2023-03-21 16:46:26'),(86,10,'customer',NULL,'Luis Flores',NULL,'Luis',NULL,'Flores',NULL,'CO0003','active','5619015715',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'72823861',NULL,NULL,NULL,NULL,NULL,15,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-28 23:28:56','2023-03-22 11:34:22','2023-03-28 23:28:56'),(87,11,'customer',NULL,'Walk-In Customer',NULL,NULL,NULL,NULL,NULL,'CO0001','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,0.0000,16,NULL,NULL,0.0000,0,0,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-22 12:12:28','2023-03-22 12:12:28'),(88,5,'supplier','rosdem','',NULL,NULL,NULL,NULL,NULL,'CO0004','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'0',NULL,NULL,NULL,8,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-29 11:07:03','2023-03-29 11:07:03'),(89,5,'supplier','mi empresa','',NULL,NULL,NULL,NULL,NULL,'CO0005','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,8,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-29 11:07:26','2023-03-29 11:07:26'),(90,5,'supplier','rosdem','',NULL,NULL,NULL,NULL,NULL,'CO0006','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,8,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-29 11:08:16','2023-03-29 11:08:16'),(91,4,'supplier','Mi Proveedor','',NULL,NULL,NULL,NULL,NULL,'CO0002','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,6,NULL,NULL,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-29 13:42:38','2023-03-29 13:42:38');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `crm_call_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_call_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `call_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` int DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `duration` int DEFAULT NULL,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `crm_call_logs_business_id_index` (`business_id`),
  KEY `crm_call_logs_user_id_index` (`user_id`),
  KEY `crm_call_logs_contact_id_index` (`contact_id`),
  KEY `crm_call_logs_created_by_index` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `crm_call_logs` WRITE;
/*!40000 ALTER TABLE `crm_call_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_call_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `crm_campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_campaigns` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_type` enum('sms','email') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'email',
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_body` text COLLATE utf8mb4_unicode_ci,
  `sms_body` text COLLATE utf8mb4_unicode_ci,
  `sent_on` datetime DEFAULT NULL,
  `contact_ids` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `additional_info` text COLLATE utf8mb4_unicode_ci,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `crm_campaigns_business_id_foreign` (`business_id`),
  KEY `crm_campaigns_created_by_index` (`created_by`),
  CONSTRAINT `crm_campaigns_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `crm_campaigns` WRITE;
/*!40000 ALTER TABLE `crm_campaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_campaigns` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `crm_followup_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_followup_invoices` (
  `follow_up_id` int NOT NULL,
  `transaction_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `crm_followup_invoices` WRITE;
/*!40000 ALTER TABLE `crm_followup_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_followup_invoices` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `crm_lead_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_lead_users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `contact_id` int unsigned NOT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `crm_lead_users_user_id_index` (`user_id`),
  KEY `crm_lead_users_contact_id_index` (`contact_id`),
  CONSTRAINT `crm_lead_users_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `crm_lead_users` WRITE;
/*!40000 ALTER TABLE `crm_lead_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_lead_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `crm_proposal_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_proposal_templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int unsigned NOT NULL,
  `subject` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `crm_proposal_templates_business_id_foreign` (`business_id`),
  KEY `crm_proposal_templates_created_by_index` (`created_by`),
  CONSTRAINT `crm_proposal_templates_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `crm_proposal_templates` WRITE;
/*!40000 ALTER TABLE `crm_proposal_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_proposal_templates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `crm_proposals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_proposals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int unsigned NOT NULL,
  `contact_id` int unsigned NOT NULL,
  `subject` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `sent_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `crm_proposals_business_id_foreign` (`business_id`),
  KEY `crm_proposals_contact_id_foreign` (`contact_id`),
  KEY `crm_proposals_sent_by_index` (`sent_by`),
  CONSTRAINT `crm_proposals_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `crm_proposals_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `crm_proposals` WRITE;
/*!40000 ALTER TABLE `crm_proposals` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_proposals` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `crm_schedule_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_schedule_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `schedule_id` bigint unsigned NOT NULL,
  `log_type` enum('call','sms','meeting','email') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'email',
  `start_datetime` datetime NOT NULL,
  `end_datetime` datetime NOT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `crm_schedule_logs_schedule_id_foreign` (`schedule_id`),
  KEY `crm_schedule_logs_created_by_index` (`created_by`),
  CONSTRAINT `crm_schedule_logs_schedule_id_foreign` FOREIGN KEY (`schedule_id`) REFERENCES `crm_schedules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `crm_schedule_logs` WRITE;
/*!40000 ALTER TABLE `crm_schedule_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_schedule_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `crm_schedule_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_schedule_users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `schedule_id` bigint unsigned NOT NULL,
  `user_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `crm_schedule_users_schedule_id_foreign` (`schedule_id`),
  KEY `crm_schedule_users_user_id_index` (`user_id`),
  CONSTRAINT `crm_schedule_users_schedule_id_foreign` FOREIGN KEY (`schedule_id`) REFERENCES `crm_schedules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `crm_schedule_users` WRITE;
/*!40000 ALTER TABLE `crm_schedule_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_schedule_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `crm_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_schedules` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int unsigned NOT NULL,
  `contact_id` int DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_datetime` datetime DEFAULT NULL,
  `end_datetime` datetime DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `schedule_type` enum('call','sms','meeting','email') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'email',
  `allow_notification` tinyint(1) NOT NULL DEFAULT '1',
  `notify_via` text COLLATE utf8mb4_unicode_ci,
  `notify_before` int DEFAULT NULL,
  `notify_type` enum('minute','hour','day') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'hour',
  `created_by` int NOT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `recursion_days` int DEFAULT NULL,
  `followup_additional_info` text COLLATE utf8mb4_unicode_ci,
  `follow_up_by` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `follow_up_by_value` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `crm_schedules_created_by_index` (`created_by`),
  KEY `crm_schedules_business_id_index` (`business_id`),
  KEY `crm_schedules_contact_id_index` (`contact_id`),
  KEY `crm_schedules_schedule_type_index` (`schedule_type`),
  KEY `crm_schedules_notify_type_index` (`notify_type`),
  CONSTRAINT `crm_schedules_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `crm_schedules` WRITE;
/*!40000 ALTER TABLE `crm_schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_schedules` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `currencies` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `symbol` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `thousand_separator` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `decimal_separator` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=142 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `currencies` WRITE;
/*!40000 ALTER TABLE `currencies` DISABLE KEYS */;
INSERT INTO `currencies` VALUES (1,'Albania','Leke','ALL','Lek',',','.',NULL,NULL),(2,'America','Dollars','USD','$',',','.',NULL,NULL),(3,'Afghanistan','Afghanis','AF','؋',',','.',NULL,NULL),(4,'Argentina','Pesos','ARS','$',',','.',NULL,NULL),(5,'Aruba','Guilders','AWG','ƒ',',','.',NULL,NULL),(6,'Australia','Dollars','AUD','$',',','.',NULL,NULL),(7,'Azerbaijan','New Manats','AZ','ман',',','.',NULL,NULL),(8,'Bahamas','Dollars','BSD','$',',','.',NULL,NULL),(9,'Barbados','Dollars','BBD','$',',','.',NULL,NULL),(10,'Belarus','Rubles','BYR','p.',',','.',NULL,NULL),(11,'Belgium','Euro','EUR','€',',','.',NULL,NULL),(12,'Beliz','Dollars','BZD','BZ$',',','.',NULL,NULL),(13,'Bermuda','Dollars','BMD','$',',','.',NULL,NULL),(14,'Bolivia','Bolivianos','BOB','$b',',','.',NULL,NULL),(15,'Bosnia and Herzegovina','Convertible Marka','BAM','KM',',','.',NULL,NULL),(16,'Botswana','Pula\'s','BWP','P',',','.',NULL,NULL),(17,'Bulgaria','Leva','BG','лв',',','.',NULL,NULL),(18,'Brazil','Reais','BRL','R$',',','.',NULL,NULL),(19,'Britain [United Kingdom]','Pounds','GBP','£',',','.',NULL,NULL),(20,'Brunei Darussalam','Dollars','BND','$',',','.',NULL,NULL),(21,'Cambodia','Riels','KHR','៛',',','.',NULL,NULL),(22,'Canada','Dollars','CAD','$',',','.',NULL,NULL),(23,'Cayman Islands','Dollars','KYD','$',',','.',NULL,NULL),(24,'Chile','Pesos','CLP','$',',','.',NULL,NULL),(25,'China','Yuan Renminbi','CNY','¥',',','.',NULL,NULL),(26,'Colombia','Pesos','COP','$',',','.',NULL,NULL),(27,'Costa Rica','Colón','CRC','₡',',','.',NULL,NULL),(28,'Croatia','Kuna','HRK','kn',',','.',NULL,NULL),(29,'Cuba','Pesos','CUP','₱',',','.',NULL,NULL),(30,'Cyprus','Euro','EUR','€','.',',',NULL,NULL),(31,'Czech Republic','Koruny','CZK','Kč',',','.',NULL,NULL),(32,'Denmark','Kroner','DKK','kr',',','.',NULL,NULL),(33,'Dominican Republic','Pesos','DOP ','RD$',',','.',NULL,NULL),(34,'East Caribbean','Dollars','XCD','$',',','.',NULL,NULL),(35,'Egypt','Pounds','EGP','£',',','.',NULL,NULL),(36,'El Salvador','Colones','SVC','$',',','.',NULL,NULL),(37,'England [United Kingdom]','Pounds','GBP','£',',','.',NULL,NULL),(38,'Euro','Euro','EUR','€','.',',',NULL,NULL),(39,'Falkland Islands','Pounds','FKP','£',',','.',NULL,NULL),(40,'Fiji','Dollars','FJD','$',',','.',NULL,NULL),(41,'France','Euro','EUR','€','.',',',NULL,NULL),(42,'Ghana','Cedis','GHS','¢',',','.',NULL,NULL),(43,'Gibraltar','Pounds','GIP','£',',','.',NULL,NULL),(44,'Greece','Euro','EUR','€','.',',',NULL,NULL),(45,'Guatemala','Quetzales','GTQ','Q',',','.',NULL,NULL),(46,'Guernsey','Pounds','GGP','£',',','.',NULL,NULL),(47,'Guyana','Dollars','GYD','$',',','.',NULL,NULL),(48,'Holland [Netherlands]','Euro','EUR','€','.',',',NULL,NULL),(49,'Honduras','Lempiras','HNL','L',',','.',NULL,NULL),(50,'Hong Kong','Dollars','HKD','$',',','.',NULL,NULL),(51,'Hungary','Forint','HUF','Ft',',','.',NULL,NULL),(52,'Iceland','Kronur','ISK','kr',',','.',NULL,NULL),(53,'India','Rupees','INR','₹',',','.',NULL,NULL),(54,'Indonesia','Rupiahs','IDR','Rp',',','.',NULL,NULL),(55,'Iran','Rials','IRR','﷼',',','.',NULL,NULL),(56,'Ireland','Euro','EUR','€','.',',',NULL,NULL),(57,'Isle of Man','Pounds','IMP','£',',','.',NULL,NULL),(58,'Israel','New Shekels','ILS','₪',',','.',NULL,NULL),(59,'Italy','Euro','EUR','€','.',',',NULL,NULL),(60,'Jamaica','Dollars','JMD','J$',',','.',NULL,NULL),(61,'Japan','Yen','JPY','¥',',','.',NULL,NULL),(62,'Jersey','Pounds','JEP','£',',','.',NULL,NULL),(63,'Kazakhstan','Tenge','KZT','лв',',','.',NULL,NULL),(64,'Korea [North]','Won','KPW','₩',',','.',NULL,NULL),(65,'Korea [South]','Won','KRW','₩',',','.',NULL,NULL),(66,'Kyrgyzstan','Soms','KGS','лв',',','.',NULL,NULL),(67,'Laos','Kips','LAK','₭',',','.',NULL,NULL),(68,'Latvia','Lati','LVL','Ls',',','.',NULL,NULL),(69,'Lebanon','Pounds','LBP','£',',','.',NULL,NULL),(70,'Liberia','Dollars','LRD','$',',','.',NULL,NULL),(71,'Liechtenstein','Switzerland Francs','CHF','CHF',',','.',NULL,NULL),(72,'Lithuania','Litai','LTL','Lt',',','.',NULL,NULL),(73,'Luxembourg','Euro','EUR','€','.',',',NULL,NULL),(74,'Macedonia','Denars','MKD','ден',',','.',NULL,NULL),(75,'Malaysia','Ringgits','MYR','RM',',','.',NULL,NULL),(76,'Malta','Euro','EUR','€','.',',',NULL,NULL),(77,'Mauritius','Rupees','MUR','₨',',','.',NULL,NULL),(78,'Mexico','Pesos','MXN','$',',','.',NULL,NULL),(79,'Mongolia','Tugriks','MNT','₮',',','.',NULL,NULL),(80,'Mozambique','Meticais','MZ','MT',',','.',NULL,NULL),(81,'Namibia','Dollars','NAD','$',',','.',NULL,NULL),(82,'Nepal','Rupees','NPR','₨',',','.',NULL,NULL),(83,'Netherlands Antilles','Guilders','ANG','ƒ',',','.',NULL,NULL),(84,'Netherlands','Euro','EUR','€','.',',',NULL,NULL),(85,'New Zealand','Dollars','NZD','$',',','.',NULL,NULL),(86,'Nicaragua','Cordobas','NIO','C$',',','.',NULL,NULL),(87,'Nigeria','Nairas','NGN','₦',',','.',NULL,NULL),(88,'North Korea','Won','KPW','₩',',','.',NULL,NULL),(89,'Norway','Krone','NOK','kr',',','.',NULL,NULL),(90,'Oman','Rials','OMR','﷼',',','.',NULL,NULL),(91,'Pakistan','Rupees','PKR','₨',',','.',NULL,NULL),(92,'Panama','Balboa','PAB','B/.',',','.',NULL,NULL),(93,'Paraguay','Guarani','PYG','Gs',',','.',NULL,NULL),(94,'Peru','Nuevos Soles','PE','S/.',',','.',NULL,NULL),(95,'Philippines','Pesos','PHP','Php',',','.',NULL,NULL),(96,'Poland','Zlotych','PL','zł',',','.',NULL,NULL),(97,'Qatar','Rials','QAR','﷼',',','.',NULL,NULL),(98,'Romania','New Lei','RO','lei',',','.',NULL,NULL),(99,'Russia','Rubles','RUB','руб',',','.',NULL,NULL),(100,'Saint Helena','Pounds','SHP','£',',','.',NULL,NULL),(101,'Saudi Arabia','Riyals','SAR','﷼',',','.',NULL,NULL),(102,'Serbia','Dinars','RSD','Дин.',',','.',NULL,NULL),(103,'Seychelles','Rupees','SCR','₨',',','.',NULL,NULL),(104,'Singapore','Dollars','SGD','$',',','.',NULL,NULL),(105,'Slovenia','Euro','EUR','€','.',',',NULL,NULL),(106,'Solomon Islands','Dollars','SBD','$',',','.',NULL,NULL),(107,'Somalia','Shillings','SOS','S',',','.',NULL,NULL),(108,'South Africa','Rand','ZAR','R',',','.',NULL,NULL),(109,'South Korea','Won','KRW','₩',',','.',NULL,NULL),(110,'Spain','Euro','EUR','€','.',',',NULL,NULL),(111,'Sri Lanka','Rupees','LKR','₨',',','.',NULL,NULL),(112,'Sweden','Kronor','SEK','kr',',','.',NULL,NULL),(113,'Switzerland','Francs','CHF','CHF',',','.',NULL,NULL),(114,'Suriname','Dollars','SRD','$',',','.',NULL,NULL),(115,'Syria','Pounds','SYP','£',',','.',NULL,NULL),(116,'Taiwan','New Dollars','TWD','NT$',',','.',NULL,NULL),(117,'Thailand','Baht','THB','฿',',','.',NULL,NULL),(118,'Trinidad and Tobago','Dollars','TTD','TT$',',','.',NULL,NULL),(119,'Turkey','Lira','TRY','TL',',','.',NULL,NULL),(120,'Turkey','Liras','TRL','£',',','.',NULL,NULL),(121,'Tuvalu','Dollars','TVD','$',',','.',NULL,NULL),(122,'Ukraine','Hryvnia','UAH','₴',',','.',NULL,NULL),(123,'United Kingdom','Pounds','GBP','£',',','.',NULL,NULL),(124,'United States of America','Dollars','USD','$',',','.',NULL,NULL),(125,'Uruguay','Pesos','UYU','$U',',','.',NULL,NULL),(126,'Uzbekistan','Sums','UZS','лв',',','.',NULL,NULL),(127,'Vatican City','Euro','EUR','€','.',',',NULL,NULL),(128,'Venezuela','Bolivares Fuertes','VEF','Bs',',','.',NULL,NULL),(129,'Vietnam','Dong','VND','₫',',','.',NULL,NULL),(130,'Yemen','Rials','YER','﷼',',','.',NULL,NULL),(131,'Zimbabwe','Zimbabwe Dollars','ZWD','Z$',',','.',NULL,NULL),(132,'Iraq','Iraqi dinar','IQD','د.ع',',','.',NULL,NULL),(133,'Kenya','Kenyan shilling','KES','KSh',',','.',NULL,NULL),(134,'Bangladesh','Taka','BDT','৳',',','.',NULL,NULL),(135,'Algerie','Algerian dinar','DZD','د.ج',' ','.',NULL,NULL),(136,'United Arab Emirates','United Arab Emirates dirham','AED','د.إ',',','.',NULL,NULL),(137,'Uganda','Uganda shillings','UGX','USh',',','.',NULL,NULL),(138,'Tanzania','Tanzanian shilling','TZS','TSh',',','.',NULL,NULL),(139,'Angola','Kwanza','AOA','Kz',',','.',NULL,NULL),(140,'Kuwait','Kuwaiti dinar','KWD','KD',',','.',NULL,NULL),(141,'Bahrain','Bahraini dinar','BHD','BD',',','.',NULL,NULL);
/*!40000 ALTER TABLE `currencies` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `customer_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_groups` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double(5,2) NOT NULL,
  `price_calculation_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'percentage',
  `selling_price_group_id` int DEFAULT NULL,
  `created_by` int unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_groups_business_id_foreign` (`business_id`),
  KEY `customer_groups_created_by_index` (`created_by`),
  KEY `customer_groups_price_calculation_type_index` (`price_calculation_type`),
  KEY `customer_groups_selling_price_group_id_index` (`selling_price_group_id`),
  CONSTRAINT `customer_groups_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `customer_groups` WRITE;
/*!40000 ALTER TABLE `customer_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_groups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `dashboard_configurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard_configurations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int unsigned NOT NULL,
  `created_by` int NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `configuration` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dashboard_configurations_business_id_foreign` (`business_id`),
  CONSTRAINT `dashboard_configurations_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `dashboard_configurations` WRITE;
/*!40000 ALTER TABLE `dashboard_configurations` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard_configurations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `discount_variations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `discount_variations` (
  `discount_id` int NOT NULL,
  `variation_id` int NOT NULL,
  KEY `discount_variations_discount_id_index` (`discount_id`),
  KEY `discount_variations_variation_id_index` (`variation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `discount_variations` WRITE;
/*!40000 ALTER TABLE `discount_variations` DISABLE KEYS */;
/*!40000 ALTER TABLE `discount_variations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `discounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `discounts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int NOT NULL,
  `brand_id` int DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  `location_id` int DEFAULT NULL,
  `priority` int DEFAULT NULL,
  `discount_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_amount` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `starts_at` datetime DEFAULT NULL,
  `ends_at` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `spg` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Applicable in specified selling price group only. Use of applicable_in_spg column is discontinued',
  `applicable_in_cg` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discounts_business_id_index` (`business_id`),
  KEY `discounts_brand_id_index` (`brand_id`),
  KEY `discounts_category_id_index` (`category_id`),
  KEY `discounts_location_id_index` (`location_id`),
  KEY `discounts_priority_index` (`priority`),
  KEY `discounts_spg_index` (`spg`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `discounts` WRITE;
/*!40000 ALTER TABLE `discounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `discounts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `document_and_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_and_notes` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int NOT NULL,
  `notable_id` int NOT NULL,
  `notable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `heading` text COLLATE utf8mb4_unicode_ci,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `document_and_notes_business_id_index` (`business_id`),
  KEY `document_and_notes_notable_id_index` (`notable_id`),
  KEY `document_and_notes_created_by_index` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `document_and_notes` WRITE;
/*!40000 ALTER TABLE `document_and_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `document_and_notes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_allowances_and_deductions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `essentials_allowances_and_deductions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('allowance','deduction') COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(22,4) NOT NULL,
  `amount_type` enum('fixed','percent') COLLATE utf8mb4_unicode_ci NOT NULL,
  `applicable_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_allowances_and_deductions_business_id_index` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_allowances_and_deductions` WRITE;
/*!40000 ALTER TABLE `essentials_allowances_and_deductions` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_allowances_and_deductions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_attendances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `essentials_attendances` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `business_id` int NOT NULL,
  `clock_in_time` datetime DEFAULT NULL,
  `clock_out_time` datetime DEFAULT NULL,
  `essentials_shift_id` int DEFAULT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `clock_in_note` text COLLATE utf8mb4_unicode_ci,
  `clock_out_note` text COLLATE utf8mb4_unicode_ci,
  `clock_in_location` text COLLATE utf8mb4_unicode_ci,
  `clock_out_location` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_attendances_user_id_index` (`user_id`),
  KEY `essentials_attendances_business_id_index` (`business_id`),
  KEY `essentials_attendances_essentials_shift_id_index` (`essentials_shift_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_attendances` WRITE;
/*!40000 ALTER TABLE `essentials_attendances` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_attendances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_document_shares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `essentials_document_shares` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `document_id` int NOT NULL,
  `value_type` enum('user','role') COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_document_shares_document_id_index` (`document_id`),
  KEY `essentials_document_shares_value_type_index` (`value_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_document_shares` WRITE;
/*!40000 ALTER TABLE `essentials_document_shares` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_document_shares` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `essentials_documents` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int NOT NULL,
  `user_id` int NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_documents` WRITE;
/*!40000 ALTER TABLE `essentials_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_documents` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `essentials_holidays` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `business_id` int NOT NULL,
  `location_id` int DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_holidays_business_id_index` (`business_id`),
  KEY `essentials_holidays_location_id_index` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_holidays` WRITE;
/*!40000 ALTER TABLE `essentials_holidays` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_holidays` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_kb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `essentials_kb` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `business_id` bigint unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kb_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` bigint unsigned DEFAULT NULL COMMENT 'id from essentials_kb table',
  `share_with` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'public, private, only_with',
  `created_by` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_kb_business_id_index` (`business_id`),
  KEY `essentials_kb_parent_id_index` (`parent_id`),
  KEY `essentials_kb_created_by_index` (`created_by`),
  CONSTRAINT `essentials_kb_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `essentials_kb` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_kb` WRITE;
/*!40000 ALTER TABLE `essentials_kb` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_kb` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_kb_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `essentials_kb_users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `kb_id` int NOT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_kb_users_kb_id_index` (`kb_id`),
  KEY `essentials_kb_users_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_kb_users` WRITE;
/*!40000 ALTER TABLE `essentials_kb_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_kb_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_leave_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `essentials_leave_types` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `leave_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `max_leave_count` int DEFAULT NULL,
  `leave_count_interval` enum('month','year') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_leave_types_business_id_index` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_leave_types` WRITE;
/*!40000 ALTER TABLE `essentials_leave_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_leave_types` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_leaves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `essentials_leaves` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `essentials_leave_type_id` int DEFAULT NULL,
  `business_id` int NOT NULL,
  `user_id` int NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `ref_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','approved','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `status_note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_leaves_essentials_leave_type_id_index` (`essentials_leave_type_id`),
  KEY `essentials_leaves_business_id_index` (`business_id`),
  KEY `essentials_leaves_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_leaves` WRITE;
/*!40000 ALTER TABLE `essentials_leaves` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_leaves` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `essentials_messages` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int NOT NULL,
  `user_id` int NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_messages_business_id_index` (`business_id`),
  KEY `essentials_messages_user_id_index` (`user_id`),
  KEY `essentials_messages_location_id_index` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_messages` WRITE;
/*!40000 ALTER TABLE `essentials_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_messages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `essentials_reminders` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int NOT NULL,
  `user_id` int NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `end_time` time DEFAULT NULL,
  `repeat` enum('one_time','every_day','every_week','every_month') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_reminders_business_id_index` (`business_id`),
  KEY `essentials_reminders_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_reminders` WRITE;
/*!40000 ALTER TABLE `essentials_reminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_reminders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_shifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `essentials_shifts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('fixed_shift','flexible_shift') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fixed_shift',
  `business_id` int NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `holidays` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_shifts_type_index` (`type`),
  KEY `essentials_shifts_business_id_index` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_shifts` WRITE;
/*!40000 ALTER TABLE `essentials_shifts` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_shifts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_to_dos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `essentials_to_dos` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int NOT NULL,
  `task` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `task_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estimated_hours` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priority` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_to_dos_status_index` (`status`),
  KEY `essentials_to_dos_priority_index` (`priority`),
  KEY `essentials_to_dos_created_by_index` (`created_by`),
  KEY `essentials_to_dos_business_id_index` (`business_id`),
  KEY `essentials_to_dos_task_id_index` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_to_dos` WRITE;
/*!40000 ALTER TABLE `essentials_to_dos` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_to_dos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_todo_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `essentials_todo_comments` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `task_id` int NOT NULL,
  `comment_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_todo_comments_task_id_index` (`task_id`),
  KEY `essentials_todo_comments_comment_by_index` (`comment_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_todo_comments` WRITE;
/*!40000 ALTER TABLE `essentials_todo_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_todo_comments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_todos_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `essentials_todos_users` (
  `todo_id` int NOT NULL,
  `user_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_todos_users` WRITE;
/*!40000 ALTER TABLE `essentials_todos_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_todos_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_user_allowance_and_deductions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `essentials_user_allowance_and_deductions` (
  `user_id` int NOT NULL,
  `allowance_deduction_id` int NOT NULL,
  KEY `essentials_user_allowance_and_deductions_user_id_index` (`user_id`),
  KEY `allow_deduct_index` (`allowance_deduction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_user_allowance_and_deductions` WRITE;
/*!40000 ALTER TABLE `essentials_user_allowance_and_deductions` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_user_allowance_and_deductions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_user_shifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `essentials_user_shifts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `essentials_shift_id` int NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_user_shifts_user_id_index` (`user_id`),
  KEY `essentials_user_shifts_essentials_shift_id_index` (`essentials_shift_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_user_shifts` WRITE;
/*!40000 ALTER TABLE `essentials_user_shifts` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_user_shifts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `expense_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expense_categories` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int unsigned NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `expense_categories_business_id_foreign` (`business_id`),
  CONSTRAINT `expense_categories_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `expense_categories` WRITE;
/*!40000 ALTER TABLE `expense_categories` DISABLE KEYS */;
INSERT INTO `expense_categories` VALUES (1,'Inversion Buen Samaritano',3,NULL,NULL,'2023-01-26 19:37:32','2023-01-26 19:37:32'),(2,'Gastos Varios',3,NULL,NULL,'2023-01-31 10:25:28','2023-01-31 10:25:28'),(3,'Pago de Beneficios',3,NULL,NULL,'2023-01-31 10:36:27','2023-01-31 10:36:27'),(4,'Compra Celular',3,NULL,NULL,'2023-02-03 14:23:00','2023-02-03 14:23:00'),(5,'Hosting y Dominio',3,NULL,NULL,'2023-02-10 19:47:16','2023-02-10 19:47:16');
/*!40000 ALTER TABLE `expense_categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `group_sub_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_sub_taxes` (
  `group_tax_id` int unsigned NOT NULL,
  `tax_id` int unsigned NOT NULL,
  KEY `group_sub_taxes_group_tax_id_foreign` (`group_tax_id`),
  KEY `group_sub_taxes_tax_id_foreign` (`tax_id`),
  CONSTRAINT `group_sub_taxes_group_tax_id_foreign` FOREIGN KEY (`group_tax_id`) REFERENCES `tax_rates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `group_sub_taxes_tax_id_foreign` FOREIGN KEY (`tax_id`) REFERENCES `tax_rates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `group_sub_taxes` WRITE;
/*!40000 ALTER TABLE `group_sub_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_sub_taxes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `invoice_layouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_layouts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `header_text` text COLLATE utf8mb4_unicode_ci,
  `invoice_no_prefix` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quotation_no_prefix` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_heading` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_heading_line1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_heading_line2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_heading_line3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_heading_line4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_heading_line5` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_heading_not_paid` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_heading_paid` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quotation_heading` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_total_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `round_off_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_due_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_client_id` tinyint(1) NOT NULL DEFAULT '0',
  `client_id_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_tax_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_time_format` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_time` tinyint(1) NOT NULL DEFAULT '1',
  `show_brand` tinyint(1) NOT NULL DEFAULT '0',
  `show_sku` tinyint(1) NOT NULL DEFAULT '1',
  `show_cat_code` tinyint(1) NOT NULL DEFAULT '1',
  `show_expiry` tinyint(1) NOT NULL DEFAULT '0',
  `show_lot` tinyint(1) NOT NULL DEFAULT '0',
  `show_image` tinyint(1) NOT NULL DEFAULT '0',
  `show_sale_description` tinyint(1) NOT NULL DEFAULT '0',
  `sales_person_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_sales_person` tinyint(1) NOT NULL DEFAULT '0',
  `table_product_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `table_qty_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `table_unit_price_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `table_subtotal_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cat_code_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_logo` tinyint(1) NOT NULL DEFAULT '0',
  `show_business_name` tinyint(1) NOT NULL DEFAULT '0',
  `show_location_name` tinyint(1) NOT NULL DEFAULT '1',
  `show_landmark` tinyint(1) NOT NULL DEFAULT '1',
  `show_city` tinyint(1) NOT NULL DEFAULT '1',
  `show_state` tinyint(1) NOT NULL DEFAULT '1',
  `show_zip_code` tinyint(1) NOT NULL DEFAULT '1',
  `show_country` tinyint(1) NOT NULL DEFAULT '1',
  `show_mobile_number` tinyint(1) NOT NULL DEFAULT '1',
  `show_alternate_number` tinyint(1) NOT NULL DEFAULT '0',
  `show_email` tinyint(1) NOT NULL DEFAULT '0',
  `show_tax_1` tinyint(1) NOT NULL DEFAULT '1',
  `show_tax_2` tinyint(1) NOT NULL DEFAULT '0',
  `show_barcode` tinyint(1) NOT NULL DEFAULT '0',
  `show_payments` tinyint(1) NOT NULL DEFAULT '0',
  `show_customer` tinyint(1) NOT NULL DEFAULT '0',
  `customer_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commission_agent_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_commission_agent` tinyint(1) NOT NULL DEFAULT '0',
  `show_reward_point` tinyint(1) NOT NULL DEFAULT '0',
  `highlight_color` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_text` text COLLATE utf8mb4_unicode_ci,
  `module_info` text COLLATE utf8mb4_unicode_ci,
  `common_settings` text COLLATE utf8mb4_unicode_ci,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `business_id` int unsigned NOT NULL,
  `show_qr_code` tinyint(1) NOT NULL DEFAULT '0',
  `qr_code_fields` text COLLATE utf8mb4_unicode_ci,
  `design` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT 'classic',
  `cn_heading` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'cn = credit note',
  `cn_no_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cn_amount_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `table_tax_headings` text COLLATE utf8mb4_unicode_ci,
  `show_previous_bal` tinyint(1) NOT NULL DEFAULT '0',
  `prev_bal_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `change_return_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_custom_fields` text COLLATE utf8mb4_unicode_ci,
  `contact_custom_fields` text COLLATE utf8mb4_unicode_ci,
  `location_custom_fields` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_layouts_business_id_foreign` (`business_id`),
  CONSTRAINT `invoice_layouts_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `invoice_layouts` WRITE;
/*!40000 ALTER TABLE `invoice_layouts` DISABLE KEYS */;
INSERT INTO `invoice_layouts` VALUES (1,'Default',NULL,'Invoice No.',NULL,'Invoice',NULL,NULL,NULL,NULL,NULL,'','',NULL,'Subtotal','Discount','Tax','Total',NULL,'Total Due','Total Paid',0,NULL,NULL,'Date',NULL,1,0,1,1,0,0,0,0,NULL,0,'Product','Quantity','Unit Price','Subtotal',NULL,NULL,0,0,1,1,1,1,1,1,1,0,0,1,0,0,1,1,'Customer',NULL,0,0,'#000000','',NULL,NULL,1,1,0,NULL,'classic',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2023-01-26 15:59:33','2023-01-26 15:59:33'),(2,'Default',NULL,'Invoice No.',NULL,'Invoice',NULL,NULL,NULL,NULL,NULL,'','',NULL,'Subtotal','Discount','Tax','Total',NULL,'Total Due','Total Paid',0,NULL,NULL,'Date',NULL,1,0,1,1,0,0,0,0,NULL,0,'Product','Quantity','Unit Price','Subtotal',NULL,NULL,0,0,1,1,1,1,1,1,1,0,0,1,0,0,1,1,'Customer',NULL,0,0,'#000000','',NULL,NULL,1,2,0,NULL,'classic',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2023-01-26 16:42:31','2023-01-26 16:42:31'),(3,'Default',NULL,'Venta º',NULL,'Venta',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Subtotal','Descuento','Impuesto','Total',NULL,'Total Adeudado','Total Pagado',0,NULL,NULL,'Fecha',NULL,1,0,0,0,0,0,0,0,NULL,0,'Producto','Cantidad','Precio Unitario','Subtotal',NULL,'1675089102_shopteclogo.png',1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,'Cliente',NULL,0,0,'#000000',NULL,NULL,'{\"proforma_heading\":null,\"due_date_label\":null,\"total_quantity_label\":null,\"item_discount_label\":null,\"num_to_word_format\":\"international\"}',1,3,0,NULL,'slim2',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2023-01-26 19:20:15','2023-01-30 11:32:24'),(4,'Recibo',NULL,'Invoice No.',NULL,'Invoice',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Subtotal','Discount','Tax','Total',NULL,'Total Due','Total Paid',0,NULL,NULL,'Date',NULL,1,0,1,1,0,0,0,0,NULL,0,'Product','Quantity','Unit Price','Subtotal',NULL,NULL,0,0,1,1,1,1,1,1,1,0,0,1,0,0,1,1,'Customer',NULL,0,0,'#000000',NULL,NULL,'{\"proforma_heading\":null,\"due_date_label\":null,\"total_quantity_label\":null,\"item_discount_label\":null,\"num_to_word_format\":\"international\"}',1,4,0,NULL,'slim2',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2023-01-26 20:28:14','2023-03-29 14:01:51'),(5,'Default',NULL,'Invoice No.',NULL,'Invoice',NULL,NULL,NULL,NULL,NULL,'','',NULL,'Subtotal','Discount','Tax','Total',NULL,'Total Due','Total Paid',0,NULL,NULL,'Date',NULL,1,0,1,1,0,0,0,0,NULL,0,'Product','Quantity','Unit Price','Subtotal',NULL,NULL,0,0,1,1,1,1,1,1,1,0,0,1,0,0,1,1,'Customer',NULL,0,0,'#000000','',NULL,NULL,1,5,0,NULL,'classic',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2023-01-28 21:05:09','2023-01-28 21:05:09'),(6,'Default',NULL,'Invoice No.',NULL,'Invoice',NULL,NULL,NULL,NULL,NULL,'','',NULL,'Subtotal','Discount','Tax','Total',NULL,'Total Due','Total Paid',0,NULL,NULL,'Date',NULL,1,0,1,1,0,0,0,0,NULL,0,'Product','Quantity','Unit Price','Subtotal',NULL,NULL,0,0,1,1,1,1,1,1,1,0,0,1,0,0,1,1,'Customer',NULL,0,0,'#000000','',NULL,NULL,1,6,0,NULL,'classic',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2023-01-30 16:12:22','2023-01-30 16:12:22'),(7,'Default',NULL,'Invoice No.',NULL,'Invoice',NULL,NULL,NULL,NULL,NULL,'','',NULL,'Subtotal','Discount','Tax','Total',NULL,'Total Due','Total Paid',0,NULL,NULL,'Date',NULL,1,0,1,1,0,0,0,0,NULL,0,'Product','Quantity','Unit Price','Subtotal',NULL,NULL,0,0,1,1,1,1,1,1,1,0,0,1,0,0,1,1,'Customer',NULL,0,0,'#000000','',NULL,NULL,1,7,0,NULL,'classic',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2023-02-01 10:48:07','2023-02-01 10:48:07'),(8,'Default',NULL,'Invoice No.',NULL,'Invoice',NULL,NULL,NULL,NULL,NULL,'','',NULL,'Subtotal','Discount','Tax','Total',NULL,'Total Due','Total Paid',0,NULL,NULL,'Date',NULL,1,0,1,1,0,0,0,0,NULL,0,'Product','Quantity','Unit Price','Subtotal',NULL,NULL,0,0,1,1,1,1,1,1,1,0,0,1,0,0,1,1,'Customer',NULL,0,0,'#000000','',NULL,NULL,1,8,0,NULL,'classic',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2023-02-15 09:06:18','2023-02-15 09:06:18'),(9,'Default',NULL,'Invoice No.',NULL,'Invoice',NULL,NULL,NULL,NULL,NULL,'','',NULL,'Subtotal','Discount','Tax','Total',NULL,'Total Due','Total Paid',0,NULL,NULL,'Date',NULL,1,0,1,1,0,0,0,0,NULL,0,'Product','Quantity','Unit Price','Subtotal',NULL,NULL,0,0,1,1,1,1,1,1,1,0,0,1,0,0,1,1,'Customer',NULL,0,0,'#000000','',NULL,NULL,1,9,0,NULL,'classic',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2023-03-06 13:58:51','2023-03-06 13:58:51'),(10,'Factura','<h6 style=\"text-align: center;\">SAAVEDRA JALIRI ALEJANDRA<br />7926141018<br />AVENIDA GRAN PAITITI NRO. S/N ZONA/BARRIO: SAN VICENTE - TRINIDAD</h6>','Factura No.',NULL,'Recibo',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Subtotal','Descuento','Tax','Total',NULL,'Total Due','Total Pagado',0,NULL,'NIT','Fecha',NULL,1,0,0,0,0,0,0,0,NULL,0,'Producto','Cantidad','Precio','Subtotal',NULL,'1679432742_invoice-line-icon-logo-illustration-free-vector.webp',1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,'Cliente',NULL,0,0,'#000000',NULL,NULL,'{\"proforma_heading\":\"Recibo\",\"due_date_label\":null,\"total_quantity_label\":null,\"item_discount_label\":null,\"show_total_in_words\":\"1\",\"num_to_word_format\":\"international\"}',0,10,1,'[\"business_name\",\"address\",\"invoice_no\",\"invoice_datetime\",\"total_tax\",\"customer_name\",\"invoice_url\"]','slim2',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2023-03-21 16:07:24','2023-03-21 19:32:51'),(11,'Recibo',NULL,'Recibo no.','Número de cotización','|',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Cotización','Subtotal','Descuento','Impuesto','Total','Redondear','Debido','Total pagado',0,NULL,NULL,'Fecha',NULL,1,0,0,0,0,0,0,0,'Atendido por:',0,'Producto','Cant','Precio','Total','HSN',NULL,0,1,0,0,1,1,0,1,1,0,0,0,0,0,1,1,'Cliente','Comisionista',0,0,'#000000',NULL,NULL,'{\"proforma_heading\":\"Proforma\",\"due_date_label\":\"Fecha de vencimiento\",\"total_quantity_label\":\"Total Cantidad\",\"item_discount_label\":null,\"show_total_in_words\":\"1\",\"num_to_word_format\":\"international\"}',1,10,0,NULL,'slim','Credit Note','Numero de referencia','Credit Amount',NULL,0,NULL,'Cambio',NULL,NULL,NULL,'2023-03-21 18:43:15','2023-03-21 19:46:36'),(12,'Recibo',NULL,'Invoice No.',NULL,'|',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Subtotal','Discount','Tax','Total',NULL,'Total Due','Total Paid',0,NULL,NULL,'Date',NULL,1,0,0,0,0,0,0,0,NULL,0,'Producto','Cant','Precio',NULL,NULL,NULL,0,0,1,0,1,1,0,1,1,0,0,0,0,0,1,1,'Customer',NULL,0,0,'#000000',NULL,NULL,'{\"proforma_heading\":null,\"due_date_label\":null,\"total_quantity_label\":null,\"item_discount_label\":null,\"num_to_word_format\":\"international\"}',1,11,0,NULL,'classic',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2023-03-22 12:12:28','2023-03-22 12:20:21'),(13,'Factura',NULL,'Factura no.','Número de cotización','|',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Cotización','Subtotal','Descuento','Impuesto','Total','Redondear','Debido','Total pagado',0,NULL,NULL,'Fecha',NULL,1,0,0,0,0,0,0,0,NULL,0,'Producto','Cant','Precio',NULL,'HSN',NULL,0,0,0,0,1,1,0,1,1,0,0,0,0,0,1,1,'Cliente','Comisionista',0,0,'#000000',NULL,NULL,'{\"proforma_heading\":\"Factura de proforma\",\"due_date_label\":\"Fecha de vencimiento\",\"total_quantity_label\":\"Total Quantity\",\"item_discount_label\":\"Discount\",\"num_to_word_format\":\"international\"}',0,11,1,'[\"business_name\",\"address\",\"invoice_no\",\"invoice_datetime\",\"subtotal\",\"customer_name\",\"invoice_url\"]','slim2','Credit Note','Numero de referencia','Credit Amount',NULL,0,NULL,'Cambiar el retorno',NULL,NULL,NULL,'2023-03-22 12:21:56','2023-03-22 12:21:56'),(14,'Factura',NULL,'Factura no.','Número de cotización','Invoice',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Cotización','Subtotal','Descuento','Impuesto','Total','Redondear','Debido','Total pagado',0,NULL,NULL,'Fecha',NULL,1,0,1,0,0,0,0,0,NULL,0,'Producto','Cantidad','Precio unitario','Subtotal','HSN',NULL,0,0,1,1,1,1,1,1,1,0,0,1,0,0,1,1,'Cliente','Comisionista',0,0,'#000000',NULL,NULL,'{\"proforma_heading\":\"Factura de proforma\",\"due_date_label\":\"Fecha de vencimiento\",\"total_quantity_label\":\"Total Quantity\",\"item_discount_label\":\"Discount\",\"num_to_word_format\":\"international\"}',0,4,0,NULL,'slim2','Credit Note','Numero de referencia','Credit Amount',NULL,0,NULL,'Cambiar el retorno',NULL,NULL,NULL,'2023-03-29 14:02:48','2023-03-29 14:02:48');
/*!40000 ALTER TABLE `invoice_layouts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `invoice_schemes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_schemes` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheme_type` enum('blank','year') COLLATE utf8mb4_unicode_ci NOT NULL,
  `prefix` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_number` int DEFAULT NULL,
  `invoice_count` int NOT NULL DEFAULT '0',
  `total_digits` int DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_schemes_business_id_foreign` (`business_id`),
  KEY `invoice_schemes_scheme_type_index` (`scheme_type`),
  CONSTRAINT `invoice_schemes_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `invoice_schemes` WRITE;
/*!40000 ALTER TABLE `invoice_schemes` DISABLE KEYS */;
INSERT INTO `invoice_schemes` VALUES (1,1,'Default','blank','',1,0,4,1,'2023-01-26 15:59:33','2023-01-26 15:59:33'),(2,2,'Default','blank','',1,1,4,1,'2023-01-26 16:42:31','2023-02-17 18:38:46'),(3,3,'Default','blank','',1,14,4,1,'2023-01-26 19:20:15','2023-02-10 19:40:09'),(4,4,'Recibo','year','REC-',1,2,4,1,'2023-01-26 20:28:14','2023-03-29 14:11:27'),(5,5,'Default','blank','',1,12,4,1,'2023-01-28 21:05:09','2023-03-29 10:49:46'),(6,6,'Default','blank','',1,0,4,1,'2023-01-30 16:12:22','2023-01-30 16:12:22'),(7,7,'Default','blank','',1,0,4,1,'2023-02-01 10:48:07','2023-02-01 10:48:07'),(8,8,'Default','blank','',1,0,4,1,'2023-02-15 09:06:18','2023-02-15 09:06:18'),(9,9,'Default','blank','',1,0,4,1,'2023-03-06 13:58:51','2023-03-06 13:58:51'),(10,10,'Factura','year','FAC-',0,8,4,0,'2023-03-21 16:07:24','2023-03-28 23:20:43'),(11,10,'Recibo','year','REC-',0,6,4,1,'2023-03-21 18:36:22','2023-03-28 23:20:49'),(12,11,'Recibo','year','REC-',1,0,4,1,'2023-03-22 12:12:28','2023-03-22 12:18:21'),(13,11,'Factura','year','FAC-',1,0,4,0,'2023-03-22 12:17:46','2023-03-22 12:18:29'),(14,4,'Factura','year','FAC-',0,0,4,0,'2023-03-29 14:01:13','2023-03-29 14:01:13');
/*!40000 ALTER TABLE `invoice_schemes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int NOT NULL,
  `file_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `uploaded_by` int DEFAULT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_media_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `woocommerce_media_id` int DEFAULT NULL,
  `model_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`),
  KEY `media_business_id_index` (`business_id`),
  KEY `media_uploaded_by_index` (`uploaded_by`),
  KEY `media_woocommerce_media_id_index` (`woocommerce_media_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` VALUES (1,2,'1676388490_619702825_MARCA DE AGUA HAMBURGUESAS SKOT.png',NULL,2,'App\\Product',NULL,NULL,27,'2023-02-14 11:28:10','2023-02-14 11:28:10'),(2,10,'1679498557_1984991791_Captura001.PNG',NULL,15,'App\\User',NULL,NULL,15,'2023-03-22 11:22:37','2023-03-22 11:22:37');
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `mfg_ingredient_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mfg_ingredient_groups` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `mfg_ingredient_groups` WRITE;
/*!40000 ALTER TABLE `mfg_ingredient_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `mfg_ingredient_groups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `mfg_recipe_ingredients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mfg_recipe_ingredients` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `mfg_recipe_id` int unsigned NOT NULL,
  `variation_id` int NOT NULL,
  `mfg_ingredient_group_id` int DEFAULT NULL,
  `quantity` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `waste_percent` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `sub_unit_id` int DEFAULT NULL,
  `sort_order` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mfg_recipe_ingredients_mfg_recipe_id_foreign` (`mfg_recipe_id`),
  CONSTRAINT `mfg_recipe_ingredients_mfg_recipe_id_foreign` FOREIGN KEY (`mfg_recipe_id`) REFERENCES `mfg_recipes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `mfg_recipe_ingredients` WRITE;
/*!40000 ALTER TABLE `mfg_recipe_ingredients` DISABLE KEYS */;
/*!40000 ALTER TABLE `mfg_recipe_ingredients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `mfg_recipes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mfg_recipes` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `variation_id` int NOT NULL,
  `instructions` text COLLATE utf8mb4_unicode_ci,
  `waste_percent` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ingredients_cost` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `extra_cost` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `production_cost_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'percentage',
  `total_quantity` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `final_price` decimal(22,4) NOT NULL,
  `sub_unit_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mfg_recipes_product_id_index` (`product_id`),
  KEY `mfg_recipes_variation_id_index` (`variation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `mfg_recipes` WRITE;
/*!40000 ALTER TABLE `mfg_recipes` DISABLE KEYS */;
/*!40000 ALTER TABLE `mfg_recipes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=392 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2016_06_01_000001_create_oauth_auth_codes_table',1),(4,'2016_06_01_000002_create_oauth_access_tokens_table',1),(5,'2016_06_01_000003_create_oauth_refresh_tokens_table',1),(6,'2016_06_01_000004_create_oauth_clients_table',1),(7,'2016_06_01_000005_create_oauth_personal_access_clients_table',1),(8,'2017_07_05_071953_create_currencies_table',1),(9,'2017_07_05_073658_create_business_table',1),(10,'2017_07_22_075923_add_business_id_users_table',1),(11,'2017_07_23_113209_create_brands_table',1),(12,'2017_07_26_083429_create_permission_tables',1),(13,'2017_07_26_110000_create_tax_rates_table',1),(14,'2017_07_26_122313_create_units_table',1),(15,'2017_07_27_075706_create_contacts_table',1),(16,'2017_08_04_071038_create_categories_table',1),(17,'2017_08_08_115903_create_products_table',1),(18,'2017_08_09_061616_create_variation_templates_table',1),(19,'2017_08_09_061638_create_variation_value_templates_table',1),(20,'2017_08_10_061146_create_product_variations_table',1),(21,'2017_08_10_061216_create_variations_table',1),(22,'2017_08_19_054827_create_transactions_table',1),(23,'2017_08_31_073533_create_purchase_lines_table',1),(24,'2017_10_15_064638_create_transaction_payments_table',1),(25,'2017_10_31_065621_add_default_sales_tax_to_business_table',1),(26,'2017_11_20_051930_create_table_group_sub_taxes',1),(27,'2017_11_20_063603_create_transaction_sell_lines',1),(28,'2017_11_21_064540_create_barcodes_table',1),(29,'2017_11_23_181237_create_invoice_schemes_table',1),(30,'2017_12_25_122822_create_business_locations_table',1),(31,'2017_12_25_160253_add_location_id_to_transactions_table',1),(32,'2017_12_25_163227_create_variation_location_details_table',1),(33,'2018_01_04_115627_create_sessions_table',1),(34,'2018_01_05_112817_create_invoice_layouts_table',1),(35,'2018_01_06_112303_add_invoice_scheme_id_and_invoice_layout_id_to_business_locations',1),(36,'2018_01_08_104124_create_expense_categories_table',1),(37,'2018_01_08_123327_modify_transactions_table_for_expenses',1),(38,'2018_01_09_111005_modify_payment_status_in_transactions_table',1),(39,'2018_01_09_111109_add_paid_on_column_to_transaction_payments_table',1),(40,'2018_01_25_172439_add_printer_related_fields_to_business_locations_table',1),(41,'2018_01_27_184322_create_printers_table',1),(42,'2018_01_30_181442_create_cash_registers_table',1),(43,'2018_01_31_125836_create_cash_register_transactions_table',1),(44,'2018_02_07_173326_modify_business_table',1),(45,'2018_02_08_105425_add_enable_product_expiry_column_to_business_table',1),(46,'2018_02_08_111027_add_expiry_period_and_expiry_period_type_columns_to_products_table',1),(47,'2018_02_08_131118_add_mfg_date_and_exp_date_purchase_lines_table',1),(48,'2018_02_08_155348_add_exchange_rate_to_transactions_table',1),(49,'2018_02_09_124945_modify_transaction_payments_table_for_contact_payments',1),(50,'2018_02_12_113640_create_transaction_sell_lines_purchase_lines_table',1),(51,'2018_02_12_114605_add_quantity_sold_in_purchase_lines_table',1),(52,'2018_02_13_183323_alter_decimal_fields_size',1),(53,'2018_02_14_161928_add_transaction_edit_days_to_business_table',1),(54,'2018_02_15_161032_add_document_column_to_transactions_table',1),(55,'2018_02_17_124709_add_more_options_to_invoice_layouts',1),(56,'2018_02_19_111517_add_keyboard_shortcut_column_to_business_table',1),(57,'2018_02_19_121537_stock_adjustment_move_to_transaction_table',1),(58,'2018_02_20_165505_add_is_direct_sale_column_to_transactions_table',1),(59,'2018_02_21_105329_create_system_table',1),(60,'2018_02_23_100549_version_1_2',1),(61,'2018_02_23_125648_add_enable_editing_sp_from_purchase_column_to_business_table',1),(62,'2018_02_26_103612_add_sales_commission_agent_column_to_business_table',1),(63,'2018_02_26_130519_modify_users_table_for_sales_cmmsn_agnt',1),(64,'2018_02_26_134500_add_commission_agent_to_transactions_table',1),(65,'2018_02_27_121422_add_item_addition_method_to_business_table',1),(66,'2018_02_27_170232_modify_transactions_table_for_stock_transfer',1),(67,'2018_03_05_153510_add_enable_inline_tax_column_to_business_table',1),(68,'2018_03_06_210206_modify_product_barcode_types',1),(69,'2018_03_13_181541_add_expiry_type_to_business_table',1),(70,'2018_03_16_113446_product_expiry_setting_for_business',1),(71,'2018_03_19_113601_add_business_settings_options',1),(72,'2018_03_26_125334_add_pos_settings_to_business_table',1),(73,'2018_03_26_165350_create_customer_groups_table',1),(74,'2018_03_27_122720_customer_group_related_changes_in_tables',1),(75,'2018_03_29_110138_change_tax_field_to_nullable_in_business_table',1),(76,'2018_03_29_115502_add_changes_for_sr_number_in_products_and_sale_lines_table',1),(77,'2018_03_29_134340_add_inline_discount_fields_in_purchase_lines',1),(78,'2018_03_31_140921_update_transactions_table_exchange_rate',1),(79,'2018_04_03_103037_add_contact_id_to_contacts_table',1),(80,'2018_04_03_122709_add_changes_to_invoice_layouts_table',1),(81,'2018_04_09_135320_change_exchage_rate_size_in_business_table',1),(82,'2018_04_17_123122_add_lot_number_to_business',1),(83,'2018_04_17_160845_add_product_racks_table',1),(84,'2018_04_20_182015_create_res_tables_table',1),(85,'2018_04_24_105246_restaurant_fields_in_transaction_table',1),(86,'2018_04_24_114149_add_enabled_modules_business_table',1),(87,'2018_04_24_133704_add_modules_fields_in_invoice_layout_table',1),(88,'2018_04_27_132653_quotation_related_change',1),(89,'2018_05_02_104439_add_date_format_and_time_format_to_business',1),(90,'2018_05_02_111939_add_sell_return_to_transaction_payments',1),(91,'2018_05_14_114027_add_rows_positions_for_products',1),(92,'2018_05_14_125223_add_weight_to_products_table',1),(93,'2018_05_14_164754_add_opening_stock_permission',1),(94,'2018_05_15_134729_add_design_to_invoice_layouts',1),(95,'2018_05_16_183307_add_tax_fields_invoice_layout',1),(96,'2018_05_18_191956_add_sell_return_to_transaction_table',1),(97,'2018_05_21_131349_add_custom_fileds_to_contacts_table',1),(98,'2018_05_21_131607_invoice_layout_fields_for_sell_return',1),(99,'2018_05_21_131949_add_custom_fileds_and_website_to_business_locations_table',1),(100,'2018_05_22_123527_create_reference_counts_table',1),(101,'2018_05_22_154540_add_ref_no_prefixes_column_to_business_table',1),(102,'2018_05_24_132620_add_ref_no_column_to_transaction_payments_table',1),(103,'2018_05_24_161026_add_location_id_column_to_business_location_table',1),(104,'2018_05_25_180603_create_modifiers_related_table',1),(105,'2018_05_29_121714_add_purchase_line_id_to_stock_adjustment_line_table',1),(106,'2018_05_31_114645_add_res_order_status_column_to_transactions_table',1),(107,'2018_06_05_103530_rename_purchase_line_id_in_stock_adjustment_lines_table',1),(108,'2018_06_05_111905_modify_products_table_for_modifiers',1),(109,'2018_06_06_110524_add_parent_sell_line_id_column_to_transaction_sell_lines_table',1),(110,'2018_06_07_152443_add_is_service_staff_to_roles_table',1),(111,'2018_06_07_182258_add_image_field_to_products_table',1),(112,'2018_06_13_133705_create_bookings_table',1),(113,'2018_06_15_173636_add_email_column_to_contacts_table',1),(114,'2018_06_27_182835_add_superadmin_related_fields_business',1),(115,'2018_06_27_185405_create_packages_table',1),(116,'2018_06_28_182803_create_subscriptions_table',1),(117,'2018_07_10_101913_add_custom_fields_to_products_table',1),(118,'2018_07_17_103434_add_sales_person_name_label_to_invoice_layouts_table',1),(119,'2018_07_17_163920_add_theme_skin_color_column_to_business_table',1),(120,'2018_07_17_182021_add_rows_to_system_table',1),(121,'2018_07_19_131721_add_options_to_packages_table',1),(122,'2018_07_24_160319_add_lot_no_line_id_to_transaction_sell_lines_table',1),(123,'2018_07_25_110004_add_show_expiry_and_show_lot_colums_to_invoice_layouts_table',1),(124,'2018_07_25_172004_add_discount_columns_to_transaction_sell_lines_table',1),(125,'2018_07_26_124720_change_design_column_type_in_invoice_layouts_table',1),(126,'2018_07_26_170424_add_unit_price_before_discount_column_to_transaction_sell_line_table',1),(127,'2018_07_28_103614_add_credit_limit_column_to_contacts_table',1),(128,'2018_08_08_110755_add_new_payment_methods_to_transaction_payments_table',1),(129,'2018_08_08_122225_modify_cash_register_transactions_table_for_new_payment_methods',1),(130,'2018_08_14_104036_add_opening_balance_type_to_transactions_table',1),(131,'2018_08_17_155534_add_min_termination_alert_days',1),(132,'2018_08_28_105945_add_business_based_username_settings_to_system_table',1),(133,'2018_08_30_105906_add_superadmin_communicator_logs_table',1),(134,'2018_09_04_155900_create_accounts_table',1),(135,'2018_09_06_114438_create_selling_price_groups_table',1),(136,'2018_09_06_154057_create_variation_group_prices_table',1),(137,'2018_09_07_102413_add_permission_to_access_default_selling_price',1),(138,'2018_09_07_134858_add_selling_price_group_id_to_transactions_table',1),(139,'2018_09_10_112448_update_product_type_to_single_if_null_in_products_table',1),(140,'2018_09_10_152703_create_account_transactions_table',1),(141,'2018_09_10_173656_add_account_id_column_to_transaction_payments_table',1),(142,'2018_09_19_123914_create_notification_templates_table',1),(143,'2018_09_22_110504_add_sms_and_email_settings_columns_to_business_table',1),(144,'2018_09_24_134942_add_lot_no_line_id_to_stock_adjustment_lines_table',1),(145,'2018_09_26_105557_add_transaction_payments_for_existing_expenses',1),(146,'2018_09_27_111609_modify_transactions_table_for_purchase_return',1),(147,'2018_09_27_131154_add_quantity_returned_column_to_purchase_lines_table',1),(148,'2018_10_01_151252_create_documents_table',1),(149,'2018_10_02_131401_add_return_quantity_column_to_transaction_sell_lines_table',1),(150,'2018_10_02_151803_create_document_shares_table',1),(151,'2018_10_03_104918_add_qty_returned_column_to_transaction_sell_lines_purchase_lines_table',1),(152,'2018_10_03_185947_add_default_notification_templates_to_database',1),(153,'2018_10_09_134558_create_reminders_table',1),(154,'2018_10_09_153105_add_business_id_to_transaction_payments_table',1),(155,'2018_10_10_110400_add_module_version_to_system_table',1),(156,'2018_10_10_122845_add_woocommerce_api_settings_to_business_table',1),(157,'2018_10_10_162041_add_woocommerce_category_id_to_categories_table',1),(158,'2018_10_11_173839_create_woocommerce_sync_logs_table',1),(159,'2018_10_16_123522_add_woocommerce_tax_rate_id_column_to_tax_rates_table',1),(160,'2018_10_16_135229_create_permission_for_sells_and_purchase',1),(161,'2018_10_22_114441_add_columns_for_variable_product_modifications',1),(162,'2018_10_22_134428_modify_variable_product_data',1),(163,'2018_10_23_111555_add_woocommerce_attr_id_column_to_variation_templates_table',1),(164,'2018_10_30_181558_add_table_tax_headings_to_invoice_layout',1),(165,'2018_10_31_122619_add_pay_terms_field_transactions_table',1),(166,'2018_10_31_161328_add_new_permissions_for_pos_screen',1),(167,'2018_10_31_174752_add_access_selected_contacts_only_to_users_table',1),(168,'2018_10_31_175627_add_user_contact_access',1),(169,'2018_10_31_180559_add_auto_send_sms_column_to_notification_templates_table',1),(170,'2018_11_02_130636_add_custom_permissions_to_packages_table',1),(171,'2018_11_02_171949_change_card_type_column_to_varchar_in_transaction_payments_table',1),(172,'2018_11_05_161848_add_more_fields_to_packages_table',1),(173,'2018_11_08_105621_add_role_permissions',1),(174,'2018_11_16_170756_create_to_dos_table',1),(175,'2018_11_26_114135_add_is_suspend_column_to_transactions_table',1),(176,'2018_11_28_104410_modify_units_table_for_multi_unit',1),(177,'2018_11_28_170952_add_sub_unit_id_to_purchase_lines_and_sell_lines',1),(178,'2018_11_29_115918_add_primary_key_in_system_table',1),(179,'2018_12_03_163945_add_woocommerce_permissions',1),(180,'2018_12_03_185546_add_product_description_column_to_products_table',1),(181,'2018_12_06_114937_modify_system_table_and_users_table',1),(182,'2018_12_10_124621_modify_system_table_values_null_default',1),(183,'2018_12_13_160007_add_custom_fields_display_options_to_invoice_layouts_table',1),(184,'2018_12_14_103307_modify_system_table',1),(185,'2018_12_18_133837_add_prev_balance_due_columns_to_invoice_layouts_table',1),(186,'2018_12_18_170656_add_invoice_token_column_to_transaction_table',1),(187,'2018_12_20_133639_add_date_time_format_column_to_invoice_layouts_table',1),(188,'2018_12_21_120659_add_recurring_invoice_fields_to_transactions_table',1),(189,'2018_12_24_154933_create_notifications_table',1),(190,'2019_01_08_112015_add_document_column_to_transaction_payments_table',1),(191,'2019_01_10_124645_add_account_permission',1),(192,'2019_01_16_125825_add_subscription_no_column_to_transactions_table',1),(193,'2019_01_28_111647_add_order_addresses_column_to_transactions_table',1),(194,'2019_02_13_173821_add_is_inactive_column_to_products_table',1),(195,'2019_02_18_154414_change_woocommerce_sync_logs_table',1),(196,'2019_02_19_103118_create_discounts_table',1),(197,'2019_02_21_120324_add_discount_id_column_to_transaction_sell_lines_table',1),(198,'2019_02_21_134324_add_permission_for_discount',1),(199,'2019_02_22_120329_essentials_messages',1),(200,'2019_02_22_161513_add_message_permissions',1),(201,'2019_03_04_170832_add_service_staff_columns_to_transaction_sell_lines_table',1),(202,'2019_03_07_155813_make_repair_statuses_table',1),(203,'2019_03_08_120634_add_repair_columns_to_transactions_table',1),(204,'2019_03_09_102425_add_sub_type_column_to_transactions_table',1),(205,'2019_03_09_124457_add_indexing_transaction_sell_lines_purchase_lines_table',1),(206,'2019_03_12_120336_create_activity_log_table',1),(207,'2019_03_14_182704_add_repair_permissions',1),(208,'2019_03_15_132925_create_media_table',1),(209,'2019_03_29_110241_add_repair_version_column_to_system_table',1),(210,'2019_03_29_164339_add_essentials_version_to_system_table',1),(211,'2019_04_12_113901_add_repair_settings_column_to_business_table',1),(212,'2019_04_19_174129_add_disable_woocommerce_sync_column_to_products_table',1),(213,'2019_05_08_130339_add_indexing_to_parent_id_in_transaction_payments_table',1),(214,'2019_05_10_132311_add_missing_column_indexing',1),(215,'2019_05_10_135434_add_missing_database_column_indexes',1),(216,'2019_05_14_091812_add_show_image_column_to_invoice_layouts_table',1),(217,'2019_05_17_153306_create_essentials_leave_types_table',1),(218,'2019_05_17_175921_create_essentials_leaves_table',1),(219,'2019_05_21_154517_add_essentials_settings_columns_to_business_table',1),(220,'2019_05_21_181653_create_table_essentials_attendance',1),(221,'2019_05_25_104922_add_view_purchase_price_permission',1),(222,'2019_05_30_110049_create_essentials_payrolls_table',1),(223,'2019_06_04_105723_create_essentials_holidays_table',1),(224,'2019_06_08_132440_add_woocommerce_wh_oc_secret_column_to_business_table',1),(225,'2019_06_17_103515_add_profile_informations_columns_to_users_table',1),(226,'2019_06_18_135524_add_permission_to_view_own_sales_only',1),(227,'2019_06_19_112058_add_database_changes_for_reward_points',1),(228,'2019_06_28_133732_change_type_column_to_string_in_transactions_table',1),(229,'2019_06_28_134217_add_payroll_columns_to_transactions_table',1),(230,'2019_07_13_111420_add_is_created_from_api_column_to_transactions_table',1),(231,'2019_07_15_114211_add_manufacturing_module_version_to_system_table',1),(232,'2019_07_15_114403_create_mfg_recipes_table',1),(233,'2019_07_15_165136_add_fields_for_combo_product',1),(234,'2019_07_18_180217_add_production_columns_to_transactions_table',1),(235,'2019_07_19_103446_add_mfg_quantity_used_column_to_purchase_lines_table',1),(236,'2019_07_22_152649_add_not_for_selling_in_product_table',1),(237,'2019_07_26_110753_add_manufacturing_settings_column_to_business_table',1),(238,'2019_07_26_170450_add_manufacturing_permissions',1),(239,'2019_07_29_185351_add_show_reward_point_column_to_invoice_layouts_table',1),(240,'2019_08_08_110035_create_mfg_recipe_ingredients_table',1),(241,'2019_08_08_162302_add_sub_units_related_fields',1),(242,'2019_08_08_172837_add_recipe_add_edit_permissions',1),(243,'2019_08_12_114610_add_ingredient_waste_percent_columns',1),(244,'2019_08_16_115300_create_superadmin_frontend_pages_table',1),(245,'2019_08_26_103520_add_approve_leave_permission',1),(246,'2019_08_26_133419_update_price_fields_decimal_point',1),(247,'2019_08_27_103724_create_essentials_allowance_and_deduction_table',1),(248,'2019_08_27_105236_create_essentials_user_allowances_and_deductions',1),(249,'2019_09_02_160054_remove_location_permissions_from_roles',1),(250,'2019_09_03_185259_add_permission_for_pos_screen',1),(251,'2019_09_04_163141_add_location_id_to_cash_registers_table',1),(252,'2019_09_04_184008_create_types_of_services_table',1),(253,'2019_09_06_131445_add_types_of_service_fields_to_transactions_table',1),(254,'2019_09_09_134810_add_default_selling_price_group_id_column_to_business_locations_table',1),(255,'2019_09_12_105616_create_product_locations_table',1),(256,'2019_09_17_122522_add_custom_labels_column_to_business_table',1),(257,'2019_09_18_164319_add_shipping_fields_to_transactions_table',1),(258,'2019_09_19_170927_close_all_active_registers',1),(259,'2019_09_20_115906_add_more_columns_to_essentials_to_dos_table',1),(260,'2019_09_23_120439_create_essentials_todo_comments_table',1),(261,'2019_09_23_161906_add_media_description_cloumn_to_media_table',1),(262,'2019_10_01_171828_add_woocommerce_media_id_columns',1),(263,'2019_10_18_155633_create_account_types_table',1),(264,'2019_10_22_163335_add_common_settings_column_to_business_table',1),(265,'2019_10_29_132521_add_update_purchase_status_permission',1),(266,'2019_11_05_115136_create_ingredient_groups_table',1),(267,'2019_11_09_110522_add_indexing_to_lot_number',1),(268,'2019_11_12_163135_create_projects_table',1),(269,'2019_11_12_164431_create_project_members_table',1),(270,'2019_11_14_112230_create_project_tasks_table',1),(271,'2019_11_14_112258_create_project_task_members_table',1),(272,'2019_11_18_154617_create_project_task_comments_table',1),(273,'2019_11_19_134807_create_project_time_logs_table',1),(274,'2019_11_19_170824_add_is_active_column_to_business_locations_table',1),(275,'2019_11_21_162913_change_quantity_field_types_to_decimal',1),(276,'2019_11_25_160340_modify_categories_table_for_polymerphic_relationship',1),(277,'2019_12_02_105025_create_warranties_table',1),(278,'2019_12_03_180342_add_common_settings_field_to_invoice_layouts_table',1),(279,'2019_12_05_170724_add_hrm_columns_to_users_table',1),(280,'2019_12_05_183955_add_more_fields_to_users_table',1),(281,'2019_12_06_174904_add_change_return_label_column_to_invoice_layouts_table',1),(282,'2019_12_09_105809_add_allowance_and_deductions_permission',1),(283,'2019_12_11_102549_add_more_fields_in_transactions_table',1),(284,'2019_12_11_102735_create_invoice_lines_table',1),(285,'2019_12_11_121307_add_draft_and_quotation_list_permissions',1),(286,'2019_12_12_180126_copy_expense_total_to_total_before_tax',1),(287,'2019_12_19_181412_make_alert_quantity_field_nullable_on_products_table',1),(288,'2019_12_25_173413_create_dashboard_configurations_table',1),(289,'2020_01_07_172852_add_project_permissions',1),(290,'2020_01_08_115422_add_project_module_version_to_system_table',1),(291,'2020_01_08_133506_create_document_and_notes_table',1),(292,'2020_01_09_113252_add_cc_bcc_column_to_notification_templates_table',1),(293,'2020_01_16_174818_add_round_off_amount_field_to_transactions_table',1),(294,'2020_01_28_162345_add_weighing_scale_settings_in_business_settings_table',1),(295,'2020_02_18_172447_add_import_fields_to_transactions_table',1),(296,'2020_02_22_120303_add_column_to_mfg_recipe_ingredients_table',1),(297,'2020_03_13_135844_add_is_active_column_to_selling_price_groups_table',1),(298,'2020_03_16_115449_add_contact_status_field_to_contacts_table',1),(299,'2020_03_19_130231_add_contact_id_to_users_table',1),(300,'2020_03_26_124736_add_allow_login_column_in_users_table',1),(301,'2020_03_27_133605_create_schedules_table',1),(302,'2020_03_27_133628_create_schedule_users_table',1),(303,'2020_03_28_152838_create_essentials_shift_table',1),(304,'2020_03_30_112834_create_schedule_logs_table',1),(305,'2020_03_30_162029_create_user_shifts_table',1),(306,'2020_03_31_134558_add_shift_id_to_attendance_table',1),(307,'2020_04_02_182331_add_crm_module_version_to_system_table',1),(308,'2020_04_08_153231_modify_cloumn_in_contacts_table',1),(309,'2020_04_09_101052_create_lead_users_table',1),(310,'2020_04_13_154150_add_feature_products_column_to_business_loactions',1),(311,'2020_04_15_151802_add_user_type_to_users_table',1),(312,'2020_04_16_114747_create_crm_campaigns_table',1),(313,'2020_04_22_153905_add_subscription_repeat_on_column_to_transactions_table',1),(314,'2020_04_28_111436_add_shipping_address_to_contacts_table',1),(315,'2020_05_05_125008_create_device_models_table',1),(316,'2020_05_06_103135_add_repair_model_id_column_to_products_table',1),(317,'2020_06_01_094654_add_max_sale_discount_column_to_users_table',1),(318,'2020_06_12_162245_modify_contacts_table',1),(319,'2020_06_22_103104_change_recur_interval_default_to_one',1),(320,'2020_07_09_174621_add_balance_field_to_contacts_table',1),(321,'2020_07_10_114514_set_location_id_on_existing_invoice',1),(322,'2020_07_11_120308_add_columns_to_repair_statuses_table',1),(323,'2020_07_23_104933_change_status_column_to_varchar_in_transaction_table',1),(324,'2020_07_31_130737_create_job_sheets_table',1),(325,'2020_08_07_124241_add_job_sheet_id_to_transactions_table',1),(326,'2020_08_18_123107_add_connector_module_version_to_system_table',1),(327,'2020_08_19_103831_add_production_cost_type_to_recipe_and_transaction_table',1),(328,'2020_08_22_104640_add_email_template_field_to_repair_status_table',1),(329,'2020_09_07_124952_add_woocommerce_skipped_orders_fields_to_business_table',1),(330,'2020_09_07_171059_change_completed_stock_transfer_status_to_final',1),(331,'2020_09_21_123224_modify_booking_status_column_in_bookings_table',1),(332,'2020_09_22_121639_create_discount_variations_table',1),(333,'2020_09_29_184909_add_product_catalogue_version',1),(334,'2020_10_05_121550_modify_business_location_table_for_invoice_layout',1),(335,'2020_10_16_175726_set_status_as_received_for_opening_stock',1),(336,'2020_10_19_131934_add_job_sheet_custom_fields_to_repair_job_sheets_table',1),(337,'2020_10_23_170823_add_for_group_tax_column_to_tax_rates_table',1),(338,'2020_11_04_130940_add_more_custom_fields_to_contacts_table',1),(339,'2020_11_05_105157_modify_todos_date_column_type',1),(340,'2020_11_10_152841_add_cash_register_permissions',1),(341,'2020_11_11_174852_add_end_time_column_to_essentials_reminders_table',1),(342,'2020_11_17_164041_modify_type_column_to_varchar_in_contacts_table',1),(343,'2020_11_25_111050_add_parts_column_to_repair_job_sheets_table',1),(344,'2020_11_26_170527_create_essentials_kb_table',1),(345,'2020_11_30_112615_create_essentials_kb_users_table',1),(346,'2020_12_18_181447_add_shipping_custom_fields_to_transactions_table',1),(347,'2020_12_22_164303_add_sub_status_column_to_transactions_table',1),(348,'2020_12_24_153050_add_custom_fields_to_transactions_table',1),(349,'2020_12_28_105403_add_whatsapp_text_column_to_notification_templates_table',1),(350,'2020_12_29_165925_add_model_document_type_to_media_table',1),(351,'2020_12_30_101842_add_use_for_repair_column_to_brands_table',1),(352,'2021_01_07_155757_add_followup_additional_info_column_to_crm_schedules_table',1),(353,'2021_02_02_140021_add_additional_info_to_crm_campaigns_table',1),(354,'2021_02_02_173651_add_new_columns_to_contacts_table',1),(355,'2021_02_04_120439_create_call_logs_table',1),(356,'2021_02_08_172047_add_mobile_name_column_to_crm_call_logs_table',1),(357,'2021_02_08_175632_add_contact_number_fields_to_users_table',1),(358,'2021_02_11_172217_add_indexing_for_multiple_columns',1),(359,'2021_02_12_185514_add_clock_in_location_to_essentials_attendances_table',1),(360,'2021_02_16_190038_add_crm_module_indexing',1),(361,'2021_02_16_190203_add_essentials_module_indexing',1),(362,'2021_02_16_190423_add_repair_module_indexing',1),(363,'2021_02_16_190608_add_woocommerce_module_indexing',1),(364,'2021_02_19_120846_create_crm_followup_invoices',1),(365,'2021_02_22_132125_add_follow_up_by_to_crm_schedules_table',1),(366,'2021_02_23_122043_add_more_columns_to_customer_groups_table',1),(367,'2021_02_24_175551_add_print_invoice_permission_to_all_roles',1),(368,'2021_03_03_162021_add_purchase_order_columns_to_purchase_lines_and_transactions_table',1),(369,'2021_03_11_120229_add_sales_order_columns',1),(370,'2021_03_16_120705_add_business_id_to_activity_log_table',1),(371,'2021_03_16_153427_add_code_columns_to_business_table',1),(372,'2021_03_18_173308_add_account_details_column_to_accounts_table',1),(373,'2021_03_18_183119_add_prefer_payment_account_columns_to_transactions_table',1),(374,'2021_03_22_120810_add_more_types_of_service_custom_fields',1),(375,'2021_03_24_160736_add_department_and_designation_to_users_table',1),(376,'2021_03_24_183132_add_shipping_export_custom_field_details_to_contacts_table',1),(377,'2021_03_25_170715_add_export_custom_fields_info_to_transactions_table',1),(378,'2021_04_15_063449_add_denominations_column_to_cash_registers_table',1),(379,'2021_05_22_083426_add_indexing_to_account_transactions_table',1),(380,'2021_06_15_152924_create_proposal_templates_table',1),(381,'2021_06_16_114448_add_recursive_fields_to_crm_schedules_table',1),(382,'2021_06_16_125740_create_proposals_table',1),(383,'2021_07_08_065808_add_additional_expense_columns_to_transaction_table',1),(384,'2021_07_13_082918_add_qr_code_columns_to_invoice_layouts_table',1),(385,'2021_07_21_061615_add_fields_to_show_commission_agent_in_invoice_layout',1),(386,'2021_08_13_105549_add_crm_contact_id_to_users_table',1),(387,'2021_08_25_114932_add_payment_link_fields_to_transaction_payments_table',1),(388,'2021_09_01_063110_add_spg_column_to_discounts_table',1),(389,'2021_09_03_061528_modify_cash_register_transactions_table',1),(390,'2021_09_24_065738_add_crm_settings_column_to_business_table',1),(391,'2021_10_05_061658_add_source_column_to_transactions_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` int unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_type_model_id_index` (`model_type`,`model_id`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
INSERT INTO `model_has_permissions` VALUES (103,'App\\User',2),(103,'App\\User',4),(103,'App\\User',5),(110,'App\\User',7),(103,'App\\User',11),(106,'App\\User',11),(107,'App\\User',11),(108,'App\\User',11),(103,'App\\User',13);
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` int unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_type_model_id_index` (`model_type`,`model_id`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\User',1),(3,'App\\User',2),(5,'App\\User',3),(5,'App\\User',4),(5,'App\\User',5),(7,'App\\User',6),(8,'App\\User',7),(9,'App\\User',8),(11,'App\\User',9),(13,'App\\User',10),(4,'App\\User',11),(15,'App\\User',12),(3,'App\\User',13),(18,'App\\User',14),(20,'App\\User',15),(22,'App\\User',16);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notification_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_templates` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int NOT NULL,
  `template_for` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_body` text COLLATE utf8mb4_unicode_ci,
  `sms_body` text COLLATE utf8mb4_unicode_ci,
  `whatsapp_text` text COLLATE utf8mb4_unicode_ci,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cc` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bcc` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auto_send` tinyint(1) NOT NULL DEFAULT '0',
  `auto_send_sms` tinyint(1) NOT NULL DEFAULT '0',
  `auto_send_wa_notif` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notification_templates` WRITE;
/*!40000 ALTER TABLE `notification_templates` DISABLE KEYS */;
INSERT INTO `notification_templates` VALUES (1,1,'new_sale','<p>Dear {contact_name},</p>\n\n                    <p>Your invoice number is {invoice_number}<br />\n                    Total amount: {total_amount}<br />\n                    Paid amount: {received_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2023-01-26 15:59:33','2023-01-26 15:59:33'),(2,1,'payment_received','<p>Dear {contact_name},</p>\n\n                <p>We have received a payment of {received_amount}</p>\n\n                <p>{business_logo}</p>','Dear {contact_name}, We have received a payment of {received_amount}. {business_name}',NULL,'Payment Received, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 15:59:33','2023-01-26 15:59:33'),(3,1,'payment_reminder','<p>Dear {contact_name},</p>\n\n                    <p>This is to remind you that you have pending payment of {due_amount}. Kindly pay it as soon as possible.</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, You have pending payment of {due_amount}. Kindly pay it as soon as possible. {business_name}',NULL,'Payment Reminder, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 15:59:33','2023-01-26 15:59:33'),(4,1,'new_booking','<p>Dear {contact_name},</p>\n\n                    <p>Your booking is confirmed</p>\n\n                    <p>Date: {start_time} to {end_time}</p>\n\n                    <p>Table: {table}</p>\n\n                    <p>Location: {location}</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, Your booking is confirmed. Date: {start_time} to {end_time}, Table: {table}, Location: {location}',NULL,'Booking Confirmed - {business_name}',NULL,NULL,0,0,0,'2023-01-26 15:59:33','2023-01-26 15:59:33'),(5,1,'new_order','<p>Dear {contact_name},</p>\n\n                    <p>We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','Dear {contact_name}, We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible. {business_name}',NULL,'New Order, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 15:59:33','2023-01-26 15:59:33'),(6,1,'payment_paid','<p>Dear {contact_name},</p>\n\n                    <p>We have paid amount {paid_amount} again invoice number {order_ref_number}.<br />\n                    Kindly note it down.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have paid amount {paid_amount} again invoice number {order_ref_number}.\n                    Kindly note it down. {business_name}',NULL,'Payment Paid, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 15:59:33','2023-01-26 15:59:33'),(7,1,'items_received','<p>Dear {contact_name},</p>\n\n                    <p>We have received all items from invoice reference number {order_ref_number}. Thank you for processing it.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have received all items from invoice reference number {order_ref_number}. Thank you for processing it. {business_name}',NULL,'Items received, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 15:59:33','2023-01-26 15:59:33'),(8,1,'items_pending','<p>Dear {contact_name},<br />\n                    This is to remind you that we have not yet received some items from invoice reference number {order_ref_number}. Please process it as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','This is to remind you that we have not yet received some items from invoice reference number {order_ref_number} . Please process it as soon as possible.{business_name}',NULL,'Items Pending, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 15:59:33','2023-01-26 15:59:33'),(9,1,'new_quotation','<p>Dear {contact_name},</p>\n\n                    <p>Your quotation number is {invoice_number}<br />\n                    Total amount: {total_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2023-01-26 15:59:33','2023-01-26 15:59:33'),(10,2,'new_sale','<p>Dear {contact_name},</p>\n\n                    <p>Your invoice number is {invoice_number}<br />\n                    Total amount: {total_amount}<br />\n                    Paid amount: {received_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2023-01-26 16:42:31','2023-01-26 16:42:31'),(11,2,'payment_received','<p>Dear {contact_name},</p>\n\n                <p>We have received a payment of {received_amount}</p>\n\n                <p>{business_logo}</p>','Dear {contact_name}, We have received a payment of {received_amount}. {business_name}',NULL,'Payment Received, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 16:42:31','2023-01-26 16:42:31'),(12,2,'payment_reminder','<p>Dear {contact_name},</p>\n\n                    <p>This is to remind you that you have pending payment of {due_amount}. Kindly pay it as soon as possible.</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, You have pending payment of {due_amount}. Kindly pay it as soon as possible. {business_name}',NULL,'Payment Reminder, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 16:42:31','2023-01-26 16:42:31'),(13,2,'new_booking','<p>Dear {contact_name},</p>\n\n                    <p>Your booking is confirmed</p>\n\n                    <p>Date: {start_time} to {end_time}</p>\n\n                    <p>Table: {table}</p>\n\n                    <p>Location: {location}</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, Your booking is confirmed. Date: {start_time} to {end_time}, Table: {table}, Location: {location}',NULL,'Booking Confirmed - {business_name}',NULL,NULL,0,0,0,'2023-01-26 16:42:31','2023-01-26 16:42:31'),(14,2,'new_order','<p>Dear {contact_name},</p>\n\n                    <p>We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','Dear {contact_name}, We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible. {business_name}',NULL,'New Order, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 16:42:31','2023-01-26 16:42:31'),(15,2,'payment_paid','<p>Dear {contact_name},</p>\n\n                    <p>We have paid amount {paid_amount} again invoice number {order_ref_number}.<br />\n                    Kindly note it down.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have paid amount {paid_amount} again invoice number {order_ref_number}.\n                    Kindly note it down. {business_name}',NULL,'Payment Paid, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 16:42:31','2023-01-26 16:42:31'),(16,2,'items_received','<p>Dear {contact_name},</p>\n\n                    <p>We have received all items from invoice reference number {order_ref_number}. Thank you for processing it.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have received all items from invoice reference number {order_ref_number}. Thank you for processing it. {business_name}',NULL,'Items received, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 16:42:31','2023-01-26 16:42:31'),(17,2,'items_pending','<p>Dear {contact_name},<br />\n                    This is to remind you that we have not yet received some items from invoice reference number {order_ref_number}. Please process it as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','This is to remind you that we have not yet received some items from invoice reference number {order_ref_number} . Please process it as soon as possible.{business_name}',NULL,'Items Pending, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 16:42:31','2023-01-26 16:42:31'),(18,2,'new_quotation','<p>Dear {contact_name},</p>\n\n                    <p>Your quotation number is {invoice_number}<br />\n                    Total amount: {total_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2023-01-26 16:42:31','2023-01-26 16:42:31'),(19,3,'new_sale','<p>Dear {contact_name},</p>\n\n                    <p>Your invoice number is {invoice_number}<br />\n                    Total amount: {total_amount}<br />\n                    Paid amount: {received_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2023-01-26 19:20:15','2023-01-26 19:20:15'),(20,3,'payment_received','<p>Dear {contact_name},</p>\n\n                <p>We have received a payment of {received_amount}</p>\n\n                <p>{business_logo}</p>','Dear {contact_name}, We have received a payment of {received_amount}. {business_name}',NULL,'Payment Received, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 19:20:15','2023-01-26 19:20:15'),(21,3,'payment_reminder','<p>Dear {contact_name},</p>\n\n                    <p>This is to remind you that you have pending payment of {due_amount}. Kindly pay it as soon as possible.</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, You have pending payment of {due_amount}. Kindly pay it as soon as possible. {business_name}',NULL,'Payment Reminder, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 19:20:15','2023-01-26 19:20:15'),(22,3,'new_booking','<p>Dear {contact_name},</p>\n\n                    <p>Your booking is confirmed</p>\n\n                    <p>Date: {start_time} to {end_time}</p>\n\n                    <p>Table: {table}</p>\n\n                    <p>Location: {location}</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, Your booking is confirmed. Date: {start_time} to {end_time}, Table: {table}, Location: {location}',NULL,'Booking Confirmed - {business_name}',NULL,NULL,0,0,0,'2023-01-26 19:20:15','2023-01-26 19:20:15'),(23,3,'new_order','<p>Dear {contact_name},</p>\n\n                    <p>We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','Dear {contact_name}, We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible. {business_name}',NULL,'New Order, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 19:20:15','2023-01-26 19:20:15'),(24,3,'payment_paid','<p>Dear {contact_name},</p>\n\n                    <p>We have paid amount {paid_amount} again invoice number {order_ref_number}.<br />\n                    Kindly note it down.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have paid amount {paid_amount} again invoice number {order_ref_number}.\n                    Kindly note it down. {business_name}',NULL,'Payment Paid, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 19:20:15','2023-01-26 19:20:15'),(25,3,'items_received','<p>Dear {contact_name},</p>\n\n                    <p>We have received all items from invoice reference number {order_ref_number}. Thank you for processing it.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have received all items from invoice reference number {order_ref_number}. Thank you for processing it. {business_name}',NULL,'Items received, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 19:20:15','2023-01-26 19:20:15'),(26,3,'items_pending','<p>Dear {contact_name},<br />\n                    This is to remind you that we have not yet received some items from invoice reference number {order_ref_number}. Please process it as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','This is to remind you that we have not yet received some items from invoice reference number {order_ref_number} . Please process it as soon as possible.{business_name}',NULL,'Items Pending, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 19:20:15','2023-01-26 19:20:15'),(27,3,'new_quotation','<p>Dear {contact_name},</p>\n\n                    <p>Your quotation number is {invoice_number}<br />\n                    Total amount: {total_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2023-01-26 19:20:15','2023-01-26 19:20:15'),(28,4,'new_sale','<p>Dear {contact_name},</p>\n\n                    <p>Your invoice number is {invoice_number}<br />\n                    Total amount: {total_amount}<br />\n                    Paid amount: {received_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2023-01-26 20:28:14','2023-01-26 20:28:14'),(29,4,'payment_received','<p>Dear {contact_name},</p>\n\n                <p>We have received a payment of {received_amount}</p>\n\n                <p>{business_logo}</p>','Dear {contact_name}, We have received a payment of {received_amount}. {business_name}',NULL,'Payment Received, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 20:28:14','2023-01-26 20:28:14'),(30,4,'payment_reminder','<p>Dear {contact_name},</p>\n\n                    <p>This is to remind you that you have pending payment of {due_amount}. Kindly pay it as soon as possible.</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, You have pending payment of {due_amount}. Kindly pay it as soon as possible. {business_name}',NULL,'Payment Reminder, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 20:28:14','2023-01-26 20:28:14'),(31,4,'new_booking','<p>Dear {contact_name},</p>\n\n                    <p>Your booking is confirmed</p>\n\n                    <p>Date: {start_time} to {end_time}</p>\n\n                    <p>Table: {table}</p>\n\n                    <p>Location: {location}</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, Your booking is confirmed. Date: {start_time} to {end_time}, Table: {table}, Location: {location}',NULL,'Booking Confirmed - {business_name}',NULL,NULL,0,0,0,'2023-01-26 20:28:14','2023-01-26 20:28:14'),(32,4,'new_order','<p>Dear {contact_name},</p>\n\n                    <p>We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','Dear {contact_name}, We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible. {business_name}',NULL,'New Order, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 20:28:14','2023-01-26 20:28:14'),(33,4,'payment_paid','<p>Dear {contact_name},</p>\n\n                    <p>We have paid amount {paid_amount} again invoice number {order_ref_number}.<br />\n                    Kindly note it down.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have paid amount {paid_amount} again invoice number {order_ref_number}.\n                    Kindly note it down. {business_name}',NULL,'Payment Paid, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 20:28:14','2023-01-26 20:28:14'),(34,4,'items_received','<p>Dear {contact_name},</p>\n\n                    <p>We have received all items from invoice reference number {order_ref_number}. Thank you for processing it.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have received all items from invoice reference number {order_ref_number}. Thank you for processing it. {business_name}',NULL,'Items received, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 20:28:14','2023-01-26 20:28:14'),(35,4,'items_pending','<p>Dear {contact_name},<br />\n                    This is to remind you that we have not yet received some items from invoice reference number {order_ref_number}. Please process it as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','This is to remind you that we have not yet received some items from invoice reference number {order_ref_number} . Please process it as soon as possible.{business_name}',NULL,'Items Pending, from {business_name}',NULL,NULL,0,0,0,'2023-01-26 20:28:14','2023-01-26 20:28:14'),(36,4,'new_quotation','<p>Dear {contact_name},</p>\n\n                    <p>Your quotation number is {invoice_number}<br />\n                    Total amount: {total_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2023-01-26 20:28:14','2023-01-26 20:28:14'),(37,5,'new_sale','<p>Dear {contact_name},</p>\n\n                    <p>Your invoice number is {invoice_number}<br />\n                    Total amount: {total_amount}<br />\n                    Paid amount: {received_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2023-01-28 21:05:09','2023-01-28 21:05:09'),(38,5,'payment_received','<p>Dear {contact_name},</p>\n\n                <p>We have received a payment of {received_amount}</p>\n\n                <p>{business_logo}</p>','Dear {contact_name}, We have received a payment of {received_amount}. {business_name}',NULL,'Payment Received, from {business_name}',NULL,NULL,0,0,0,'2023-01-28 21:05:09','2023-01-28 21:05:09'),(39,5,'payment_reminder','<p>Dear {contact_name},</p>\n\n                    <p>This is to remind you that you have pending payment of {due_amount}. Kindly pay it as soon as possible.</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, You have pending payment of {due_amount}. Kindly pay it as soon as possible. {business_name}',NULL,'Payment Reminder, from {business_name}',NULL,NULL,0,0,0,'2023-01-28 21:05:09','2023-01-28 21:05:09'),(40,5,'new_booking','<p>Dear {contact_name},</p>\n\n                    <p>Your booking is confirmed</p>\n\n                    <p>Date: {start_time} to {end_time}</p>\n\n                    <p>Table: {table}</p>\n\n                    <p>Location: {location}</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, Your booking is confirmed. Date: {start_time} to {end_time}, Table: {table}, Location: {location}',NULL,'Booking Confirmed - {business_name}',NULL,NULL,0,0,0,'2023-01-28 21:05:09','2023-01-28 21:05:09'),(41,5,'new_order','<p>Dear {contact_name},</p>\n\n                    <p>We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','Dear {contact_name}, We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible. {business_name}',NULL,'New Order, from {business_name}',NULL,NULL,0,0,0,'2023-01-28 21:05:09','2023-01-28 21:05:09'),(42,5,'payment_paid','<p>Dear {contact_name},</p>\n\n                    <p>We have paid amount {paid_amount} again invoice number {order_ref_number}.<br />\n                    Kindly note it down.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have paid amount {paid_amount} again invoice number {order_ref_number}.\n                    Kindly note it down. {business_name}',NULL,'Payment Paid, from {business_name}',NULL,NULL,0,0,0,'2023-01-28 21:05:09','2023-01-28 21:05:09'),(43,5,'items_received','<p>Dear {contact_name},</p>\n\n                    <p>We have received all items from invoice reference number {order_ref_number}. Thank you for processing it.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have received all items from invoice reference number {order_ref_number}. Thank you for processing it. {business_name}',NULL,'Items received, from {business_name}',NULL,NULL,0,0,0,'2023-01-28 21:05:09','2023-01-28 21:05:09'),(44,5,'items_pending','<p>Dear {contact_name},<br />\n                    This is to remind you that we have not yet received some items from invoice reference number {order_ref_number}. Please process it as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','This is to remind you that we have not yet received some items from invoice reference number {order_ref_number} . Please process it as soon as possible.{business_name}',NULL,'Items Pending, from {business_name}',NULL,NULL,0,0,0,'2023-01-28 21:05:09','2023-01-28 21:05:09'),(45,5,'new_quotation','<p>Dear {contact_name},</p>\n\n                    <p>Your quotation number is {invoice_number}<br />\n                    Total amount: {total_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2023-01-28 21:05:09','2023-01-28 21:05:09'),(46,6,'new_sale','<p>Dear {contact_name},</p>\n\n                    <p>Your invoice number is {invoice_number}<br />\n                    Total amount: {total_amount}<br />\n                    Paid amount: {received_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2023-01-30 16:12:22','2023-01-30 16:12:22'),(47,6,'payment_received','<p>Dear {contact_name},</p>\n\n                <p>We have received a payment of {received_amount}</p>\n\n                <p>{business_logo}</p>','Dear {contact_name}, We have received a payment of {received_amount}. {business_name}',NULL,'Payment Received, from {business_name}',NULL,NULL,0,0,0,'2023-01-30 16:12:22','2023-01-30 16:12:22'),(48,6,'payment_reminder','<p>Dear {contact_name},</p>\n\n                    <p>This is to remind you that you have pending payment of {due_amount}. Kindly pay it as soon as possible.</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, You have pending payment of {due_amount}. Kindly pay it as soon as possible. {business_name}',NULL,'Payment Reminder, from {business_name}',NULL,NULL,0,0,0,'2023-01-30 16:12:22','2023-01-30 16:12:22'),(49,6,'new_booking','<p>Dear {contact_name},</p>\n\n                    <p>Your booking is confirmed</p>\n\n                    <p>Date: {start_time} to {end_time}</p>\n\n                    <p>Table: {table}</p>\n\n                    <p>Location: {location}</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, Your booking is confirmed. Date: {start_time} to {end_time}, Table: {table}, Location: {location}',NULL,'Booking Confirmed - {business_name}',NULL,NULL,0,0,0,'2023-01-30 16:12:22','2023-01-30 16:12:22'),(50,6,'new_order','<p>Dear {contact_name},</p>\n\n                    <p>We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','Dear {contact_name}, We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible. {business_name}',NULL,'New Order, from {business_name}',NULL,NULL,0,0,0,'2023-01-30 16:12:22','2023-01-30 16:12:22'),(51,6,'payment_paid','<p>Dear {contact_name},</p>\n\n                    <p>We have paid amount {paid_amount} again invoice number {order_ref_number}.<br />\n                    Kindly note it down.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have paid amount {paid_amount} again invoice number {order_ref_number}.\n                    Kindly note it down. {business_name}',NULL,'Payment Paid, from {business_name}',NULL,NULL,0,0,0,'2023-01-30 16:12:22','2023-01-30 16:12:22'),(52,6,'items_received','<p>Dear {contact_name},</p>\n\n                    <p>We have received all items from invoice reference number {order_ref_number}. Thank you for processing it.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have received all items from invoice reference number {order_ref_number}. Thank you for processing it. {business_name}',NULL,'Items received, from {business_name}',NULL,NULL,0,0,0,'2023-01-30 16:12:22','2023-01-30 16:12:22'),(53,6,'items_pending','<p>Dear {contact_name},<br />\n                    This is to remind you that we have not yet received some items from invoice reference number {order_ref_number}. Please process it as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','This is to remind you that we have not yet received some items from invoice reference number {order_ref_number} . Please process it as soon as possible.{business_name}',NULL,'Items Pending, from {business_name}',NULL,NULL,0,0,0,'2023-01-30 16:12:22','2023-01-30 16:12:22'),(54,6,'new_quotation','<p>Dear {contact_name},</p>\n\n                    <p>Your quotation number is {invoice_number}<br />\n                    Total amount: {total_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2023-01-30 16:12:22','2023-01-30 16:12:22'),(55,7,'new_sale','<p>Dear {contact_name},</p>\n\n                    <p>Your invoice number is {invoice_number}<br />\n                    Total amount: {total_amount}<br />\n                    Paid amount: {received_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2023-02-01 10:48:07','2023-02-01 10:48:07'),(56,7,'payment_received','<p>Dear {contact_name},</p>\n\n                <p>We have received a payment of {received_amount}</p>\n\n                <p>{business_logo}</p>','Dear {contact_name}, We have received a payment of {received_amount}. {business_name}',NULL,'Payment Received, from {business_name}',NULL,NULL,0,0,0,'2023-02-01 10:48:07','2023-02-01 10:48:07'),(57,7,'payment_reminder','<p>Dear {contact_name},</p>\n\n                    <p>This is to remind you that you have pending payment of {due_amount}. Kindly pay it as soon as possible.</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, You have pending payment of {due_amount}. Kindly pay it as soon as possible. {business_name}',NULL,'Payment Reminder, from {business_name}',NULL,NULL,0,0,0,'2023-02-01 10:48:07','2023-02-01 10:48:07'),(58,7,'new_booking','<p>Dear {contact_name},</p>\n\n                    <p>Your booking is confirmed</p>\n\n                    <p>Date: {start_time} to {end_time}</p>\n\n                    <p>Table: {table}</p>\n\n                    <p>Location: {location}</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, Your booking is confirmed. Date: {start_time} to {end_time}, Table: {table}, Location: {location}',NULL,'Booking Confirmed - {business_name}',NULL,NULL,0,0,0,'2023-02-01 10:48:07','2023-02-01 10:48:07'),(59,7,'new_order','<p>Dear {contact_name},</p>\n\n                    <p>We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','Dear {contact_name}, We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible. {business_name}',NULL,'New Order, from {business_name}',NULL,NULL,0,0,0,'2023-02-01 10:48:07','2023-02-01 10:48:07'),(60,7,'payment_paid','<p>Dear {contact_name},</p>\n\n                    <p>We have paid amount {paid_amount} again invoice number {order_ref_number}.<br />\n                    Kindly note it down.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have paid amount {paid_amount} again invoice number {order_ref_number}.\n                    Kindly note it down. {business_name}',NULL,'Payment Paid, from {business_name}',NULL,NULL,0,0,0,'2023-02-01 10:48:07','2023-02-01 10:48:07'),(61,7,'items_received','<p>Dear {contact_name},</p>\n\n                    <p>We have received all items from invoice reference number {order_ref_number}. Thank you for processing it.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have received all items from invoice reference number {order_ref_number}. Thank you for processing it. {business_name}',NULL,'Items received, from {business_name}',NULL,NULL,0,0,0,'2023-02-01 10:48:07','2023-02-01 10:48:07'),(62,7,'items_pending','<p>Dear {contact_name},<br />\n                    This is to remind you that we have not yet received some items from invoice reference number {order_ref_number}. Please process it as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','This is to remind you that we have not yet received some items from invoice reference number {order_ref_number} . Please process it as soon as possible.{business_name}',NULL,'Items Pending, from {business_name}',NULL,NULL,0,0,0,'2023-02-01 10:48:07','2023-02-01 10:48:07'),(63,7,'new_quotation','<p>Dear {contact_name},</p>\n\n                    <p>Your quotation number is {invoice_number}<br />\n                    Total amount: {total_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2023-02-01 10:48:07','2023-02-01 10:48:07'),(64,8,'new_sale','<p>Dear {contact_name},</p>\n\n                    <p>Your invoice number is {invoice_number}<br />\n                    Total amount: {total_amount}<br />\n                    Paid amount: {received_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2023-02-15 09:06:18','2023-02-15 09:06:18'),(65,8,'payment_received','<p>Dear {contact_name},</p>\n\n                <p>We have received a payment of {received_amount}</p>\n\n                <p>{business_logo}</p>','Dear {contact_name}, We have received a payment of {received_amount}. {business_name}',NULL,'Payment Received, from {business_name}',NULL,NULL,0,0,0,'2023-02-15 09:06:18','2023-02-15 09:06:18'),(66,8,'payment_reminder','<p>Dear {contact_name},</p>\n\n                    <p>This is to remind you that you have pending payment of {due_amount}. Kindly pay it as soon as possible.</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, You have pending payment of {due_amount}. Kindly pay it as soon as possible. {business_name}',NULL,'Payment Reminder, from {business_name}',NULL,NULL,0,0,0,'2023-02-15 09:06:18','2023-02-15 09:06:18'),(67,8,'new_booking','<p>Dear {contact_name},</p>\n\n                    <p>Your booking is confirmed</p>\n\n                    <p>Date: {start_time} to {end_time}</p>\n\n                    <p>Table: {table}</p>\n\n                    <p>Location: {location}</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, Your booking is confirmed. Date: {start_time} to {end_time}, Table: {table}, Location: {location}',NULL,'Booking Confirmed - {business_name}',NULL,NULL,0,0,0,'2023-02-15 09:06:18','2023-02-15 09:06:18'),(68,8,'new_order','<p>Dear {contact_name},</p>\n\n                    <p>We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','Dear {contact_name}, We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible. {business_name}',NULL,'New Order, from {business_name}',NULL,NULL,0,0,0,'2023-02-15 09:06:18','2023-02-15 09:06:18'),(69,8,'payment_paid','<p>Dear {contact_name},</p>\n\n                    <p>We have paid amount {paid_amount} again invoice number {order_ref_number}.<br />\n                    Kindly note it down.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have paid amount {paid_amount} again invoice number {order_ref_number}.\n                    Kindly note it down. {business_name}',NULL,'Payment Paid, from {business_name}',NULL,NULL,0,0,0,'2023-02-15 09:06:18','2023-02-15 09:06:18'),(70,8,'items_received','<p>Dear {contact_name},</p>\n\n                    <p>We have received all items from invoice reference number {order_ref_number}. Thank you for processing it.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have received all items from invoice reference number {order_ref_number}. Thank you for processing it. {business_name}',NULL,'Items received, from {business_name}',NULL,NULL,0,0,0,'2023-02-15 09:06:18','2023-02-15 09:06:18'),(71,8,'items_pending','<p>Dear {contact_name},<br />\n                    This is to remind you that we have not yet received some items from invoice reference number {order_ref_number}. Please process it as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','This is to remind you that we have not yet received some items from invoice reference number {order_ref_number} . Please process it as soon as possible.{business_name}',NULL,'Items Pending, from {business_name}',NULL,NULL,0,0,0,'2023-02-15 09:06:18','2023-02-15 09:06:18'),(72,8,'new_quotation','<p>Dear {contact_name},</p>\n\n                    <p>Your quotation number is {invoice_number}<br />\n                    Total amount: {total_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2023-02-15 09:06:18','2023-02-15 09:06:18'),(73,9,'new_sale','<p>Dear {contact_name},</p>\n\n                    <p>Your invoice number is {invoice_number}<br />\n                    Total amount: {total_amount}<br />\n                    Paid amount: {received_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2023-03-06 13:58:51','2023-03-06 13:58:51'),(74,9,'payment_received','<p>Dear {contact_name},</p>\n\n                <p>We have received a payment of {received_amount}</p>\n\n                <p>{business_logo}</p>','Dear {contact_name}, We have received a payment of {received_amount}. {business_name}',NULL,'Payment Received, from {business_name}',NULL,NULL,0,0,0,'2023-03-06 13:58:51','2023-03-06 13:58:51'),(75,9,'payment_reminder','<p>Dear {contact_name},</p>\n\n                    <p>This is to remind you that you have pending payment of {due_amount}. Kindly pay it as soon as possible.</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, You have pending payment of {due_amount}. Kindly pay it as soon as possible. {business_name}',NULL,'Payment Reminder, from {business_name}',NULL,NULL,0,0,0,'2023-03-06 13:58:51','2023-03-06 13:58:51'),(76,9,'new_booking','<p>Dear {contact_name},</p>\n\n                    <p>Your booking is confirmed</p>\n\n                    <p>Date: {start_time} to {end_time}</p>\n\n                    <p>Table: {table}</p>\n\n                    <p>Location: {location}</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, Your booking is confirmed. Date: {start_time} to {end_time}, Table: {table}, Location: {location}',NULL,'Booking Confirmed - {business_name}',NULL,NULL,0,0,0,'2023-03-06 13:58:51','2023-03-06 13:58:51'),(77,9,'new_order','<p>Dear {contact_name},</p>\n\n                    <p>We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','Dear {contact_name}, We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible. {business_name}',NULL,'New Order, from {business_name}',NULL,NULL,0,0,0,'2023-03-06 13:58:51','2023-03-06 13:58:51'),(78,9,'payment_paid','<p>Dear {contact_name},</p>\n\n                    <p>We have paid amount {paid_amount} again invoice number {order_ref_number}.<br />\n                    Kindly note it down.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have paid amount {paid_amount} again invoice number {order_ref_number}.\n                    Kindly note it down. {business_name}',NULL,'Payment Paid, from {business_name}',NULL,NULL,0,0,0,'2023-03-06 13:58:51','2023-03-06 13:58:51'),(79,9,'items_received','<p>Dear {contact_name},</p>\n\n                    <p>We have received all items from invoice reference number {order_ref_number}. Thank you for processing it.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have received all items from invoice reference number {order_ref_number}. Thank you for processing it. {business_name}',NULL,'Items received, from {business_name}',NULL,NULL,0,0,0,'2023-03-06 13:58:51','2023-03-06 13:58:51'),(80,9,'items_pending','<p>Dear {contact_name},<br />\n                    This is to remind you that we have not yet received some items from invoice reference number {order_ref_number}. Please process it as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','This is to remind you that we have not yet received some items from invoice reference number {order_ref_number} . Please process it as soon as possible.{business_name}',NULL,'Items Pending, from {business_name}',NULL,NULL,0,0,0,'2023-03-06 13:58:51','2023-03-06 13:58:51'),(81,9,'new_quotation','<p>Dear {contact_name},</p>\n\n                    <p>Your quotation number is {invoice_number}<br />\n                    Total amount: {total_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2023-03-06 13:58:51','2023-03-06 13:58:51'),(82,10,'new_sale','<p>Dear {contact_name},</p>\n\n                    <p>Your invoice number is {invoice_number}<br />\n                    Total amount: {total_amount}<br />\n                    Paid amount: {received_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2023-03-21 16:07:24','2023-03-21 16:07:24'),(83,10,'payment_received','<p>Dear {contact_name},</p>\n\n                <p>We have received a payment of {received_amount}</p>\n\n                <p>{business_logo}</p>','Dear {contact_name}, We have received a payment of {received_amount}. {business_name}',NULL,'Payment Received, from {business_name}',NULL,NULL,0,0,0,'2023-03-21 16:07:24','2023-03-21 16:07:24'),(84,10,'payment_reminder','<p>Dear {contact_name},</p>\n\n                    <p>This is to remind you that you have pending payment of {due_amount}. Kindly pay it as soon as possible.</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, You have pending payment of {due_amount}. Kindly pay it as soon as possible. {business_name}',NULL,'Payment Reminder, from {business_name}',NULL,NULL,0,0,0,'2023-03-21 16:07:24','2023-03-21 16:07:24'),(85,10,'new_booking','<p>Dear {contact_name},</p>\n\n                    <p>Your booking is confirmed</p>\n\n                    <p>Date: {start_time} to {end_time}</p>\n\n                    <p>Table: {table}</p>\n\n                    <p>Location: {location}</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, Your booking is confirmed. Date: {start_time} to {end_time}, Table: {table}, Location: {location}',NULL,'Booking Confirmed - {business_name}',NULL,NULL,0,0,0,'2023-03-21 16:07:24','2023-03-21 16:07:24'),(86,10,'new_order','<p>Dear {contact_name},</p>\n\n                    <p>We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','Dear {contact_name}, We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible. {business_name}',NULL,'New Order, from {business_name}',NULL,NULL,0,0,0,'2023-03-21 16:07:24','2023-03-21 16:07:24'),(87,10,'payment_paid','<p>Dear {contact_name},</p>\n\n                    <p>We have paid amount {paid_amount} again invoice number {order_ref_number}.<br />\n                    Kindly note it down.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have paid amount {paid_amount} again invoice number {order_ref_number}.\n                    Kindly note it down. {business_name}',NULL,'Payment Paid, from {business_name}',NULL,NULL,0,0,0,'2023-03-21 16:07:24','2023-03-21 16:07:24'),(88,10,'items_received','<p>Dear {contact_name},</p>\n\n                    <p>We have received all items from invoice reference number {order_ref_number}. Thank you for processing it.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have received all items from invoice reference number {order_ref_number}. Thank you for processing it. {business_name}',NULL,'Items received, from {business_name}',NULL,NULL,0,0,0,'2023-03-21 16:07:24','2023-03-21 16:07:24'),(89,10,'items_pending','<p>Dear {contact_name},<br />\n                    This is to remind you that we have not yet received some items from invoice reference number {order_ref_number}. Please process it as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','This is to remind you that we have not yet received some items from invoice reference number {order_ref_number} . Please process it as soon as possible.{business_name}',NULL,'Items Pending, from {business_name}',NULL,NULL,0,0,0,'2023-03-21 16:07:24','2023-03-21 16:07:24'),(90,10,'new_quotation','<p>Dear {contact_name},</p>\n\n                    <p>Your quotation number is {invoice_number}<br />\n                    Total amount: {total_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2023-03-21 16:07:24','2023-03-21 16:07:24'),(91,11,'new_sale','<p>Dear {contact_name},</p>\n\n                    <p>Your invoice number is {invoice_number}<br />\n                    Total amount: {total_amount}<br />\n                    Paid amount: {received_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2023-03-22 12:12:28','2023-03-22 12:12:28'),(92,11,'payment_received','<p>Dear {contact_name},</p>\n\n                <p>We have received a payment of {received_amount}</p>\n\n                <p>{business_logo}</p>','Dear {contact_name}, We have received a payment of {received_amount}. {business_name}',NULL,'Payment Received, from {business_name}',NULL,NULL,0,0,0,'2023-03-22 12:12:28','2023-03-22 12:12:28'),(93,11,'payment_reminder','<p>Dear {contact_name},</p>\n\n                    <p>This is to remind you that you have pending payment of {due_amount}. Kindly pay it as soon as possible.</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, You have pending payment of {due_amount}. Kindly pay it as soon as possible. {business_name}',NULL,'Payment Reminder, from {business_name}',NULL,NULL,0,0,0,'2023-03-22 12:12:28','2023-03-22 12:12:28'),(94,11,'new_booking','<p>Dear {contact_name},</p>\n\n                    <p>Your booking is confirmed</p>\n\n                    <p>Date: {start_time} to {end_time}</p>\n\n                    <p>Table: {table}</p>\n\n                    <p>Location: {location}</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, Your booking is confirmed. Date: {start_time} to {end_time}, Table: {table}, Location: {location}',NULL,'Booking Confirmed - {business_name}',NULL,NULL,0,0,0,'2023-03-22 12:12:28','2023-03-22 12:12:28'),(95,11,'new_order','<p>Dear {contact_name},</p>\n\n                    <p>We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','Dear {contact_name}, We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible. {business_name}',NULL,'New Order, from {business_name}',NULL,NULL,0,0,0,'2023-03-22 12:12:28','2023-03-22 12:12:28'),(96,11,'payment_paid','<p>Dear {contact_name},</p>\n\n                    <p>We have paid amount {paid_amount} again invoice number {order_ref_number}.<br />\n                    Kindly note it down.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have paid amount {paid_amount} again invoice number {order_ref_number}.\n                    Kindly note it down. {business_name}',NULL,'Payment Paid, from {business_name}',NULL,NULL,0,0,0,'2023-03-22 12:12:28','2023-03-22 12:12:28'),(97,11,'items_received','<p>Dear {contact_name},</p>\n\n                    <p>We have received all items from invoice reference number {order_ref_number}. Thank you for processing it.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have received all items from invoice reference number {order_ref_number}. Thank you for processing it. {business_name}',NULL,'Items received, from {business_name}',NULL,NULL,0,0,0,'2023-03-22 12:12:28','2023-03-22 12:12:28'),(98,11,'items_pending','<p>Dear {contact_name},<br />\n                    This is to remind you that we have not yet received some items from invoice reference number {order_ref_number}. Please process it as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','This is to remind you that we have not yet received some items from invoice reference number {order_ref_number} . Please process it as soon as possible.{business_name}',NULL,'Items Pending, from {business_name}',NULL,NULL,0,0,0,'2023-03-22 12:12:28','2023-03-22 12:12:28'),(99,11,'new_quotation','<p>Dear {contact_name},</p>\n\n                    <p>Your quotation number is {invoice_number}<br />\n                    Total amount: {total_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2023-03-22 12:12:28','2023-03-22 12:12:28');
/*!40000 ALTER TABLE `notification_templates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `client_id` int unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_access_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_access_tokens` DISABLE KEYS */;
INSERT INTO `oauth_access_tokens` VALUES ('0729fb7a98981732bddaf88b97b7b89a402f77a9be8dd459d2161b8da06f7c40cca2a9771487c31a',2,6,NULL,'[]',0,'2023-01-28 11:54:25','2023-01-28 11:54:25','2024-01-28 11:54:25'),('377454127239f28cfde0327dc32e3f0f06a4901f145dbd4543447cd573ddaf128216b6ff8e8f9fc4',6,1,NULL,'[]',0,'2023-01-30 16:05:17','2023-01-30 16:05:17','2024-01-30 16:05:17'),('388e24304900f8aed4b7749586b461aaf96f74b8eaf42f692784af843e82b2ae01732078981c5156',5,1,NULL,'[]',0,'2023-01-30 16:01:26','2023-01-30 16:01:26','2024-01-30 16:01:26'),('4a0aaf17f447a89ff554334413c101e9a7d5ed3b440adf18869e1d46f43a81412d71f580872db8d2',1,1,NULL,'[]',0,'2023-01-30 15:58:16','2023-01-30 15:58:16','2024-01-30 15:58:16'),('b3016a07182bf6a267d0dce8328dc455f4cef4a8c022ad314a51d86d5a9f7694f63e40a219e05840',4,1,NULL,'[]',0,'2023-01-30 16:04:40','2023-01-30 16:04:40','2024-01-30 16:04:40'),('c3953d8754e95d86c7fffd0a63f32f302638b73b5570a43bbd5f098e51ee02b52867a1df94af4f8d',1,1,NULL,'[]',0,'2023-01-28 11:44:20','2023-01-28 11:44:20','2024-01-28 11:44:20'),('cb1e52d4eeabdfbcfb683dc65c02b78b83014298a08bee773d01dd94b5d1840eeafa79f3ef68198a',2,1,NULL,'[]',0,'2023-01-28 11:52:29','2023-01-28 11:52:29','2024-01-28 11:52:29'),('f8cab216e0c4697e5dadb008a4f22989ef2d19a8f36f28836abb46142cb2198bd73948ed940c96e6',2,1,NULL,'[]',0,'2023-01-28 11:52:42','2023-01-28 11:52:42','2024-01-28 11:52:42');
/*!40000 ALTER TABLE `oauth_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_auth_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint NOT NULL,
  `client_id` int unsigned NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_auth_codes` WRITE;
/*!40000 ALTER TABLE `oauth_auth_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_auth_codes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_clients` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;
INSERT INTO `oauth_clients` VALUES (1,1,'mi cliente 1','5UKnYCsY6IZm8wUCDv1YsLCtIn59HTfQtQkhNIEf','http://localhost',0,1,0,'2023-01-27 16:59:57','2023-01-27 16:59:57'),(2,NULL,'Ultimate POS Personal Access Client','Lof7e7MiqcQv3OnRpwCfUMXNUlfvw4Ahf4Vbavj3','http://localhost',1,0,0,'2023-01-28 11:43:19','2023-01-28 11:43:19'),(3,NULL,'Ultimate POS Password Grant Client','rNOIuaP4gmZ25w5v9nAKXot0Kbu6Cs5jR93ob7b6','http://localhost',0,1,0,'2023-01-28 11:43:19','2023-01-28 11:43:19'),(4,NULL,'Ultimate POS Personal Access Client','oZqRk9bOPtuEuYqTpVKdHrPyKCU4N2FiYSSyDKND','http://localhost',1,0,0,'2023-01-28 11:43:45','2023-01-28 11:43:45'),(5,NULL,'Ultimate POS Password Grant Client','uG68b4FeJFV1uMRLrqiFJUDDA4xuSNnXmnOrB1HI','http://localhost',0,1,0,'2023-01-28 11:43:45','2023-01-28 11:43:45'),(6,1,'skot','2hjmCE4kB6OZng8YRjSOATEv4GQna3QNY2KQTgGT','http://localhost',0,1,0,'2023-01-28 11:53:23','2023-01-28 11:53:23'),(7,NULL,'Ultimate POS Personal Access Client','Y4pgnJMI3UmZ1r2x3lIHKtbcoOS7vJcUvSoBpbou','http://localhost',1,0,0,'2023-01-28 11:53:27','2023-01-28 11:53:27'),(8,NULL,'Ultimate POS Password Grant Client','UzXtKOIc58Hx14PO2haYuqI4jQmeMTNXGU3G82ge','http://localhost',0,1,0,'2023-01-28 11:53:27','2023-01-28 11:53:27');
/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_personal_access_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_personal_access_clients` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_personal_access_clients_client_id_index` (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_personal_access_clients` WRITE;
/*!40000 ALTER TABLE `oauth_personal_access_clients` DISABLE KEYS */;
INSERT INTO `oauth_personal_access_clients` VALUES (1,2,'2023-01-28 11:43:19','2023-01-28 11:43:19'),(2,4,'2023-01-28 11:43:45','2023-01-28 11:43:45'),(3,7,'2023-01-28 11:53:27','2023-01-28 11:53:27');
/*!40000 ALTER TABLE `oauth_personal_access_clients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_refresh_tokens` DISABLE KEYS */;
INSERT INTO `oauth_refresh_tokens` VALUES ('1a850fa49fc832225db9ab3afc54b2311073be7966d48e51a2149e4e2518bea0e692877c6c8914c9','4a0aaf17f447a89ff554334413c101e9a7d5ed3b440adf18869e1d46f43a81412d71f580872db8d2',0,'2024-01-30 15:58:16'),('1d92901e8db63050128ea7f211b96c8da207273cccc8ab2f05eb15afeba8edfab48dffa62f94b4e6','cb1e52d4eeabdfbcfb683dc65c02b78b83014298a08bee773d01dd94b5d1840eeafa79f3ef68198a',0,'2024-01-28 11:52:29'),('400cf5ad3cd9cb20ff244709020ece251adf54114b0ac76d3d7f6863072d28c1b09a04f5fa5e487d','388e24304900f8aed4b7749586b461aaf96f74b8eaf42f692784af843e82b2ae01732078981c5156',0,'2024-01-30 16:01:26'),('45628e9c99a082004d164ebc0493d0f4766ff61971458b6004408accceb37a2d0316e844ffc65999','c3953d8754e95d86c7fffd0a63f32f302638b73b5570a43bbd5f098e51ee02b52867a1df94af4f8d',0,'2024-01-28 11:44:20'),('94db071dee0504afb6ade7b72273c745fdcd0a48ceb8e68f1cb6f2577357d562a7b1fd0b7d71a622','0729fb7a98981732bddaf88b97b7b89a402f77a9be8dd459d2161b8da06f7c40cca2a9771487c31a',0,'2024-01-28 11:54:25'),('b7bd0485fc0b5005adac42fbb08ed3de4b2c99679794d57d421df46ef3281befb594c1be5d349bca','b3016a07182bf6a267d0dce8328dc455f4cef4a8c022ad314a51d86d5a9f7694f63e40a219e05840',0,'2024-01-30 16:04:40'),('ca27d14f00d00ec22a48fedbdaea3a8e54b8468c94dee46f55d2114dad88d139168aa109db0688b3','377454127239f28cfde0327dc32e3f0f06a4901f145dbd4543447cd573ddaf128216b6ff8e8f9fc4',0,'2024-01-30 16:05:17'),('f38d40f451c78cafd02328016ef554555fd4b353986df3a3c570521d04ed2d88e1eb66c2b8f30b5d','f8cab216e0c4697e5dadb008a4f22989ef2d19a8f36f28836abb46142cb2198bd73948ed940c96e6',0,'2024-01-28 11:52:42');
/*!40000 ALTER TABLE `oauth_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `packages` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_count` int NOT NULL COMMENT 'No. of Business Locations, 0 = infinite option.',
  `user_count` int NOT NULL,
  `product_count` int NOT NULL,
  `bookings` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Enable/Disable bookings',
  `kitchen` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Enable/Disable kitchen',
  `order_screen` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Enable/Disable order_screen',
  `tables` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Enable/Disable tables',
  `invoice_count` int NOT NULL,
  `interval` enum('days','months','years') COLLATE utf8mb4_unicode_ci NOT NULL,
  `interval_count` int NOT NULL,
  `trial_days` int NOT NULL,
  `price` decimal(22,4) NOT NULL,
  `custom_permissions` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL,
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `is_one_time` tinyint(1) NOT NULL DEFAULT '0',
  `enable_custom_link` tinyint(1) NOT NULL DEFAULT '0',
  `custom_link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_link_text` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `packages` WRITE;
/*!40000 ALTER TABLE `packages` DISABLE KEYS */;
INSERT INTO `packages` VALUES (1,'Gratis','pakete gratis de uso',1,1,10,0,0,0,0,100,'years',1,0,0.0000,'',1,1,1,0,0,0,'','',NULL,'2023-01-26 16:21:12','2023-03-22 14:57:55'),(2,'Packete Basico','packete basico para negocio pequeños',3,5,500,0,0,0,0,1000,'years',1,0,2100.0000,'',1,1,1,0,1,0,'','',NULL,'2023-01-26 16:25:16','2023-03-22 14:58:04');
/*!40000 ALTER TABLE `packages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'profit_loss_report.view','web','2023-01-26 15:38:35',NULL),(2,'direct_sell.access','web','2023-01-26 15:38:35',NULL),(3,'product.opening_stock','web','2023-01-26 15:38:37','2023-01-26 15:38:37'),(4,'crud_all_bookings','web','2023-01-26 15:38:38','2023-01-26 15:38:38'),(5,'crud_own_bookings','web','2023-01-26 15:38:38','2023-01-26 15:38:38'),(6,'access_default_selling_price','web','2023-01-26 15:38:40','2023-01-26 15:38:40'),(7,'purchase.payments','web','2023-01-26 15:38:41','2023-01-26 15:38:41'),(8,'sell.payments','web','2023-01-26 15:38:41','2023-01-26 15:38:41'),(9,'edit_product_price_from_sale_screen','web','2023-01-26 15:38:41','2023-01-26 15:38:41'),(10,'edit_product_discount_from_sale_screen','web','2023-01-26 15:38:41','2023-01-26 15:38:41'),(11,'roles.view','web','2023-01-26 15:38:41','2023-01-26 15:38:41'),(12,'roles.create','web','2023-01-26 15:38:41','2023-01-26 15:38:41'),(13,'roles.update','web','2023-01-26 15:38:41','2023-01-26 15:38:41'),(14,'roles.delete','web','2023-01-26 15:38:41','2023-01-26 15:38:41'),(15,'woocommerce.syc_categories','web','2023-01-26 15:38:42','2023-01-26 15:38:42'),(16,'woocommerce.sync_products','web','2023-01-26 15:38:42','2023-01-26 15:38:42'),(17,'woocommerce.sync_orders','web','2023-01-26 15:38:42','2023-01-26 15:38:42'),(18,'woocommerce.map_tax_rates','web','2023-01-26 15:38:42','2023-01-26 15:38:42'),(19,'woocommerce.access_woocommerce_api_settings','web','2023-01-26 15:38:42','2023-01-26 15:38:42'),(20,'account.access','web','2023-01-26 15:38:42','2023-01-26 15:38:42'),(21,'discount.access','web','2023-01-26 15:38:42','2023-01-26 15:38:42'),(22,'essentials.create_message','web','2023-01-26 15:38:43','2023-01-26 15:38:43'),(23,'essentials.view_message','web','2023-01-26 15:38:43','2023-01-26 15:38:43'),(24,'repair.create','web','2023-01-26 15:38:43','2023-01-26 15:38:43'),(25,'repair.update','web','2023-01-26 15:38:43','2023-01-26 15:38:43'),(26,'repair.view','web','2023-01-26 15:38:43','2023-01-26 15:38:43'),(27,'repair.delete','web','2023-01-26 15:38:43','2023-01-26 15:38:43'),(28,'repair_status.update','web','2023-01-26 15:38:43','2023-01-26 15:38:43'),(29,'repair_status.access','web','2023-01-26 15:38:43','2023-01-26 15:38:43'),(30,'view_purchase_price','web','2023-01-26 15:38:44','2023-01-26 15:38:44'),(31,'view_own_sell_only','web','2023-01-26 15:38:44','2023-01-26 15:38:44'),(32,'manufacturing.access_recipe','web','2023-01-26 15:38:45','2023-01-26 15:38:45'),(33,'manufacturing.access_production','web','2023-01-26 15:38:45','2023-01-26 15:38:45'),(34,'manufacturing.add_recipe','web','2023-01-26 15:38:45','2023-01-26 15:38:45'),(35,'manufacturing.edit_recipe','web','2023-01-26 15:38:45','2023-01-26 15:38:45'),(36,'essentials.approve_leave','web','2023-01-26 15:38:45','2023-01-26 15:38:45'),(37,'edit_product_discount_from_pos_screen','web','2023-01-26 15:38:46','2023-01-26 15:38:46'),(38,'edit_product_price_from_pos_screen','web','2023-01-26 15:38:46','2023-01-26 15:38:46'),(39,'access_shipping','web','2023-01-26 15:38:46','2023-01-26 15:38:46'),(40,'essentials.assign_todos','web','2023-01-26 15:38:46','2023-01-26 15:38:46'),(41,'purchase.update_status','web','2023-01-26 15:38:46','2023-01-26 15:38:46'),(42,'essentials.add_allowance_and_deduction','web','2023-01-26 15:38:48','2023-01-26 15:38:48'),(43,'list_drafts','web','2023-01-26 15:38:48','2023-01-26 15:38:48'),(44,'list_quotations','web','2023-01-26 15:38:48','2023-01-26 15:38:48'),(45,'project.create_project','web','2023-01-26 15:38:48','2023-01-26 15:38:48'),(46,'project.edit_project','web','2023-01-26 15:38:48','2023-01-26 15:38:48'),(47,'project.delete_project','web','2023-01-26 15:38:48','2023-01-26 15:38:48'),(48,'view_cash_register','web','2023-01-26 15:38:55','2023-01-26 15:38:55'),(49,'close_cash_register','web','2023-01-26 15:38:55','2023-01-26 15:38:55'),(50,'print_invoice','web','2023-01-26 15:39:06','2023-01-26 15:39:06'),(51,'user.view','web','2023-01-26 15:55:27',NULL),(52,'user.create','web','2023-01-26 15:55:27',NULL),(53,'user.update','web','2023-01-26 15:55:27',NULL),(54,'user.delete','web','2023-01-26 15:55:27',NULL),(55,'supplier.view','web','2023-01-26 15:55:27',NULL),(56,'supplier.create','web','2023-01-26 15:55:27',NULL),(57,'supplier.update','web','2023-01-26 15:55:27',NULL),(58,'supplier.delete','web','2023-01-26 15:55:27',NULL),(59,'customer.view','web','2023-01-26 15:55:27',NULL),(60,'customer.create','web','2023-01-26 15:55:27',NULL),(61,'customer.update','web','2023-01-26 15:55:27',NULL),(62,'customer.delete','web','2023-01-26 15:55:27',NULL),(63,'product.view','web','2023-01-26 15:55:27',NULL),(64,'product.create','web','2023-01-26 15:55:27',NULL),(65,'product.update','web','2023-01-26 15:55:27',NULL),(66,'product.delete','web','2023-01-26 15:55:27',NULL),(67,'purchase.view','web','2023-01-26 15:55:27',NULL),(68,'purchase.create','web','2023-01-26 15:55:27',NULL),(69,'purchase.update','web','2023-01-26 15:55:27',NULL),(70,'purchase.delete','web','2023-01-26 15:55:27',NULL),(71,'sell.view','web','2023-01-26 15:55:27',NULL),(72,'sell.create','web','2023-01-26 15:55:27',NULL),(73,'sell.update','web','2023-01-26 15:55:27',NULL),(74,'sell.delete','web','2023-01-26 15:55:27',NULL),(75,'purchase_n_sell_report.view','web','2023-01-26 15:55:27',NULL),(76,'contacts_report.view','web','2023-01-26 15:55:27',NULL),(77,'stock_report.view','web','2023-01-26 15:55:27',NULL),(78,'tax_report.view','web','2023-01-26 15:55:27',NULL),(79,'trending_product_report.view','web','2023-01-26 15:55:27',NULL),(80,'register_report.view','web','2023-01-26 15:55:27',NULL),(81,'sales_representative.view','web','2023-01-26 15:55:27',NULL),(82,'expense_report.view','web','2023-01-26 15:55:27',NULL),(83,'business_settings.access','web','2023-01-26 15:55:27',NULL),(84,'barcode_settings.access','web','2023-01-26 15:55:27',NULL),(85,'invoice_settings.access','web','2023-01-26 15:55:27',NULL),(86,'brand.view','web','2023-01-26 15:55:27',NULL),(87,'brand.create','web','2023-01-26 15:55:27',NULL),(88,'brand.update','web','2023-01-26 15:55:27',NULL),(89,'brand.delete','web','2023-01-26 15:55:27',NULL),(90,'tax_rate.view','web','2023-01-26 15:55:27',NULL),(91,'tax_rate.create','web','2023-01-26 15:55:27',NULL),(92,'tax_rate.update','web','2023-01-26 15:55:27',NULL),(93,'tax_rate.delete','web','2023-01-26 15:55:27',NULL),(94,'unit.view','web','2023-01-26 15:55:27',NULL),(95,'unit.create','web','2023-01-26 15:55:27',NULL),(96,'unit.update','web','2023-01-26 15:55:27',NULL),(97,'unit.delete','web','2023-01-26 15:55:27',NULL),(98,'category.view','web','2023-01-26 15:55:27',NULL),(99,'category.create','web','2023-01-26 15:55:27',NULL),(100,'category.update','web','2023-01-26 15:55:27',NULL),(101,'category.delete','web','2023-01-26 15:55:27',NULL),(102,'expense.access','web','2023-01-26 15:55:27',NULL),(103,'access_all_locations','web','2023-01-26 15:55:27',NULL),(104,'dashboard.data','web','2023-01-26 15:55:27',NULL),(105,'location.1','web','2023-01-26 15:59:33','2023-01-26 15:59:33'),(106,'location.2','web','2023-01-26 16:42:31','2023-01-26 16:42:31'),(107,'location.3','web','2023-01-26 17:29:10','2023-01-26 17:29:10'),(108,'location.4','web','2023-01-26 17:31:14','2023-01-26 17:31:14'),(109,'location.5','web','2023-01-26 19:20:15','2023-01-26 19:20:15'),(110,'location.6','web','2023-01-26 20:28:14','2023-01-26 20:28:14'),(111,'view_paid_sells_only','web','2023-01-26 21:01:51','2023-01-26 21:01:51'),(112,'view_due_sells_only','web','2023-01-26 21:01:51','2023-01-26 21:01:51'),(113,'view_partial_sells_only','web','2023-01-26 21:01:51','2023-01-26 21:01:51'),(114,'view_overdue_sells_only','web','2023-01-26 21:01:51','2023-01-26 21:01:51'),(115,'direct_sell.update','web','2023-01-26 21:01:51','2023-01-26 21:01:51'),(116,'direct_sell.delete','web','2023-01-26 21:01:51','2023-01-26 21:01:51'),(117,'view_commission_agent_sell','web','2023-01-26 21:01:51','2023-01-26 21:01:51'),(118,'access_sell_return','web','2023-01-26 21:01:51','2023-01-26 21:01:51'),(119,'access_own_sell_return','web','2023-01-26 21:01:51','2023-01-26 21:01:51'),(120,'edit_invoice_number','web','2023-01-26 21:01:51','2023-01-26 21:01:51'),(121,'access_pending_shipments_only','web','2023-01-26 21:01:51','2023-01-26 21:01:51'),(122,'access_commission_agent_shipping','web','2023-01-26 21:01:51','2023-01-26 21:01:51'),(123,'customer.view_own','web','2023-01-26 21:01:52','2023-01-26 21:01:52'),(124,'customer_with_no_sell_one_year','web','2023-01-26 21:01:52','2023-01-26 21:01:52'),(125,'access_own_shipping','web','2023-01-26 21:01:52','2023-01-26 21:01:52'),(126,'location.7','web','2023-01-28 21:05:09','2023-01-28 21:05:09'),(127,'location.8','web','2023-01-30 16:12:22','2023-01-30 16:12:22'),(128,'location.9','web','2023-02-01 10:48:08','2023-02-01 10:48:08'),(129,'location.10','web','2023-02-15 09:06:18','2023-02-15 09:06:18'),(130,'view_product_stock_value','web','2023-02-17 10:37:00','2023-02-17 10:37:00'),(131,'access_tables','web','2023-02-17 10:37:00','2023-02-17 10:37:00'),(132,'view_own_purchase','web','2023-02-17 10:37:00','2023-02-17 10:37:00'),(133,'expense.add','web','2023-02-17 15:49:10','2023-02-17 15:49:10'),(134,'expense.edit','web','2023-02-17 15:49:10','2023-02-17 15:49:10'),(135,'expense.delete','web','2023-02-17 15:49:10','2023-02-17 15:49:10'),(136,'view_own_expense','web','2023-02-17 15:49:10','2023-02-17 15:49:10'),(137,'location.11','web','2023-03-06 13:58:51','2023-03-06 13:58:51'),(138,'location.12','web','2023-03-21 16:07:24','2023-03-21 16:07:24'),(139,'location.13','web','2023-03-22 12:12:28','2023-03-22 12:12:28');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pjt_invoice_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pjt_invoice_lines` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` int unsigned NOT NULL,
  `task` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `rate` decimal(22,4) NOT NULL,
  `tax_rate_id` int DEFAULT NULL,
  `quantity` decimal(22,4) NOT NULL,
  `total` decimal(22,4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pjt_invoice_lines_transaction_id_foreign` (`transaction_id`),
  KEY `pjt_invoice_lines_tax_rate_id_index` (`tax_rate_id`),
  CONSTRAINT `pjt_invoice_lines_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pjt_invoice_lines` WRITE;
/*!40000 ALTER TABLE `pjt_invoice_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `pjt_invoice_lines` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pjt_project_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pjt_project_members` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int unsigned NOT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pjt_project_members_project_id_foreign` (`project_id`),
  KEY `pjt_project_members_user_id_index` (`user_id`),
  CONSTRAINT `pjt_project_members_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `pjt_projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pjt_project_members` WRITE;
/*!40000 ALTER TABLE `pjt_project_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `pjt_project_members` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pjt_project_task_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pjt_project_task_comments` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `project_task_id` int unsigned NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `commented_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pjt_project_task_comments_project_task_id_foreign` (`project_task_id`),
  CONSTRAINT `pjt_project_task_comments_project_task_id_foreign` FOREIGN KEY (`project_task_id`) REFERENCES `pjt_project_tasks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pjt_project_task_comments` WRITE;
/*!40000 ALTER TABLE `pjt_project_task_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `pjt_project_task_comments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pjt_project_task_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pjt_project_task_members` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `project_task_id` int unsigned NOT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pjt_project_task_members_project_task_id_foreign` (`project_task_id`),
  KEY `pjt_project_task_members_user_id_index` (`user_id`),
  CONSTRAINT `pjt_project_task_members_project_task_id_foreign` FOREIGN KEY (`project_task_id`) REFERENCES `pjt_project_tasks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pjt_project_task_members` WRITE;
/*!40000 ALTER TABLE `pjt_project_task_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `pjt_project_task_members` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pjt_project_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pjt_project_tasks` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int NOT NULL,
  `project_id` int unsigned NOT NULL,
  `task_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` datetime DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `priority` enum('low','medium','high','urgent') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'low',
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_by` int NOT NULL,
  `status` enum('completed','not_started','in_progress','on_hold','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'not_started',
  `custom_field_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pjt_project_tasks_project_id_foreign` (`project_id`),
  KEY `pjt_project_tasks_business_id_index` (`business_id`),
  KEY `pjt_project_tasks_created_by_index` (`created_by`),
  CONSTRAINT `pjt_project_tasks_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `pjt_projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pjt_project_tasks` WRITE;
/*!40000 ALTER TABLE `pjt_project_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `pjt_project_tasks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pjt_project_time_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pjt_project_time_logs` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int unsigned NOT NULL,
  `project_task_id` int unsigned DEFAULT NULL,
  `user_id` int NOT NULL,
  `start_datetime` datetime NOT NULL,
  `end_datetime` datetime NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pjt_project_time_logs_project_id_foreign` (`project_id`),
  KEY `pjt_project_time_logs_project_task_id_foreign` (`project_task_id`),
  KEY `pjt_project_time_logs_user_id_index` (`user_id`),
  KEY `pjt_project_time_logs_created_by_index` (`created_by`),
  CONSTRAINT `pjt_project_time_logs_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `pjt_projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pjt_project_time_logs_project_task_id_foreign` FOREIGN KEY (`project_task_id`) REFERENCES `pjt_project_tasks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pjt_project_time_logs` WRITE;
/*!40000 ALTER TABLE `pjt_project_time_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `pjt_project_time_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pjt_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pjt_projects` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_id` int DEFAULT NULL,
  `status` enum('not_started','in_progress','on_hold','cancelled','completed') COLLATE utf8mb4_unicode_ci NOT NULL,
  `lead_id` int NOT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_by` int NOT NULL,
  `settings` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pjt_projects_business_id_index` (`business_id`),
  KEY `pjt_projects_contact_id_index` (`contact_id`),
  KEY `pjt_projects_lead_id_index` (`lead_id`),
  KEY `pjt_projects_created_by_index` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pjt_projects` WRITE;
/*!40000 ALTER TABLE `pjt_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `pjt_projects` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `printers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `printers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection_type` enum('network','windows','linux') COLLATE utf8mb4_unicode_ci NOT NULL,
  `capability_profile` enum('default','simple','SP2000','TEP-200M','P822D') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `char_per_line` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `port` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `printers_business_id_foreign` (`business_id`),
  CONSTRAINT `printers_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `printers` WRITE;
/*!40000 ALTER TABLE `printers` DISABLE KEYS */;
INSERT INTO `printers` VALUES (1,3,'Bixolon','windows','simple','28','','','USB001',5,'2023-01-29 19:45:13','2023-01-29 20:18:10'),(2,10,'Mi Epson','windows','default','42','','','COM1',15,'2023-03-21 17:03:56','2023-03-21 17:03:56');
/*!40000 ALTER TABLE `printers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_locations` (
  `product_id` int NOT NULL,
  `location_id` int NOT NULL,
  KEY `product_locations_product_id_index` (`product_id`),
  KEY `product_locations_location_id_index` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_locations` WRITE;
/*!40000 ALTER TABLE `product_locations` DISABLE KEYS */;
INSERT INTO `product_locations` VALUES (1,2),(2,2),(3,5),(4,5),(5,5),(6,5),(7,5),(8,6),(9,5),(10,5),(27,2),(27,3),(27,4),(28,2),(28,3),(28,4),(29,2),(29,3),(29,4),(30,2),(30,3),(30,4),(18,2),(18,3),(18,4),(12,2),(12,3),(12,4),(13,2),(13,3),(13,4),(14,2),(14,3),(14,4),(15,2),(15,3),(15,4),(16,2),(16,3),(16,4),(17,2),(17,3),(17,4),(19,2),(19,3),(19,4),(20,2),(20,3),(20,4),(31,5),(32,7),(33,7),(34,7),(35,7),(36,2),(36,3),(36,4),(26,2),(26,3),(26,4),(24,2),(24,3),(24,4),(23,2),(23,3),(23,4),(21,2),(21,3),(21,4),(22,2),(22,3),(22,4),(25,2),(25,3),(25,4),(11,2),(11,3),(11,4),(37,12),(38,12),(39,12),(40,12),(41,12),(42,12),(43,12),(44,12),(45,12),(46,12),(47,12),(48,12),(49,12),(50,12),(51,12),(52,12),(53,12),(54,12),(55,12),(56,12),(57,12),(58,12),(59,12),(60,12),(61,12),(62,12),(63,12),(64,12),(65,12),(66,12),(67,12),(68,12),(69,12),(70,12),(71,12),(72,12),(73,12),(74,12),(75,12),(78,12),(90,12),(91,12),(92,12),(93,12),(94,12),(95,12),(96,12),(97,12),(98,12),(148,12),(149,12),(150,12),(151,12),(152,12),(153,12),(154,12),(155,12),(156,12),(157,12),(158,12),(160,12),(161,12),(162,12),(76,12),(77,12),(81,12),(82,12),(99,12),(100,12),(101,12),(102,12),(103,12),(105,12),(106,12),(107,12),(108,12),(163,12),(165,12),(166,12),(167,12),(168,12),(79,12),(80,12),(83,12),(84,12),(85,12),(86,12),(104,12),(138,12),(139,12),(140,12),(169,12),(170,12),(171,12),(172,12),(173,12),(174,12),(175,12),(176,12),(177,12),(178,12),(179,12),(183,12),(184,12),(185,12),(186,12),(187,12),(188,12),(189,12),(190,12),(191,12),(192,12),(193,12),(194,12),(195,12),(196,12),(197,12),(198,12),(199,12),(200,12),(201,12),(202,12),(203,12),(204,12),(214,12),(215,12),(218,12),(109,12),(110,12),(111,12),(112,12),(113,12),(114,12),(143,12),(146,12),(147,12),(205,12),(206,12),(207,12),(208,12),(209,12),(210,12),(211,12),(212,12),(213,12),(216,12),(217,12),(219,12),(220,12),(222,12),(223,12),(224,12),(115,12),(116,12),(132,12),(133,12),(159,12),(180,12),(181,12),(182,12),(221,12),(225,12),(226,12),(227,12),(228,12),(229,12),(230,12),(231,12),(232,12),(233,12),(234,12),(235,12),(236,12),(237,12),(242,12),(243,12),(244,12),(87,12),(88,12),(89,12),(117,12),(118,12),(119,12),(120,12),(121,12),(122,12),(123,12),(124,12),(125,12),(126,12),(129,12),(130,12),(238,12),(239,12),(240,12),(241,12),(245,12),(246,12),(247,12),(248,12),(249,12),(250,12),(127,12),(128,12),(131,12),(134,12),(135,12),(136,12),(137,12),(141,12),(142,12),(144,12),(145,12),(164,12),(251,12),(252,12),(253,12),(254,12),(255,7),(256,7),(257,12),(258,12),(259,12),(260,12),(261,12),(262,12),(263,12),(264,12),(265,12),(266,12),(267,12),(268,12),(269,12),(270,12),(271,12),(272,7),(273,6),(274,6),(275,6),(276,6),(277,6),(278,6),(279,6),(280,6),(281,6),(282,6),(283,6),(284,6),(285,6),(286,6),(287,6),(288,6),(289,6),(290,6),(291,6),(292,6),(293,6),(294,6),(295,6),(296,6),(297,6),(298,6),(299,6),(300,6),(301,6),(302,6),(303,6),(304,6),(305,6),(306,6),(307,6),(308,6),(309,6),(310,6),(311,6),(312,12),(313,12),(314,12),(315,12),(316,12),(317,12),(318,12);
/*!40000 ALTER TABLE `product_locations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_racks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_racks` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int unsigned NOT NULL,
  `location_id` int unsigned NOT NULL,
  `product_id` int unsigned NOT NULL,
  `rack` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `row` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_racks_business_id_index` (`business_id`),
  KEY `product_racks_location_id_index` (`location_id`),
  KEY `product_racks_product_id_index` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_racks` WRITE;
/*!40000 ALTER TABLE `product_racks` DISABLE KEYS */;
INSERT INTO `product_racks` VALUES (1,5,7,32,NULL,NULL,NULL,'2023-02-13 19:28:28','2023-02-13 19:28:28');
/*!40000 ALTER TABLE `product_racks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_variations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_variations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `variation_template_id` int DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` int unsigned NOT NULL,
  `is_dummy` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_variations_name_index` (`name`),
  KEY `product_variations_product_id_index` (`product_id`),
  CONSTRAINT `product_variations_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=319 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_variations` WRITE;
/*!40000 ALTER TABLE `product_variations` DISABLE KEYS */;
INSERT INTO `product_variations` VALUES (3,NULL,'DUMMY',3,1,'2023-01-26 19:28:13','2023-01-26 19:28:13'),(4,NULL,'DUMMY',4,1,'2023-01-26 19:32:31','2023-01-26 19:32:31'),(5,NULL,'DUMMY',5,1,'2023-01-26 19:35:27','2023-01-26 19:35:27'),(6,NULL,'DUMMY',6,1,'2023-01-26 19:48:52','2023-01-26 19:48:52'),(7,NULL,'DUMMY',7,1,'2023-01-26 19:55:36','2023-01-26 19:55:36'),(9,NULL,'DUMMY',9,1,'2023-01-27 10:27:33','2023-01-27 10:27:33'),(10,NULL,'DUMMY',10,1,'2023-01-27 15:52:40','2023-01-27 15:52:40'),(11,NULL,'DUMMY',11,1,'2023-01-27 16:58:25','2023-01-27 16:58:25'),(12,NULL,'DUMMY',12,1,'2023-01-27 16:58:25','2023-01-27 16:58:25'),(13,NULL,'DUMMY',13,1,'2023-01-27 16:58:25','2023-01-27 16:58:25'),(15,NULL,'DUMMY',15,1,'2023-01-27 16:58:25','2023-01-27 16:58:25'),(16,NULL,'DUMMY',16,1,'2023-01-27 16:58:25','2023-01-27 16:58:25'),(17,NULL,'DUMMY',17,1,'2023-01-27 16:58:25','2023-01-27 16:58:25'),(18,NULL,'DUMMY',18,1,'2023-01-27 16:58:25','2023-01-27 16:58:25'),(19,NULL,'DUMMY',19,1,'2023-01-27 16:58:25','2023-01-27 16:58:25'),(20,NULL,'DUMMY',20,1,'2023-01-27 16:58:25','2023-01-27 16:58:25'),(21,NULL,'DUMMY',21,1,'2023-01-27 16:58:25','2023-01-27 16:58:25'),(22,NULL,'DUMMY',22,1,'2023-01-27 16:58:25','2023-01-27 16:58:25'),(23,NULL,'DUMMY',23,1,'2023-01-27 16:58:25','2023-01-27 16:58:25'),(24,NULL,'DUMMY',24,1,'2023-01-27 16:58:25','2023-01-27 16:58:25'),(25,NULL,'DUMMY',25,1,'2023-01-27 16:58:25','2023-01-27 16:58:25'),(26,NULL,'DUMMY',26,1,'2023-01-27 16:58:25','2023-01-27 16:58:25'),(27,NULL,'DUMMY',27,1,'2023-01-27 17:01:34','2023-01-27 17:01:34'),(28,NULL,'DUMMY',28,1,'2023-01-27 17:02:27','2023-01-27 17:02:27'),(29,NULL,'DUMMY',29,1,'2023-01-27 17:03:55','2023-01-27 17:03:55'),(30,NULL,'DUMMY',30,1,'2023-01-27 17:05:04','2023-01-27 17:05:04'),(31,NULL,'DUMMY',31,1,'2023-02-10 19:34:59','2023-02-10 19:34:59'),(32,NULL,'DUMMY',32,1,'2023-02-13 19:03:46','2023-02-13 19:03:46'),(33,NULL,'DUMMY',33,1,'2023-02-13 19:37:22','2023-02-13 19:37:22'),(34,NULL,'DUMMY',34,1,'2023-02-13 20:01:44','2023-02-13 20:01:44'),(35,NULL,'DUMMY',35,1,'2023-02-13 20:09:05','2023-02-13 20:09:05'),(36,NULL,'DUMMY',36,1,'2023-02-17 12:32:48','2023-02-17 12:32:48'),(255,NULL,'DUMMY',255,1,'2023-03-28 12:11:47','2023-03-28 12:11:47'),(256,NULL,'DUMMY',256,1,'2023-03-28 12:13:06','2023-03-28 12:13:06'),(257,NULL,'DUMMY',257,1,'2023-03-28 22:59:38','2023-03-28 22:59:38'),(258,NULL,'DUMMY',258,1,'2023-03-28 23:01:55','2023-03-28 23:01:55'),(259,NULL,'DUMMY',259,1,'2023-03-28 23:02:35','2023-03-28 23:02:35'),(260,NULL,'DUMMY',260,1,'2023-03-28 23:05:20','2023-03-28 23:05:20'),(261,NULL,'DUMMY',261,1,'2023-03-28 23:05:55','2023-03-28 23:05:55'),(262,NULL,'DUMMY',262,1,'2023-03-28 23:06:26','2023-03-28 23:06:26'),(263,NULL,'DUMMY',263,1,'2023-03-28 23:07:04','2023-03-28 23:07:04'),(264,NULL,'DUMMY',264,1,'2023-03-28 23:07:34','2023-03-28 23:07:34'),(265,NULL,'DUMMY',265,1,'2023-03-28 23:14:57','2023-03-28 23:14:57'),(266,NULL,'DUMMY',266,1,'2023-03-28 23:15:34','2023-03-28 23:15:34'),(267,NULL,'DUMMY',267,1,'2023-03-28 23:16:09','2023-03-28 23:16:09'),(268,NULL,'DUMMY',268,1,'2023-03-28 23:16:33','2023-03-28 23:16:33'),(269,NULL,'DUMMY',269,1,'2023-03-28 23:17:10','2023-03-28 23:17:10'),(270,NULL,'DUMMY',270,1,'2023-03-28 23:17:38','2023-03-28 23:17:38'),(271,NULL,'DUMMY',271,1,'2023-03-28 23:18:02','2023-03-28 23:18:02'),(272,NULL,'DUMMY',272,1,'2023-03-28 23:48:32','2023-03-28 23:48:32'),(275,NULL,'DUMMY',275,1,'2023-03-29 14:10:27','2023-03-29 14:10:27'),(276,NULL,'DUMMY',276,1,'2023-03-29 16:19:28','2023-03-29 16:19:28'),(277,NULL,'DUMMY',277,1,'2023-03-29 16:23:19','2023-03-29 16:23:19'),(278,NULL,'DUMMY',278,1,'2023-03-29 16:26:32','2023-03-29 16:26:32'),(279,NULL,'DUMMY',279,1,'2023-03-29 16:27:45','2023-03-29 16:27:45'),(280,NULL,'DUMMY',280,1,'2023-03-29 16:36:31','2023-03-29 16:36:31'),(281,NULL,'DUMMY',281,1,'2023-03-29 16:44:06','2023-03-29 16:44:06'),(282,NULL,'DUMMY',282,1,'2023-03-29 16:46:14','2023-03-29 16:46:14'),(283,NULL,'DUMMY',283,1,'2023-03-29 16:58:46','2023-03-29 16:58:46'),(284,NULL,'DUMMY',284,1,'2023-03-29 17:05:19','2023-03-29 17:05:19'),(285,NULL,'DUMMY',285,1,'2023-03-29 17:31:59','2023-03-29 17:31:59'),(286,NULL,'DUMMY',286,1,'2023-03-29 17:34:03','2023-03-29 17:34:03'),(287,NULL,'DUMMY',287,1,'2023-03-29 17:41:19','2023-03-29 17:41:19'),(288,NULL,'DUMMY',288,1,'2023-03-29 18:13:13','2023-03-29 18:13:13'),(289,NULL,'DUMMY',289,1,'2023-03-29 18:43:38','2023-03-29 18:43:38'),(290,NULL,'DUMMY',290,1,'2023-03-29 18:46:00','2023-03-29 18:46:00'),(291,NULL,'DUMMY',291,1,'2023-03-29 18:47:55','2023-03-29 18:47:55'),(292,NULL,'DUMMY',292,1,'2023-03-29 18:55:15','2023-03-29 18:55:15'),(293,NULL,'DUMMY',293,1,'2023-03-29 18:57:42','2023-03-29 18:57:42'),(294,NULL,'DUMMY',294,1,'2023-03-29 18:59:16','2023-03-29 18:59:16'),(295,NULL,'DUMMY',295,1,'2023-03-29 19:01:13','2023-03-29 19:01:13'),(296,NULL,'DUMMY',296,1,'2023-03-29 19:03:44','2023-03-29 19:03:44'),(297,NULL,'DUMMY',297,1,'2023-03-29 19:04:46','2023-03-29 19:04:46'),(298,NULL,'DUMMY',298,1,'2023-03-29 19:06:40','2023-03-29 19:06:40'),(299,NULL,'DUMMY',299,1,'2023-03-29 19:08:44','2023-03-29 19:08:44'),(300,NULL,'DUMMY',300,1,'2023-03-29 19:11:47','2023-03-29 19:11:47'),(301,NULL,'DUMMY',301,1,'2023-03-29 19:13:51','2023-03-29 19:13:51'),(302,NULL,'DUMMY',302,1,'2023-03-29 19:15:19','2023-03-29 19:15:19'),(303,NULL,'DUMMY',303,1,'2023-03-29 19:18:20','2023-03-29 19:18:20'),(304,NULL,'DUMMY',304,1,'2023-03-29 19:21:22','2023-03-29 19:21:22'),(305,NULL,'DUMMY',305,1,'2023-03-29 19:24:07','2023-03-29 19:24:07'),(306,NULL,'DUMMY',306,1,'2023-03-29 19:29:37','2023-03-29 19:29:37'),(307,NULL,'DUMMY',307,1,'2023-03-29 19:31:27','2023-03-29 19:31:27'),(308,NULL,'DUMMY',308,1,'2023-03-29 19:35:31','2023-03-29 19:35:31'),(309,NULL,'DUMMY',309,1,'2023-03-29 19:38:21','2023-03-29 19:38:21'),(310,NULL,'DUMMY',310,1,'2023-03-29 19:40:16','2023-03-29 19:40:16'),(311,NULL,'DUMMY',311,1,'2023-03-29 19:45:50','2023-03-29 19:45:50'),(312,NULL,'DUMMY',312,1,'2023-03-30 01:00:15','2023-03-30 01:00:15'),(313,NULL,'DUMMY',313,1,'2023-03-30 01:00:56','2023-03-30 01:00:56'),(314,NULL,'DUMMY',314,1,'2023-03-30 01:01:22','2023-03-30 01:01:22'),(315,NULL,'DUMMY',315,1,'2023-03-30 01:02:03','2023-03-30 01:02:03'),(316,NULL,'DUMMY',316,1,'2023-03-30 01:02:42','2023-03-30 01:02:42'),(317,NULL,'DUMMY',317,1,'2023-03-30 01:03:12','2023-03-30 01:03:12'),(318,NULL,'DUMMY',318,1,'2023-03-30 01:03:49','2023-03-30 01:03:49');
/*!40000 ALTER TABLE `product_variations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int unsigned NOT NULL,
  `type` enum('single','variable','modifier','combo') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_id` int unsigned DEFAULT NULL,
  `sub_unit_ids` text COLLATE utf8mb4_unicode_ci,
  `brand_id` int unsigned DEFAULT NULL,
  `category_id` int unsigned DEFAULT NULL,
  `sub_category_id` int unsigned DEFAULT NULL,
  `tax` int unsigned DEFAULT NULL,
  `tax_type` enum('inclusive','exclusive') COLLATE utf8mb4_unicode_ci NOT NULL,
  `enable_stock` tinyint(1) NOT NULL DEFAULT '0',
  `alert_quantity` decimal(22,4) DEFAULT NULL,
  `sku` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `barcode_type` enum('C39','C128','EAN13','EAN8','UPCA','UPCE') COLLATE utf8mb4_unicode_ci DEFAULT 'C128',
  `expiry_period` decimal(4,2) DEFAULT NULL,
  `expiry_period_type` enum('days','months') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enable_sr_no` tinyint(1) NOT NULL DEFAULT '0',
  `weight` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_custom_field1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_custom_field2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_custom_field3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_custom_field4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `woocommerce_media_id` int DEFAULT NULL,
  `product_description` text COLLATE utf8mb4_unicode_ci,
  `created_by` int unsigned NOT NULL,
  `warranty_id` int DEFAULT NULL,
  `is_inactive` tinyint(1) NOT NULL DEFAULT '0',
  `repair_model_id` int unsigned DEFAULT NULL,
  `not_for_selling` tinyint(1) NOT NULL DEFAULT '0',
  `woocommerce_product_id` int DEFAULT NULL,
  `woocommerce_disable_sync` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `products_brand_id_foreign` (`brand_id`),
  KEY `products_category_id_foreign` (`category_id`),
  KEY `products_sub_category_id_foreign` (`sub_category_id`),
  KEY `products_tax_foreign` (`tax`),
  KEY `products_name_index` (`name`),
  KEY `products_business_id_index` (`business_id`),
  KEY `products_unit_id_index` (`unit_id`),
  KEY `products_created_by_index` (`created_by`),
  KEY `products_warranty_id_index` (`warranty_id`),
  KEY `products_type_index` (`type`),
  KEY `products_tax_type_index` (`tax_type`),
  KEY `products_barcode_type_index` (`barcode_type`),
  KEY `products_repair_model_id_index` (`repair_model_id`),
  KEY `products_woocommerce_product_id_index` (`woocommerce_product_id`),
  KEY `products_woocommerce_media_id_index` (`woocommerce_media_id`),
  CONSTRAINT `products_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_repair_model_id_foreign` FOREIGN KEY (`repair_model_id`) REFERENCES `repair_device_models` (`id`),
  CONSTRAINT `products_sub_category_id_foreign` FOREIGN KEY (`sub_category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_tax_foreign` FOREIGN KEY (`tax`) REFERENCES `tax_rates` (`id`),
  CONSTRAINT `products_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=319 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (3,'MagisTV 60Bs',3,'single',3,NULL,NULL,NULL,NULL,NULL,'exclusive',1,10.0000,'0003','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,0,NULL,0,NULL,0,'2023-01-26 19:28:13','2023-01-26 19:28:13'),(4,'Fire Stick 4K',3,'single',3,NULL,NULL,NULL,NULL,NULL,'exclusive',1,1.0000,'0004','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,0,NULL,0,NULL,0,'2023-01-26 19:32:31','2023-01-26 19:32:31'),(5,'Celular',3,'single',3,NULL,1,4,NULL,NULL,'exclusive',0,0.0000,'0005','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,0,NULL,0,NULL,0,'2023-01-26 19:35:27','2023-01-26 19:35:27'),(6,'Inicio de Tienda Jonathan',3,'single',3,NULL,NULL,NULL,NULL,NULL,'exclusive',0,0.0000,'0006','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,4,NULL,1,NULL,0,NULL,0,'2023-01-26 19:48:52','2023-01-26 20:01:03'),(7,'Inicio de Tienda Percy',3,'single',3,NULL,NULL,NULL,NULL,NULL,'exclusive',0,0.0000,'0007','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<p>Monto de Ingreso por Inicio de Actividades en Sistema</p>',4,NULL,1,NULL,0,NULL,0,'2023-01-26 19:55:36','2023-01-26 20:01:03'),(9,'Terminal Punto de Venta POS',3,'single',3,NULL,NULL,6,NULL,NULL,'exclusive',0,0.0000,'0009','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,5,NULL,0,NULL,0,NULL,0,'2023-01-27 10:27:33','2023-01-27 10:28:09'),(10,'Redmi 10C 128GB/4GB RAM',3,'single',3,NULL,1,4,NULL,NULL,'exclusive',0,0.0000,'0010','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,4,NULL,0,NULL,0,NULL,0,'2023-01-27 15:52:40','2023-01-27 15:52:40'),(11,'-------------------------------',2,'single',2,NULL,NULL,NULL,NULL,NULL,'inclusive',0,0.0000,'0011','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,2,NULL,0,NULL,0,NULL,0,'2023-01-27 16:58:25','2023-02-17 17:14:53'),(12,'Carne Hamburguesa',2,'single',2,NULL,NULL,3,NULL,NULL,'inclusive',1,10.0000,'0012','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'1674853569_carne_hamburguesa.jpeg',NULL,'<p>180 gramos de carne vacuna</p>',2,NULL,0,NULL,0,NULL,0,'2023-01-27 16:58:25','2023-02-17 16:35:18'),(13,'Carne Lomito',2,'single',2,NULL,NULL,3,NULL,NULL,'inclusive',1,0.0000,'0013','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'1674853603_lomito.jpeg',NULL,NULL,2,NULL,0,NULL,0,NULL,0,'2023-01-27 16:58:25','2023-02-17 15:56:16'),(15,'CHORIZO PARRILLERO',2,'single',2,NULL,NULL,3,NULL,NULL,'inclusive',1,0.0000,'0015','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'1674853676_chorizo.png',NULL,NULL,2,NULL,0,NULL,0,NULL,0,'2023-01-27 16:58:25','2023-02-17 17:03:58'),(16,'Huevo',2,'single',2,NULL,NULL,3,NULL,NULL,'inclusive',1,0.0000,'0016','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'1674853702_huevo.webp',NULL,NULL,2,NULL,0,NULL,0,NULL,0,'2023-01-27 16:58:25','2023-02-17 16:02:49'),(17,'Jamon',2,'single',2,NULL,NULL,3,NULL,NULL,'inclusive',1,0.0000,'0017','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'1674853725_jamon.webp',NULL,NULL,2,NULL,0,NULL,0,NULL,0,'2023-01-27 16:58:25','2023-02-17 16:03:03'),(18,'Lechuga',2,'single',2,NULL,NULL,2,NULL,NULL,'inclusive',1,0.0000,'0018','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,2,NULL,0,NULL,1,NULL,0,'2023-01-27 16:58:25','2023-02-17 16:05:53'),(19,'Pan Hamburguesa',2,'single',2,NULL,NULL,2,NULL,NULL,'inclusive',1,3.0000,'0019','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,2,NULL,0,NULL,1,NULL,0,'2023-01-27 16:58:25','2023-02-17 16:07:19'),(20,'Pan LomiSkot',2,'single',2,NULL,NULL,2,NULL,NULL,'inclusive',1,0.0000,'0020','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,2,NULL,0,NULL,1,NULL,0,'2023-01-27 16:58:25','2023-02-17 16:12:15'),(21,'Pan para choriskot No para vender',2,'single',2,NULL,NULL,2,NULL,NULL,'inclusive',1,0.0000,'0021','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,2,NULL,0,NULL,1,NULL,0,'2023-01-27 16:58:25','2023-02-17 16:16:40'),(22,'Pan SkotDog No para vender',2,'single',2,NULL,NULL,2,NULL,NULL,'inclusive',1,0.0000,'0022','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,2,NULL,0,NULL,1,NULL,0,'2023-01-27 16:58:25','2023-02-17 16:17:02'),(23,'Papas',2,'single',2,NULL,NULL,3,NULL,NULL,'inclusive',1,0.0000,'0023','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,2,NULL,0,NULL,0,NULL,0,'2023-01-27 16:58:25','2023-02-17 16:04:00'),(24,'Queso No para vender',2,'single',2,NULL,NULL,2,NULL,NULL,'inclusive',1,10.0000,'0024','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,2,NULL,0,NULL,1,NULL,0,'2023-01-27 16:58:25','2023-02-17 16:07:36'),(25,'Tocino Artesanal',2,'single',2,NULL,NULL,3,NULL,NULL,'inclusive',1,0.0000,'0025','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,2,NULL,0,NULL,0,NULL,0,'2023-01-27 16:58:25','2023-02-17 16:17:52'),(26,'Tomate No para vender',2,'single',2,NULL,NULL,2,NULL,NULL,'inclusive',1,0.0000,'0026','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,2,NULL,0,NULL,1,NULL,0,'2023-01-27 16:58:25','2023-02-17 16:08:02'),(27,'Clasica',2,'combo',2,NULL,NULL,1,NULL,NULL,'exclusive',0,0.0000,'0027','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'1676643209_what-to-serve-with-burgers-sq.webp',NULL,'<p>hamburguesa clasica skot, 180g de carne finamente seleccionada, pan de la casa, lechuga, tomate, 2 salsas de la casa en el armado, queso mozzarella.</p>',2,NULL,0,NULL,0,NULL,0,'2023-01-27 17:01:34','2023-02-17 18:10:33'),(28,'LomiSkot',2,'combo',2,NULL,NULL,1,NULL,NULL,'exclusive',1,0.0000,'0028','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,0,NULL,0,NULL,0,'2023-01-27 17:02:27','2023-02-17 16:05:27'),(29,'Chori Skot',2,'combo',2,NULL,NULL,1,NULL,NULL,'exclusive',1,10.0000,'0029','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,0,NULL,0,NULL,0,'2023-01-27 17:03:55','2023-02-17 13:02:16'),(30,'Skot Dog',2,'combo',2,NULL,NULL,1,NULL,NULL,'exclusive',1,0.0000,'0030','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,0,NULL,0,NULL,0,'2023-01-27 17:05:04','2023-02-17 16:06:50'),(31,'Infinix Note 12 256 GB/8 GB',3,'single',3,NULL,NULL,4,NULL,NULL,'exclusive',0,0.0000,'0031','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,4,NULL,0,NULL,0,NULL,0,'2023-02-10 19:34:59','2023-02-10 19:34:59'),(32,'Paracetamol 50grm',5,'single',5,NULL,5,7,NULL,NULL,'exclusive',1,3.0000,'0032','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,8,NULL,0,NULL,0,NULL,0,'2023-02-13 19:03:46','2023-02-13 19:44:51'),(33,'Aspirineta 500grm',5,'single',5,NULL,5,7,NULL,NULL,'exclusive',1,3.0000,'0033','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,8,NULL,0,NULL,0,NULL,0,'2023-02-13 19:37:22','2023-02-13 19:44:23'),(34,'vardenafil',5,'single',5,NULL,5,7,NULL,NULL,'exclusive',1,3.0000,'0034','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,8,NULL,0,NULL,0,NULL,0,'2023-02-13 20:01:44','2023-02-13 20:44:46'),(35,'Ibuprofeno 600mg',5,'single',5,NULL,5,8,NULL,NULL,'exclusive',1,NULL,'0035','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,8,NULL,0,NULL,0,NULL,0,'2023-02-13 20:09:05','2023-02-13 20:09:05'),(36,'TOCINO',2,'single',2,NULL,NULL,3,NULL,NULL,'exclusive',1,10.0000,'0036','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<p>TOCINO ARTESANAL</p>',2,NULL,0,NULL,0,NULL,0,'2023-02-17 12:32:48','2023-02-17 12:34:37'),(255,'IBUSEC 800',5,'single',5,NULL,5,8,NULL,NULL,'exclusive',1,5.0000,'0255','C128',12.00,'months',0,NULL,'ANALGESICO ANTIINFLAMATORIO ANTIPIRETICO',NULL,NULL,NULL,NULL,NULL,'<p>IBUPROFENO 800</p>',8,NULL,0,NULL,0,NULL,0,'2023-03-28 12:11:47','2023-03-28 12:25:27'),(256,'producto 1',5,'single',5,NULL,NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0256','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,8,NULL,0,NULL,0,NULL,0,'2023-03-28 12:13:06','2023-03-28 12:13:06'),(257,'CAÑERIA 1/2',10,'single',10,NULL,NULL,9,NULL,NULL,'exclusive',1,2.0000,'0257','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,0,NULL,0,NULL,0,'2023-03-28 22:59:38','2023-03-28 22:59:38'),(258,'CAÑERIA 1',10,'single',10,NULL,NULL,9,NULL,NULL,'exclusive',1,2.0000,'0258','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,0,NULL,0,NULL,0,'2023-03-28 23:01:55','2023-03-28 23:01:55'),(259,'CAÑERIA 3/4',10,'single',10,NULL,NULL,9,NULL,NULL,'exclusive',1,2.0000,'0259','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,0,NULL,0,NULL,0,'2023-03-28 23:02:35','2023-03-28 23:02:35'),(260,'MASA P/ PULIR NO. 2',10,'single',10,NULL,NULL,18,NULL,NULL,'exclusive',1,2.0000,'0260','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,0,NULL,0,NULL,0,'2023-03-28 23:05:20','2023-03-28 23:05:20'),(261,'MASA RAPIDA',10,'single',10,NULL,NULL,18,NULL,NULL,'exclusive',1,2.0000,'0261','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,0,NULL,0,NULL,0,'2023-03-28 23:05:55','2023-03-28 23:05:55'),(262,'PRIMER UNIVERSAL (SULFASE)',10,'single',10,NULL,NULL,18,NULL,NULL,'exclusive',1,2.0000,'0262','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,0,NULL,0,NULL,0,'2023-03-28 23:06:26','2023-03-28 23:06:26'),(263,'MASILLA ULTRA LIGHT (ADESIVO PLASTICO)',10,'single',10,NULL,NULL,18,NULL,NULL,'exclusive',1,2.0000,'0263','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,0,NULL,0,NULL,0,'2023-03-28 23:07:04','2023-03-28 23:07:04'),(264,'BARNIZ CON CATALIZADOR',10,'single',10,NULL,NULL,18,NULL,NULL,'exclusive',1,2.0000,'0264','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,0,NULL,0,NULL,0,'2023-03-28 23:07:34','2023-03-28 23:07:34'),(265,'MANTA SINTETICA PARA IMPERMEABILIZANTE (100M)',10,'single',10,NULL,NULL,19,NULL,NULL,'exclusive',1,2.0000,'0265','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,0,NULL,0,NULL,0,'2023-03-28 23:14:57','2023-03-28 23:14:57'),(266,'MARPLAST BARNIZ 0,9L (MOGNO Y IMBUIA)',10,'single',10,NULL,NULL,19,NULL,NULL,'exclusive',1,2.0000,'0266','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,0,NULL,0,NULL,0,'2023-03-28 23:15:34','2023-03-28 23:15:34'),(267,'TINTA MADEPLAST 0,9L (WALNUT 27, CAFÉ 50 Y AMERICAN WALNUT 17)',10,'single',10,NULL,NULL,19,NULL,NULL,'exclusive',1,2.0000,'0267','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,0,NULL,0,NULL,0,'2023-03-28 23:16:09','2023-03-28 23:16:09'),(268,'RECUPLAST TECHO BALDE AMARILLO 0,9L',10,'single',10,NULL,NULL,19,NULL,NULL,'exclusive',1,2.0000,'0268','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,0,NULL,0,NULL,0,'2023-03-28 23:16:33','2023-03-28 23:16:33'),(269,'RECUPLAST TECHO BALDE AMARILLO 3,6L',10,'single',10,NULL,NULL,19,NULL,NULL,'exclusive',1,2.0000,'0269','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,0,NULL,0,NULL,0,'2023-03-28 23:17:10','2023-03-28 23:17:10'),(270,'RECUPLAST TECHO BALDE AMARILLO 10L',10,'single',10,NULL,NULL,19,NULL,NULL,'exclusive',1,2.0000,'0270','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,0,NULL,0,NULL,0,'2023-03-28 23:17:38','2023-03-28 23:17:38'),(271,'RECUPLAST LADRILLO 3,6L (BARNIZ PARED)',10,'single',10,NULL,NULL,19,NULL,NULL,'exclusive',1,2.0000,'0271','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,0,NULL,0,NULL,0,'2023-03-28 23:18:02','2023-03-28 23:18:02'),(272,'Typire',5,'single',5,NULL,5,8,NULL,NULL,'exclusive',1,2.0000,'0272','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,8,NULL,0,NULL,0,NULL,0,'2023-03-28 23:48:32','2023-03-28 23:48:32'),(275,'Producto 1',4,'single',4,NULL,31,5,NULL,NULL,'exclusive',1,2.0000,'0275','C128',12.00,'months',0,NULL,'para el dolor de cabeza',NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 14:10:27','2023-03-29 14:10:27'),(276,'BAGOVITAL DIGEST',4,'single',4,NULL,6,27,NULL,NULL,'exclusive',1,2.0000,'0276','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<p>PROBIOTICOS</p>',6,NULL,0,NULL,0,NULL,0,'2023-03-29 16:19:28','2023-03-29 16:19:28'),(277,'BAGOVITAL INMUNE',4,'single',4,NULL,6,27,NULL,NULL,'exclusive',1,2.0000,'0277','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 16:23:19','2023-03-29 16:23:19'),(278,'BATADINA 200MG',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,2.0000,'0278','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 16:26:32','2023-03-29 16:26:32'),(279,'BATADINA 400MG',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,2.0000,'0279','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 16:27:45','2023-03-29 16:27:45'),(280,'BIL 13',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,50.0000,'0280','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 16:36:31','2023-03-29 16:36:31'),(281,'BLOCAR 6,25 MG',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,2.0000,'0281','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 16:44:06','2023-03-29 16:44:06'),(282,'BLOCAR 12,5 MG',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,2.0000,'0282','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 16:46:14','2023-03-29 16:46:14'),(283,'BLOCAR 25MG',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,2.0000,'0283','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 16:58:46','2023-03-29 16:58:46'),(284,'BREVEX',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,2.0000,'0284','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 17:05:19','2023-03-29 17:05:19'),(285,'ABRAMAX',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,2.0000,'0285','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 17:31:59','2023-03-29 17:31:59'),(286,'ACNOTIN 20MG',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,2.0000,'0286','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 17:34:03','2023-03-29 17:34:03'),(287,'ANAFLEX MUJER',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,2.0000,'0287','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 17:41:19','2023-03-29 17:41:19'),(288,'BACTICEL FORTE',4,'single',4,NULL,6,21,NULL,NULL,'exclusive',1,3.0000,'0288','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 18:13:13','2023-03-29 18:13:13'),(289,'BACTICEL FORTE',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,3.0000,'0289','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 18:43:38','2023-03-29 18:43:38'),(290,'BACTICEL',4,'single',4,NULL,6,21,NULL,NULL,'exclusive',1,3.0000,'0290','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 18:46:00','2023-03-29 18:46:00'),(291,'BACTIFREN 500MG',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,2.0000,'0291','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 18:47:55','2023-03-29 18:47:55'),(292,'BAGOCILETAS FRAMBUESA',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,1.0000,'0292','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 18:55:15','2023-03-29 18:55:15'),(293,'BAGOCILETAS MIEL LIMON',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,1.0000,'0293','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 18:57:42','2023-03-29 18:57:42'),(294,'BAGOCILETA NARANJA',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,1.0000,'0294','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 18:59:16','2023-03-29 18:59:16'),(295,'BAGODERM',4,'single',4,NULL,6,26,NULL,NULL,'exclusive',1,1.0000,'0295','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 19:01:13','2023-03-29 19:01:13'),(296,'BAGOMICINA 50 MG',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,1.0000,'0296','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 19:03:44','2023-03-29 19:03:44'),(297,'BAGOMICINA 100MG',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,1.0000,'0297','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 19:04:46','2023-03-29 19:04:46'),(298,'BRONCOTEROL ADULTO',4,'single',4,NULL,6,21,NULL,NULL,'exclusive',1,1.0000,'0298','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 19:06:40','2023-03-29 19:06:40'),(299,'BRONCOTEROL INFANTIL',4,'single',4,NULL,6,21,NULL,NULL,'exclusive',1,1.0000,'0299','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 19:08:44','2023-03-29 19:08:44'),(300,'CEFIN SHAMPOO',4,'single',4,NULL,6,NULL,NULL,NULL,'exclusive',1,1.0000,'0300','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 19:11:47','2023-03-29 19:11:47'),(301,'CLOFENAC 50MG',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,50.0000,'0301','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 19:13:51','2023-03-29 19:13:51'),(302,'CLOFENAC 75MG',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,50.0000,'0302','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 19:15:19','2023-03-29 19:15:19'),(303,'CLOFENAC 75MG /3ML',4,'single',4,NULL,6,5,NULL,NULL,'exclusive',1,5.0000,'0303','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 19:18:20','2023-03-29 19:18:20'),(304,'CLOFENAC GEL 5%',4,'single',4,NULL,6,NULL,NULL,NULL,'exclusive',1,1.0000,'0304','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 19:21:22','2023-03-29 19:21:22'),(305,'CLOFENAC GESIC',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,2.0000,'0305','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 19:24:07','2023-03-29 19:24:07'),(306,'CLOFENAC RELAX',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,3.0000,'0306','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 19:29:37','2023-03-29 19:29:37'),(307,'CLOFENAC RELAX FORTE',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,1.0000,'0307','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 19:31:27','2023-03-29 19:31:27'),(308,'CLOFENAC RELAX',4,'single',4,NULL,6,5,NULL,NULL,'exclusive',1,3.0000,'0308','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 19:35:31','2023-03-29 19:35:31'),(309,'CLOFENAC RETARD 100MG',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,1.0000,'0309','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 19:38:21','2023-03-29 19:38:21'),(310,'CLOFENAC B12 FORTE',4,'single',4,NULL,6,5,NULL,NULL,'exclusive',1,3.0000,'0310','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 19:40:16','2023-03-29 19:40:16'),(311,'CLOFENAC B1 B6 B12',4,'single',4,NULL,6,23,NULL,NULL,'exclusive',1,40.0000,'0311','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,NULL,0,NULL,0,NULL,0,'2023-03-29 19:45:50','2023-03-29 19:45:50'),(312,'SOPLADOR ASPIRADOR ELECTRICO 600W',10,'single',10,NULL,NULL,42,NULL,NULL,'exclusive',1,2.0000,'0312','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,0,NULL,0,NULL,0,'2023-03-30 01:00:15','2023-03-30 01:00:15'),(313,'AMOLADORA ANGULAR 7\", 2350W',10,'single',10,NULL,NULL,42,NULL,NULL,'exclusive',1,2.0000,'0313','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,0,NULL,0,NULL,0,'2023-03-30 01:00:56','2023-03-30 01:00:56'),(314,'KIT PARA PINTAR ENERGY 500W 800ML',10,'single',10,NULL,NULL,42,NULL,NULL,'exclusive',1,2.0000,'0314','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,0,NULL,0,NULL,0,'2023-03-30 01:01:22','2023-03-30 01:01:22'),(315,'BOMBA PERIFERICA 1/2 HP FORES GARDEN',10,'single',10,NULL,NULL,42,NULL,NULL,'exclusive',1,2.0000,'0315','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,0,NULL,0,NULL,0,'2023-03-30 01:02:03','2023-03-30 01:02:03'),(316,'BOMBA PERIFERICA 1 HP FORES GARDEN',10,'single',10,NULL,NULL,42,NULL,NULL,'exclusive',1,2.0000,'0316','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,0,NULL,0,NULL,0,'2023-03-30 01:02:42','2023-03-30 01:02:42'),(317,'ESTABILIZADOR AUTOMATICO DE PRESION PC-7000',10,'single',10,NULL,NULL,42,NULL,NULL,'exclusive',1,NULL,'0317','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,0,NULL,0,NULL,0,'2023-03-30 01:03:12','2023-03-30 01:03:12'),(318,'BORDEADORA',10,'single',10,NULL,NULL,42,NULL,NULL,'exclusive',1,NULL,'0318','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15,NULL,0,NULL,0,NULL,0,'2023-03-30 01:03:49','2023-03-30 01:03:49');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchase_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_lines` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` int unsigned NOT NULL,
  `product_id` int unsigned NOT NULL,
  `variation_id` int unsigned NOT NULL,
  `quantity` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `pp_without_discount` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Purchase price before inline discounts',
  `discount_percent` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT 'Inline discount percentage',
  `purchase_price` decimal(22,4) NOT NULL,
  `purchase_price_inc_tax` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `item_tax` decimal(22,4) NOT NULL COMMENT 'Tax for one quantity',
  `tax_id` int unsigned DEFAULT NULL,
  `purchase_order_line_id` int DEFAULT NULL,
  `quantity_sold` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Quanity sold from this purchase line',
  `quantity_adjusted` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Quanity adjusted in stock adjustment from this purchase line',
  `quantity_returned` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `po_quantity_purchased` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `mfg_quantity_used` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `mfg_date` date DEFAULT NULL,
  `exp_date` date DEFAULT NULL,
  `lot_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_unit_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_lines_transaction_id_foreign` (`transaction_id`),
  KEY `purchase_lines_product_id_foreign` (`product_id`),
  KEY `purchase_lines_variation_id_foreign` (`variation_id`),
  KEY `purchase_lines_tax_id_foreign` (`tax_id`),
  KEY `purchase_lines_sub_unit_id_index` (`sub_unit_id`),
  KEY `purchase_lines_lot_number_index` (`lot_number`),
  CONSTRAINT `purchase_lines_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchase_lines_tax_id_foreign` FOREIGN KEY (`tax_id`) REFERENCES `tax_rates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchase_lines_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchase_lines_variation_id_foreign` FOREIGN KEY (`variation_id`) REFERENCES `variations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchase_lines` WRITE;
/*!40000 ALTER TABLE `purchase_lines` DISABLE KEYS */;
INSERT INTO `purchase_lines` VALUES (1,1,3,3,74.0000,22.5000,0.00,22.5000,22.5000,0.0000,NULL,NULL,23.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2023-01-26 19:29:07','2023-02-10 19:40:09'),(2,2,4,4,4.0000,265.0000,0.00,265.0000,265.0000,0.0000,NULL,NULL,3.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2023-01-26 19:32:40','2023-02-10 19:40:09'),(4,25,32,32,120.0000,2.0000,0.00,2.0000,2.0000,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,'2023-03-11',NULL,NULL,'2023-02-13 19:03:59','2023-02-13 19:35:22'),(5,26,33,33,90.0000,3.0000,0.00,3.0000,3.0000,0.0000,NULL,NULL,66.0000,0.0000,0.0000,0.0000,0.0000,NULL,'2023-03-09',NULL,NULL,'2023-02-13 19:37:31','2023-03-28 12:40:19'),(6,27,34,34,20.0000,10.0000,0.00,10.0000,10.0000,0.0000,NULL,NULL,18.0000,0.0000,0.0000,0.0000,0.0000,NULL,'2023-03-03',NULL,NULL,'2023-02-13 20:01:55','2023-03-29 10:49:46'),(7,28,35,35,400.0000,0.5000,0.00,0.5000,0.5000,0.0000,NULL,NULL,90.0000,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-30',NULL,NULL,'2023-02-13 20:10:10','2023-03-29 10:49:46'),(37,40,27,27,10.0000,8.2500,0.00,8.2500,8.2500,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2023-02-17 17:48:22','2023-02-17 17:48:22'),(38,54,19,19,1.0000,0.5000,0.00,0.5000,0.5000,0.0000,NULL,NULL,1.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2023-02-17 18:37:08','2023-02-17 18:38:47'),(39,60,24,24,1.0000,2.0000,0.00,2.0000,2.0000,0.0000,NULL,NULL,1.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2023-02-17 18:37:39','2023-02-17 18:38:47'),(40,61,12,12,1.0000,5.0000,0.00,5.0000,5.0000,0.0000,NULL,NULL,1.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2023-02-17 18:38:10','2023-02-17 18:38:47'),(41,57,26,26,1.0000,0.2500,0.00,0.2500,0.2500,0.0000,NULL,NULL,1.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2023-02-17 18:38:26','2023-02-17 18:38:47'),(42,56,18,18,1.0000,0.5000,0.00,0.5000,0.5000,0.0000,NULL,NULL,1.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2023-02-17 18:38:43','2023-02-17 18:38:47'),(43,101,255,255,100.0000,1.0000,0.00,1.0000,1.0000,0.0000,NULL,NULL,9.0000,0.0000,0.0000,0.0000,0.0000,NULL,'2023-08-31',NULL,NULL,'2023-03-28 12:15:41','2023-03-29 10:49:46'),(44,102,256,256,50.0000,5.0000,0.00,5.0000,5.0000,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,'2023-08-11',NULL,NULL,'2023-03-28 12:15:53','2023-03-28 12:15:53'),(45,105,257,257,47.0000,29.7300,0.00,29.7300,29.7300,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2023-03-28 22:59:38','2023-03-28 22:59:38'),(46,106,258,258,6.0000,42.1000,0.00,42.1000,42.1000,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2023-03-28 23:01:55','2023-03-28 23:01:55'),(47,107,259,259,2.0000,39.1000,0.00,39.1000,39.1000,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2023-03-28 23:02:36','2023-03-28 23:02:36'),(48,108,261,261,23.0000,34.6600,0.00,34.6600,34.6600,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2023-03-28 23:05:55','2023-03-28 23:05:55'),(49,109,262,262,6.0000,34.0000,0.00,34.0000,34.0000,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2023-03-28 23:06:26','2023-03-28 23:06:26'),(50,110,271,271,2.0000,102.0000,0.00,102.0000,102.0000,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2023-03-28 23:18:02','2023-03-28 23:18:02'),(51,111,272,272,60.0000,1.0000,0.00,1.0000,1.0000,0.0000,NULL,NULL,1.0000,0.0000,0.0000,0.0000,0.0000,NULL,'2024-07-17',NULL,NULL,'2023-03-28 23:48:32','2023-03-28 23:58:44'),(52,115,255,255,50.0000,1.0000,0.00,1.0000,1.0000,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,'2023-03-31',NULL,NULL,'2023-03-29 11:09:32','2023-03-29 11:09:32'),(53,115,33,33,1.0000,2.0000,0.00,2.0000,2.0000,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2023-03-29 11:09:32','2023-03-29 11:09:32'),(57,120,275,275,50.0000,1.0000,0.00,1.0000,1.0000,0.0000,NULL,NULL,7.0000,0.0000,0.0000,0.0000,0.0000,NULL,'2025-07-24',NULL,NULL,'2023-03-29 14:10:27','2023-03-29 14:11:27'),(58,122,312,312,2.0000,245.0000,0.00,245.0000,245.0000,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2023-03-30 01:00:15','2023-03-30 01:00:15'),(59,123,313,313,1.0000,519.4700,0.00,519.4700,519.4700,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2023-03-30 01:00:56','2023-03-30 01:00:56'),(60,124,314,314,1.0000,294.0000,0.00,294.0000,294.0000,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2023-03-30 01:01:22','2023-03-30 01:01:22'),(61,125,315,315,4.0000,189.0000,0.00,189.0000,189.0000,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2023-03-30 01:02:03','2023-03-30 01:02:03'),(62,126,316,316,3.0000,499.5000,0.00,499.5000,499.5000,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2023-03-30 01:02:42','2023-03-30 01:02:42'),(63,127,318,318,1.0000,300.0000,0.00,300.0000,300.0000,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2023-03-30 01:03:49','2023-03-30 01:03:49');
/*!40000 ALTER TABLE `purchase_lines` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reference_counts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reference_counts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `ref_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ref_count` int NOT NULL,
  `business_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reference_counts_business_id_index` (`business_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reference_counts` WRITE;
/*!40000 ALTER TABLE `reference_counts` DISABLE KEYS */;
INSERT INTO `reference_counts` VALUES (1,'contacts',1,1,'2023-01-26 15:59:33','2023-01-26 15:59:33'),(2,'business_location',1,1,'2023-01-26 15:59:33','2023-01-26 15:59:33'),(3,'contacts',1,2,'2023-01-26 16:42:31','2023-01-26 16:42:31'),(4,'business_location',3,2,'2023-01-26 16:42:31','2023-01-26 17:31:14'),(5,'contacts',73,3,'2023-01-26 19:20:15','2023-02-10 19:39:23'),(6,'business_location',1,3,'2023-01-26 19:20:15','2023-01-26 19:20:15'),(7,'expense',8,3,'2023-01-26 19:44:35','2023-02-16 21:53:51'),(8,'sell_payment',24,3,'2023-01-26 19:58:47','2023-03-01 22:00:27'),(9,'contacts',2,4,'2023-01-26 20:28:14','2023-03-29 13:42:38'),(10,'business_location',1,4,'2023-01-26 20:28:14','2023-01-26 20:28:14'),(11,'contacts',6,5,'2023-01-28 21:05:09','2023-03-29 11:08:16'),(12,'business_location',1,5,'2023-01-28 21:05:09','2023-01-28 21:05:09'),(13,'contacts',1,6,'2023-01-30 16:12:22','2023-01-30 16:12:22'),(14,'business_location',1,6,'2023-01-30 16:12:22','2023-01-30 16:12:22'),(15,'contacts',1,7,'2023-02-01 10:48:07','2023-02-01 10:48:07'),(16,'business_location',1,7,'2023-02-01 10:48:07','2023-02-01 10:48:07'),(17,'sell_payment',4,5,'2023-02-13 20:28:15','2023-03-29 10:54:35'),(18,'contacts',1,8,'2023-02-15 09:06:18','2023-02-15 09:06:18'),(19,'business_location',1,8,'2023-02-15 09:06:18','2023-02-15 09:06:18'),(20,'username',1,2,'2023-02-17 10:18:33','2023-02-17 10:18:33'),(21,'stock_transfer',3,2,'2023-02-17 10:29:48','2023-02-17 12:15:27'),(22,'draft',3,2,'2023-02-17 16:35:27','2023-02-17 17:53:29'),(23,'expense',1,2,'2023-02-17 16:37:11','2023-02-17 16:37:11'),(24,'sell_payment',2,2,'2023-02-17 16:37:11','2023-02-17 18:38:46'),(25,'contacts',1,9,'2023-03-06 13:58:51','2023-03-06 13:58:51'),(26,'business_location',1,9,'2023-03-06 13:58:51','2023-03-06 13:58:51'),(27,'contacts',3,10,'2023-03-21 16:07:24','2023-03-22 11:34:22'),(28,'business_location',1,10,'2023-03-21 16:07:24','2023-03-21 16:07:24'),(29,'sell_payment',17,10,'2023-03-21 16:54:13','2023-03-22 11:35:31'),(30,'contacts',1,11,'2023-03-22 12:12:28','2023-03-22 12:12:28'),(31,'business_location',1,11,'2023-03-22 12:12:28','2023-03-22 12:12:28'),(32,'purchase',1,5,'2023-03-29 11:09:32','2023-03-29 11:09:32'),(33,'purchase_payment',1,5,'2023-03-29 11:09:32','2023-03-29 11:09:32'),(34,'sell_payment',4,4,'2023-03-29 11:48:42','2023-03-29 14:11:27'),(35,'purchase',1,4,'2023-03-29 13:45:36','2023-03-29 13:45:36'),(36,'purchase_payment',1,4,'2023-03-29 13:45:36','2023-03-29 13:45:36');
/*!40000 ALTER TABLE `reference_counts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `repair_device_models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repair_device_models` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `repair_checklist` text COLLATE utf8mb4_unicode_ci,
  `brand_id` int unsigned DEFAULT NULL,
  `device_id` int unsigned DEFAULT NULL,
  `created_by` int unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `repair_device_models_business_id_index` (`business_id`),
  KEY `repair_device_models_brand_id_index` (`brand_id`),
  KEY `repair_device_models_device_id_index` (`device_id`),
  KEY `repair_device_models_created_by_index` (`created_by`),
  CONSTRAINT `repair_device_models_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`),
  CONSTRAINT `repair_device_models_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `repair_device_models_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `repair_device_models_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `repair_device_models` WRITE;
/*!40000 ALTER TABLE `repair_device_models` DISABLE KEYS */;
/*!40000 ALTER TABLE `repair_device_models` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `repair_job_sheets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repair_job_sheets` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int unsigned NOT NULL,
  `location_id` int unsigned DEFAULT NULL,
  `contact_id` int unsigned NOT NULL,
  `job_sheet_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `service_type` enum('carry_in','pick_up','on_site') COLLATE utf8mb4_unicode_ci NOT NULL,
  `pick_up_on_site_addr` text COLLATE utf8mb4_unicode_ci,
  `brand_id` int unsigned DEFAULT NULL,
  `device_id` int unsigned DEFAULT NULL,
  `device_model_id` int unsigned DEFAULT NULL,
  `checklist` text COLLATE utf8mb4_unicode_ci,
  `security_pwd` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `security_pattern` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serial_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_id` int NOT NULL,
  `delivery_date` datetime DEFAULT NULL,
  `product_configuration` text COLLATE utf8mb4_unicode_ci,
  `defects` text COLLATE utf8mb4_unicode_ci,
  `product_condition` text COLLATE utf8mb4_unicode_ci,
  `service_staff` int unsigned DEFAULT NULL,
  `comment_by_ss` text COLLATE utf8mb4_unicode_ci COMMENT 'comment made by technician',
  `estimated_cost` decimal(22,4) DEFAULT NULL,
  `created_by` int unsigned NOT NULL,
  `parts` text COLLATE utf8mb4_unicode_ci,
  `custom_field_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_5` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `repair_job_sheets_business_id_index` (`business_id`),
  KEY `repair_job_sheets_location_id_index` (`location_id`),
  KEY `repair_job_sheets_contact_id_index` (`contact_id`),
  KEY `repair_job_sheets_brand_id_index` (`brand_id`),
  KEY `repair_job_sheets_device_id_index` (`device_id`),
  KEY `repair_job_sheets_device_model_id_index` (`device_model_id`),
  KEY `repair_job_sheets_status_id_index` (`status_id`),
  KEY `repair_job_sheets_service_staff_index` (`service_staff`),
  KEY `repair_job_sheets_created_by_index` (`created_by`),
  CONSTRAINT `repair_job_sheets_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`),
  CONSTRAINT `repair_job_sheets_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `repair_job_sheets_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `repair_job_sheets_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `repair_job_sheets_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `repair_job_sheets_device_model_id_foreign` FOREIGN KEY (`device_model_id`) REFERENCES `repair_device_models` (`id`),
  CONSTRAINT `repair_job_sheets_service_staff_foreign` FOREIGN KEY (`service_staff`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `repair_job_sheets` WRITE;
/*!40000 ALTER TABLE `repair_job_sheets` DISABLE KEYS */;
/*!40000 ALTER TABLE `repair_job_sheets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `repair_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repair_statuses` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int DEFAULT NULL,
  `business_id` int NOT NULL,
  `is_completed_status` tinyint(1) NOT NULL DEFAULT '0',
  `sms_template` text COLLATE utf8mb4_unicode_ci,
  `email_subject` text COLLATE utf8mb4_unicode_ci,
  `email_body` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `repair_statuses` WRITE;
/*!40000 ALTER TABLE `repair_statuses` DISABLE KEYS */;
/*!40000 ALTER TABLE `repair_statuses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `res_product_modifier_sets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `res_product_modifier_sets` (
  `modifier_set_id` int unsigned NOT NULL,
  `product_id` int unsigned NOT NULL COMMENT 'Table use to store the modifier sets applicable for a product',
  KEY `res_product_modifier_sets_modifier_set_id_foreign` (`modifier_set_id`),
  CONSTRAINT `res_product_modifier_sets_modifier_set_id_foreign` FOREIGN KEY (`modifier_set_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `res_product_modifier_sets` WRITE;
/*!40000 ALTER TABLE `res_product_modifier_sets` DISABLE KEYS */;
/*!40000 ALTER TABLE `res_product_modifier_sets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `res_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `res_tables` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int unsigned NOT NULL,
  `location_id` int unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_by` int unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `res_tables_business_id_foreign` (`business_id`),
  CONSTRAINT `res_tables_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `res_tables` WRITE;
/*!40000 ALTER TABLE `res_tables` DISABLE KEYS */;
INSERT INTO `res_tables` VALUES (1,2,3,'Mesa 1',NULL,2,NULL,'2023-01-26 17:42:14','2023-01-26 17:42:14');
/*!40000 ALTER TABLE `res_tables` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` int unsigned NOT NULL,
  `role_id` int unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (48,2),(49,2),(71,2),(72,2),(73,2),(74,2),(103,2),(6,4),(48,4),(49,4),(59,4),(60,4),(61,4),(63,4),(64,4),(65,4),(71,4),(72,4),(73,4),(77,4),(82,4),(121,4),(122,4),(124,4),(125,4),(131,4),(133,4),(134,4),(135,4),(136,4),(48,6),(49,6),(71,6),(72,6),(73,6),(74,6),(103,6),(2,8),(3,8),(8,8),(9,8),(10,8),(21,8),(30,8),(31,8),(37,8),(38,8),(50,8),(60,8),(61,8),(62,8),(63,8),(64,8),(65,8),(66,8),(71,8),(72,8),(73,8),(74,8),(86,8),(87,8),(88,8),(89,8),(94,8),(95,8),(96,8),(97,8),(98,8),(99,8),(100,8),(101,8),(111,8),(112,8),(113,8),(114,8),(115,8),(116,8),(117,8),(118,8),(119,8),(120,8),(121,8),(122,8),(123,8),(124,8),(125,8),(48,10),(49,10),(71,10),(72,10),(73,10),(74,10),(103,10),(48,12),(49,12),(71,12),(72,12),(73,12),(74,12),(103,12),(48,14),(49,14),(71,14),(72,14),(73,14),(74,14),(103,14),(48,16),(49,16),(71,16),(72,16),(73,16),(74,16),(103,16),(3,17),(6,17),(7,17),(30,17),(41,17),(63,17),(64,17),(65,17),(66,17),(68,17),(69,17),(70,17),(104,17),(132,17),(48,19),(49,19),(71,19),(72,19),(73,19),(74,19),(103,19),(48,21),(49,21),(71,21),(72,21),(73,21),(74,21),(103,21),(48,23),(49,23),(71,23),(72,23),(73,23),(74,23),(103,23);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int unsigned NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_service_staff` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `roles_business_id_foreign` (`business_id`),
  CONSTRAINT `roles_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Admin#1','web',1,1,0,'2023-01-26 15:59:33','2023-01-26 15:59:33'),(2,'Cashier#1','web',1,0,0,'2023-01-26 15:59:33','2023-01-26 15:59:33'),(3,'Admin#2','web',2,1,0,'2023-01-26 16:42:31','2023-01-26 16:42:31'),(4,'Cashier#2','web',2,0,0,'2023-01-26 16:42:31','2023-01-26 16:42:31'),(5,'Admin#3','web',3,1,0,'2023-01-26 19:20:15','2023-01-26 19:20:15'),(6,'Cashier#3','web',3,0,0,'2023-01-26 19:20:15','2023-01-26 19:20:15'),(7,'Admin#4','web',4,1,0,'2023-01-26 20:28:14','2023-01-26 20:28:14'),(8,'Cashier#4','web',4,0,0,'2023-01-26 20:28:14','2023-01-26 20:28:14'),(9,'Admin#5','web',5,1,0,'2023-01-28 21:05:09','2023-01-28 21:05:09'),(10,'Cashier#5','web',5,0,0,'2023-01-28 21:05:09','2023-01-28 21:05:09'),(11,'Admin#6','web',6,1,0,'2023-01-30 16:12:22','2023-01-30 16:12:22'),(12,'Cashier#6','web',6,0,0,'2023-01-30 16:12:22','2023-01-30 16:12:22'),(13,'Admin#7','web',7,1,0,'2023-02-01 10:48:07','2023-02-01 10:48:07'),(14,'Cashier#7','web',7,0,0,'2023-02-01 10:48:07','2023-02-01 10:48:07'),(15,'Admin#8','web',8,1,0,'2023-02-15 09:06:18','2023-02-15 09:06:18'),(16,'Cashier#8','web',8,0,0,'2023-02-15 09:06:18','2023-02-15 09:06:18'),(17,'Repartidor#2','web',2,0,0,'2023-02-17 10:54:13','2023-02-17 10:54:13'),(18,'Admin#9','web',9,1,0,'2023-03-06 13:58:51','2023-03-06 13:58:51'),(19,'Cashier#9','web',9,0,0,'2023-03-06 13:58:51','2023-03-06 13:58:51'),(20,'Admin#10','web',10,1,0,'2023-03-21 16:07:24','2023-03-21 16:07:24'),(21,'Cashier#10','web',10,0,0,'2023-03-21 16:07:24','2023-03-21 16:07:24'),(22,'Admin#11','web',11,1,0,'2023-03-22 12:12:28','2023-03-22 12:12:28'),(23,'Cashier#11','web',11,0,0,'2023-03-22 12:12:28','2023-03-22 12:12:28');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sell_line_warranties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sell_line_warranties` (
  `sell_line_id` int NOT NULL,
  `warranty_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sell_line_warranties` WRITE;
/*!40000 ALTER TABLE `sell_line_warranties` DISABLE KEYS */;
/*!40000 ALTER TABLE `sell_line_warranties` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `selling_price_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `selling_price_groups` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `business_id` int unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `selling_price_groups_business_id_foreign` (`business_id`),
  CONSTRAINT `selling_price_groups_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `selling_price_groups` WRITE;
/*!40000 ALTER TABLE `selling_price_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `selling_price_groups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `stock_adjustment_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_adjustment_lines` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` int unsigned NOT NULL,
  `product_id` int unsigned NOT NULL,
  `variation_id` int unsigned NOT NULL,
  `quantity` decimal(22,4) NOT NULL,
  `unit_price` decimal(22,4) DEFAULT NULL COMMENT 'Last purchase unit price',
  `removed_purchase_line` int DEFAULT NULL,
  `lot_no_line_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_adjustment_lines_product_id_foreign` (`product_id`),
  KEY `stock_adjustment_lines_variation_id_foreign` (`variation_id`),
  KEY `stock_adjustment_lines_transaction_id_index` (`transaction_id`),
  KEY `stock_adjustment_lines_lot_no_line_id_index` (`lot_no_line_id`),
  CONSTRAINT `stock_adjustment_lines_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_adjustment_lines_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_adjustment_lines_variation_id_foreign` FOREIGN KEY (`variation_id`) REFERENCES `variations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `stock_adjustment_lines` WRITE;
/*!40000 ALTER TABLE `stock_adjustment_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_adjustment_lines` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `stock_adjustments_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_adjustments_temp` (
  `id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `stock_adjustments_temp` WRITE;
/*!40000 ALTER TABLE `stock_adjustments_temp` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_adjustments_temp` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriptions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int unsigned NOT NULL,
  `package_id` int unsigned NOT NULL,
  `start_date` date DEFAULT NULL,
  `trial_end_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `package_price` decimal(22,4) NOT NULL,
  `package_details` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_id` int unsigned NOT NULL,
  `paid_via` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_transaction_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('approved','waiting','declined') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'waiting',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subscriptions_business_id_foreign` (`business_id`),
  KEY `subscriptions_package_id_index` (`package_id`),
  KEY `subscriptions_created_id_index` (`created_id`),
  CONSTRAINT `subscriptions_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
INSERT INTO `subscriptions` VALUES (1,1,1,'2023-01-26','2023-02-26','2023-02-26',0.0000,'{\"location_count\":1,\"user_count\":1,\"product_count\":10,\"invoice_count\":100,\"name\":\"Gratis\"}',1,NULL,'FREE','approved',NULL,'2023-01-26 16:36:33','2023-01-26 16:36:33'),(2,2,1,'2023-01-01','2023-01-25','2023-01-25',0.0000,'{\"location_count\":1,\"user_count\":1,\"product_count\":10,\"invoice_count\":100,\"name\":\"Gratis\"}',2,NULL,'FREE','approved',NULL,'2023-01-26 16:48:45','2023-01-26 17:25:48'),(3,2,2,'2023-01-26','2023-12-31','2023-12-31',1400.0000,'{\"location_count\":\"3\",\"user_count\":\"5\",\"product_count\":\"500\",\"invoice_count\":\"1000\",\"name\":\"Packete Basico\",\"connector_module\":\"1\",\"crm_module\":\"1\",\"productcatalogue_module\":\"1\"}',2,'offline','0012145857','approved',NULL,'2023-01-26 17:15:47','2023-01-31 18:46:44'),(4,3,2,'2023-01-26','2023-02-26','2023-02-26',1400.0000,'{\"location_count\":\"3\",\"user_count\":\"5\",\"product_count\":\"500\",\"invoice_count\":\"1000\",\"name\":\"Packete Basico\",\"connector_module\":\"1\",\"crm_module\":\"1\",\"productcatalogue_module\":\"1\"}',3,'offline',NULL,'approved',NULL,'2023-01-26 19:22:23','2023-01-31 18:46:44'),(5,4,2,'2023-01-26','2023-03-29','2023-02-26',1400.0000,'{\"location_count\":\"3\",\"user_count\":\"5\",\"product_count\":\"500\",\"invoice_count\":\"1000\",\"name\":\"Packete Basico\",\"connector_module\":\"1\",\"crm_module\":\"1\",\"productcatalogue_module\":\"1\"}',6,'offline',NULL,'approved',NULL,'2023-01-26 20:47:04','2023-03-29 10:17:07'),(6,5,2,'2023-01-28','2023-02-28','2023-02-28',1400.0000,'{\"location_count\":\"3\",\"user_count\":\"5\",\"product_count\":\"500\",\"invoice_count\":\"1000\",\"name\":\"Packete Basico\",\"connector_module\":\"1\",\"crm_module\":\"1\",\"productcatalogue_module\":\"1\"}',1,'offline',NULL,'approved',NULL,'2023-01-28 21:05:09','2023-01-31 18:46:44'),(7,7,1,'2023-02-01','2023-03-01','2023-03-01',0.0000,'{\"location_count\":1,\"user_count\":1,\"product_count\":10,\"invoice_count\":100,\"name\":\"Gratis\"}',1,'offline',NULL,'approved',NULL,'2023-02-01 10:48:08','2023-02-01 10:48:08'),(8,9,1,'2023-03-06','2023-04-06','2023-04-06',0.0000,'{\"location_count\":1,\"user_count\":1,\"product_count\":10,\"invoice_count\":100,\"name\":\"Gratis\"}',14,NULL,'FREE','approved',NULL,'2023-03-06 20:50:02','2023-03-06 20:50:02'),(9,10,2,'2023-03-21','2023-04-21','2023-04-21',1400.0000,'{\"location_count\":3,\"user_count\":5,\"product_count\":500,\"invoice_count\":1000,\"name\":\"Packete Basico\",\"connector_module\":\"1\",\"productcatalogue_module\":\"1\"}',15,'offline',NULL,'approved',NULL,'2023-03-21 16:13:16','2023-03-21 16:13:48'),(10,10,2,NULL,NULL,NULL,1400.0000,'{\"location_count\":3,\"user_count\":5,\"product_count\":500,\"invoice_count\":1000,\"name\":\"Packete Basico\",\"connector_module\":\"1\",\"productcatalogue_module\":\"1\"}',15,'offline',NULL,'waiting',NULL,'2023-03-21 16:14:29','2023-03-21 16:14:29'),(11,11,2,'2023-03-22','2024-03-22','2024-03-22',2100.0000,'{\"location_count\":3,\"user_count\":5,\"product_count\":500,\"invoice_count\":1000,\"name\":\"Packete Basico\"}',16,'offline',NULL,'approved',NULL,'2023-03-22 14:59:26','2023-03-22 14:59:44'),(12,5,2,'2023-03-01','2024-03-01','2024-03-01',2100.0000,'{\"location_count\":3,\"user_count\":5,\"product_count\":500,\"invoice_count\":1000,\"name\":\"Packete Basico\"}',1,'offline','00326565','approved',NULL,'2023-03-28 11:57:01','2023-03-28 11:57:01'),(13,4,2,'2023-02-27','2024-02-27','2024-02-27',2100.0000,'{\"location_count\":3,\"user_count\":5,\"product_count\":500,\"invoice_count\":1000,\"name\":\"Packete Basico\"}',1,'offline','651861','approved',NULL,'2023-03-29 10:17:45','2023-03-29 10:17:45');
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `superadmin_communicator_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `superadmin_communicator_logs` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_ids` text COLLATE utf8mb4_unicode_ci,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `superadmin_communicator_logs` WRITE;
/*!40000 ALTER TABLE `superadmin_communicator_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `superadmin_communicator_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `superadmin_frontend_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `superadmin_frontend_pages` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_shown` tinyint(1) NOT NULL,
  `menu_order` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `superadmin_frontend_pages` WRITE;
/*!40000 ALTER TABLE `superadmin_frontend_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `superadmin_frontend_pages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `system`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `system` WRITE;
/*!40000 ALTER TABLE `system` DISABLE KEYS */;
INSERT INTO `system` VALUES (1,'db_version','4.6'),(2,'default_business_active_status','1'),(4,'woocommerce_version','2.7'),(5,'superadmin_version','2.7'),(6,'app_currency_id','2'),(7,'invoice_business_name','Ultimate POS'),(8,'invoice_business_landmark','Landmark'),(9,'invoice_business_zip','Zip'),(10,'invoice_business_state','State'),(11,'invoice_business_city','City'),(12,'invoice_business_country','Country'),(13,'email','superadmin@example.com'),(14,'package_expiry_alert_days','5'),(15,'enable_business_based_username','0'),(17,'project_version','1.6'),(18,'productcatalogue_version','0.6'),(21,'superadmin_register_tc',NULL),(22,'welcome_email_subject',NULL),(23,'welcome_email_body',NULL),(24,'additional_js',NULL),(25,'additional_css',NULL),(26,'offline_payment_details','Datos para transferencia de otro banco a Soli (Sin comisión)\r\n\r\n Banco\r\n Banco de Crédito\r\n\r\n Tipo de cuenta\r\n Billetera móvil\r\n Número de cuenta 72823861\r\n\r\n Soli, Así de fácil 😉'),(27,'superadmin_enable_register_tc','0'),(28,'allow_email_settings_to_businesses','0'),(29,'enable_new_business_registration_notification','0'),(30,'enable_new_subscription_notification','0'),(31,'enable_welcome_email','0'),(32,'enable_offline_payment','1'),(34,'repair_version','1.1'),(37,'essentials_version','2.5'),(38,'manufacturing_version','2.1'),(39,'connector_version','1.7'),(40,'crm_version','1.4'),(41,'default_business_active_status','1'),(42,'superadmin_version','2.7'),(43,'app_currency_id','2'),(44,'invoice_business_name','Ultimate POS'),(45,'invoice_business_landmark','Landmark'),(46,'invoice_business_zip','Zip'),(47,'invoice_business_state','State'),(48,'invoice_business_city','City'),(49,'invoice_business_country','Country'),(50,'email','superadmin@example.com'),(51,'package_expiry_alert_days','5'),(52,'enable_business_based_username','0'),(53,'woocommerce_version','2.7'),(54,'repair_version','1.1'),(55,'essentials_version','2.5'),(56,'manufacturing_version','2.1'),(57,'project_version','1.6'),(58,'crm_version','1.4'),(59,'connector_version','1.7'),(60,'productcatalogue_version','0.6');
/*!40000 ALTER TABLE `system` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tax_rates` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double(22,4) NOT NULL,
  `is_tax_group` tinyint(1) NOT NULL DEFAULT '0',
  `for_tax_group` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` int unsigned NOT NULL,
  `woocommerce_tax_rate_id` int DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tax_rates_business_id_foreign` (`business_id`),
  KEY `tax_rates_created_by_foreign` (`created_by`),
  KEY `tax_rates_woocommerce_tax_rate_id_index` (`woocommerce_tax_rate_id`),
  CONSTRAINT `tax_rates_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tax_rates_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tax_rates` WRITE;
/*!40000 ALTER TABLE `tax_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tax_rates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `transaction_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_payments` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` int unsigned DEFAULT NULL,
  `business_id` int DEFAULT NULL,
  `is_return` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Used during sales to return the change',
  `amount` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_transaction_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_holder_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_month` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_year` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_security` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cheque_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_account_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_on` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `paid_through_link` tinyint(1) NOT NULL DEFAULT '0',
  `gateway` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_advance` tinyint(1) NOT NULL DEFAULT '0',
  `payment_for` int DEFAULT NULL,
  `parent_id` int DEFAULT NULL,
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_ref_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_payments_transaction_id_foreign` (`transaction_id`),
  KEY `transaction_payments_created_by_index` (`created_by`),
  KEY `transaction_payments_parent_id_index` (`parent_id`),
  CONSTRAINT `transaction_payments_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `transaction_payments` WRITE;
/*!40000 ALTER TABLE `transaction_payments` DISABLE KEYS */;
INSERT INTO `transaction_payments` VALUES (1,4,3,0,500.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-26 19:58:47',4,0,NULL,0,3,NULL,NULL,NULL,'SP2023/0001',NULL,'2023-01-26 19:58:47','2023-01-26 19:58:47'),(2,4,3,0,566.0000,'custom_pay_2',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-26 19:58:47',4,0,NULL,0,3,NULL,NULL,NULL,'SP2023/0002',NULL,'2023-01-26 19:58:47','2023-01-26 19:58:47'),(3,5,3,0,1916.1200,'other',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-26 19:58:47',5,0,NULL,0,3,NULL,'Dinero inicial por cambio de sistema',NULL,'SP2023/0003',NULL,'2023-01-26 19:58:47','2023-01-26 19:58:47'),(4,6,3,0,0.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-26 20:10:43',5,0,NULL,0,4,NULL,NULL,NULL,'SP2023/0004',NULL,'2023-01-26 20:10:43','2023-01-26 20:14:12'),(5,9,3,0,1396.0000,'bank_transfer',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 10:28:52',5,0,NULL,0,3,NULL,NULL,NULL,'SP2023/0005',NULL,'2023-01-27 10:28:52','2023-01-27 10:29:38'),(6,11,3,0,1075.0000,'bank_transfer',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:06:00',5,0,NULL,0,8,NULL,NULL,NULL,'SP2023/0006',NULL,'2023-01-27 16:07:52','2023-01-27 16:07:52'),(7,12,3,0,50.0000,'custom_pay_2',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-30 10:19:19',5,0,NULL,0,73,NULL,NULL,NULL,'SP2023/0007',NULL,'2023-01-30 10:19:19','2023-01-30 10:19:19'),(8,13,3,0,340.0000,'custom_pay_2',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-31 10:23:25',5,0,NULL,0,12,NULL,NULL,NULL,'SP2023/0008',NULL,'2023-01-31 10:23:25','2023-01-31 10:23:25'),(9,14,3,0,300.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-31 10:24:36',4,0,NULL,0,4,NULL,NULL,NULL,'SP2023/0009',NULL,'2023-01-31 10:24:36','2023-01-31 10:24:36'),(10,15,3,0,60.0000,'custom_pay_2',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-31 10:25:14',5,0,NULL,0,75,NULL,NULL,NULL,'SP2023/0010',NULL,'2023-01-31 10:25:14','2023-01-31 10:25:14'),(11,16,3,0,22.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-31 10:25:00',4,0,NULL,0,NULL,NULL,'Compra Papel Térmico',NULL,'SP2023/0011',NULL,'2023-01-31 10:26:16','2023-01-31 10:26:16'),(12,17,3,0,500.0000,'custom_pay_2',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-31 10:36:00',5,0,NULL,0,NULL,NULL,'pago de beneficios a favor de percy',NULL,'SP2023/0012',NULL,'2023-01-31 10:37:27','2023-01-31 10:37:27'),(14,18,3,0,340.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-03 10:52:34',5,0,NULL,0,77,NULL,NULL,NULL,'SP2023/0014',NULL,'2023-02-03 10:52:34','2023-02-03 10:52:34'),(15,19,3,0,500.0000,'custom_pay_2',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-03 14:10:00',4,0,NULL,0,NULL,NULL,'Pago de Beneficios Jonathan',NULL,'SP2023/0015',NULL,'2023-02-03 14:12:21','2023-02-03 14:12:21'),(16,20,3,0,423.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-03 14:20:59',4,0,NULL,0,8,NULL,'1 Cuota de 3',NULL,'SP2023/0016',NULL,'2023-02-03 14:20:59','2023-02-03 14:20:59'),(17,21,3,0,1100.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-10 19:36:01',4,0,NULL,0,78,NULL,NULL,NULL,'SP2023/0017',NULL,'2023-02-10 19:36:01','2023-02-10 19:36:01'),(18,22,3,0,250.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-10 19:40:09',4,0,NULL,0,79,NULL,NULL,NULL,'SP2023/0018',NULL,'2023-02-10 19:40:09','2023-02-10 19:40:09'),(19,23,3,0,1565.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-10 19:40:00',4,0,NULL,0,NULL,NULL,'Compra Infinix Note 12 256GB/8GB RAM',NULL,'SP2023/0019',NULL,'2023-02-10 19:41:59','2023-02-10 19:41:59'),(20,24,3,0,210.0000,'card',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-10 19:49:00',5,0,NULL,0,NULL,NULL,'pago por 2',NULL,'SP2023/0020',NULL,'2023-02-10 19:52:49','2023-02-10 19:52:49'),(21,7,3,0,125.0000,'custom_pay_2',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-10 20:06:00',4,0,NULL,0,5,NULL,NULL,NULL,'SP2023/0021',NULL,'2023-02-10 20:06:18','2023-02-10 20:06:18'),(22,29,5,0,2.1000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-13 20:27:00',8,0,NULL,0,80,NULL,NULL,NULL,'SP2023/0001',NULL,'2023-02-13 20:28:15','2023-02-13 20:28:15'),(23,42,3,0,1000.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-16 21:52:00',4,0,NULL,0,NULL,NULL,'Pago Beneficios',NULL,'SP2023/0022',NULL,'2023-02-16 21:53:51','2023-02-16 21:53:51'),(24,64,2,0,10.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-17 16:36:00',2,0,NULL,0,NULL,NULL,'se envio 20 carnes a la tradicion',NULL,'SP2023/0001',NULL,'2023-02-17 16:37:11','2023-02-17 16:37:11'),(44,86,2,0,15.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-17 18:38:46',11,0,NULL,0,2,NULL,NULL,NULL,'SP2023/0002',NULL,'2023-02-17 18:38:46','2023-02-17 18:38:46'),(45,21,3,0,640.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-26 20:47:00',4,0,NULL,0,78,NULL,NULL,NULL,'SP2023/0023',NULL,'2023-02-26 20:47:50','2023-02-26 20:47:50'),(46,14,3,0,200.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-01 21:59:00',4,0,NULL,0,4,NULL,NULL,NULL,'SP2023/0024',NULL,'2023-03-01 22:00:27','2023-03-01 22:00:27'),(64,103,5,0,14.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-28 12:36:19',8,0,NULL,0,72,NULL,NULL,NULL,'SP2023/0002',NULL,'2023-03-28 12:36:19','2023-03-28 12:36:19'),(65,104,5,0,15.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-28 12:40:19',8,0,NULL,0,72,NULL,NULL,NULL,'SP2023/0003',NULL,'2023-03-28 12:40:19','2023-03-28 12:40:19'),(66,113,5,0,20.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-29 10:53:00',8,0,NULL,0,81,NULL,NULL,NULL,'SP2023/0004',NULL,'2023-03-29 10:54:35','2023-03-29 10:54:35'),(67,115,5,0,50.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-29 11:00:00',8,0,NULL,0,90,NULL,NULL,NULL,'PP2023/0001',NULL,'2023-03-29 11:09:32','2023-03-29 11:09:32'),(71,121,4,0,20.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-29 14:11:27',6,0,NULL,0,6,NULL,NULL,NULL,'SP2023/0003',NULL,'2023-03-29 14:11:27','2023-03-29 14:11:27'),(72,121,4,1,6.0000,'cash',NULL,'','','','','',NULL,'','','','2023-03-29 14:11:27',6,0,NULL,0,6,NULL,'',NULL,'SP2023/0004',NULL,'2023-03-29 14:11:27','2023-03-29 14:11:27');
/*!40000 ALTER TABLE `transaction_payments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `transaction_sell_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_sell_lines` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` int unsigned NOT NULL,
  `product_id` int unsigned NOT NULL,
  `variation_id` int unsigned NOT NULL,
  `quantity` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `mfg_waste_percent` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `quantity_returned` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `unit_price_before_discount` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `unit_price` decimal(22,4) DEFAULT NULL COMMENT 'Sell price excluding tax',
  `line_discount_type` enum('fixed','percentage') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `line_discount_amount` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `unit_price_inc_tax` decimal(22,4) DEFAULT NULL COMMENT 'Sell price including tax',
  `item_tax` decimal(22,4) NOT NULL COMMENT 'Tax for one quantity',
  `tax_id` int unsigned DEFAULT NULL,
  `discount_id` int DEFAULT NULL,
  `lot_no_line_id` int DEFAULT NULL,
  `sell_line_note` text COLLATE utf8mb4_unicode_ci,
  `so_line_id` int DEFAULT NULL,
  `so_quantity_invoiced` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `res_service_staff_id` int DEFAULT NULL,
  `res_line_order_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `woocommerce_line_items_id` int DEFAULT NULL,
  `parent_sell_line_id` int DEFAULT NULL,
  `children_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Type of children for the parent, like modifier or combo',
  `sub_unit_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_sell_lines_transaction_id_foreign` (`transaction_id`),
  KEY `transaction_sell_lines_product_id_foreign` (`product_id`),
  KEY `transaction_sell_lines_variation_id_foreign` (`variation_id`),
  KEY `transaction_sell_lines_tax_id_foreign` (`tax_id`),
  KEY `transaction_sell_lines_children_type_index` (`children_type`),
  KEY `transaction_sell_lines_parent_sell_line_id_index` (`parent_sell_line_id`),
  KEY `transaction_sell_lines_line_discount_type_index` (`line_discount_type`),
  KEY `transaction_sell_lines_discount_id_index` (`discount_id`),
  KEY `transaction_sell_lines_lot_no_line_id_index` (`lot_no_line_id`),
  KEY `transaction_sell_lines_sub_unit_id_index` (`sub_unit_id`),
  KEY `transaction_sell_lines_woocommerce_line_items_id_index` (`woocommerce_line_items_id`),
  CONSTRAINT `transaction_sell_lines_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaction_sell_lines_tax_id_foreign` FOREIGN KEY (`tax_id`) REFERENCES `tax_rates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaction_sell_lines_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaction_sell_lines_variation_id_foreign` FOREIGN KEY (`variation_id`) REFERENCES `variations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `transaction_sell_lines` WRITE;
/*!40000 ALTER TABLE `transaction_sell_lines` DISABLE KEYS */;
INSERT INTO `transaction_sell_lines` VALUES (1,4,6,6,1.0000,0.0000,0.0000,1066.0000,1066.0000,'fixed',0.0000,1066.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-01-26 19:58:47','2023-01-26 19:58:47'),(2,5,7,7,1.0000,0.0000,0.0000,1916.1200,1916.1200,'fixed',0.0000,1916.1200,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-01-26 19:58:47','2023-01-26 19:58:47'),(3,6,5,5,1.0000,0.0000,0.0000,1950.0000,1950.0000,'fixed',0.0000,1950.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-01-26 20:10:43','2023-01-26 20:14:12'),(4,7,4,4,1.0000,0.0000,0.0000,350.0000,350.0000,'fixed',0.0000,350.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-01-26 20:14:10','2023-01-26 20:14:10'),(5,7,3,3,3.0000,0.0000,0.0000,60.0000,60.0000,'fixed',0.0000,60.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-01-26 20:14:10','2023-01-26 20:14:10'),(6,9,9,9,1.0000,0.0000,0.0000,1400.0000,1400.0000,'fixed',0.0000,1400.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-01-27 10:28:52','2023-01-27 10:29:38'),(8,12,3,3,1.0000,0.0000,0.0000,60.0000,60.0000,'fixed',0.0000,60.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-01-30 10:19:19','2023-01-30 10:19:19'),(9,13,3,3,6.0000,0.0000,0.0000,60.0000,60.0000,'fixed',0.0000,60.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-01-31 10:23:25','2023-01-31 10:23:25'),(10,14,3,3,3.0000,0.0000,0.0000,60.0000,60.0000,'fixed',0.0000,60.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-01-31 10:24:36','2023-01-31 10:24:36'),(11,14,4,4,1.0000,0.0000,0.0000,350.0000,350.0000,'fixed',0.0000,350.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-01-31 10:24:36','2023-01-31 10:24:36'),(12,15,3,3,1.0000,0.0000,0.0000,60.0000,60.0000,'fixed',0.0000,60.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-01-31 10:25:14','2023-01-31 10:25:14'),(13,18,3,3,6.0000,0.0000,0.0000,60.0000,60.0000,'fixed',0.0000,60.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-02-03 10:52:34','2023-02-03 10:52:34'),(14,20,10,10,1.0000,0.0000,0.0000,1270.0000,1270.0000,'fixed',0.0000,1270.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-02-03 14:20:59','2023-02-03 14:20:59'),(15,21,31,31,1.0000,0.0000,0.0000,1740.0000,1740.0000,'fixed',0.0000,1740.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-02-10 19:36:01','2023-02-10 19:36:01'),(16,22,4,4,1.0000,0.0000,0.0000,350.0000,350.0000,'fixed',0.0000,350.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-02-10 19:40:09','2023-02-10 19:40:09'),(17,22,3,3,3.0000,0.0000,0.0000,60.0000,60.0000,'fixed',0.0000,60.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-02-10 19:40:09','2023-02-10 19:40:09'),(18,29,33,33,1.0000,0.0000,0.0000,3.0000,3.0000,'fixed',0.0000,3.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-02-13 20:25:47','2023-02-13 20:25:47'),(19,30,34,34,10.0000,0.0000,0.0000,13.0000,13.0000,'fixed',0.0000,13.0000,0.0000,NULL,NULL,6,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-02-13 20:30:14','2023-02-13 20:30:14'),(20,31,35,35,30.0000,0.0000,0.0000,0.7000,0.7000,'fixed',0.0000,0.7000,0.0000,NULL,NULL,7,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-02-13 20:34:54','2023-02-13 20:34:54'),(21,32,33,33,50.0000,0.0000,0.0000,3.0000,3.0000,'fixed',0.0000,3.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-02-13 20:35:51','2023-02-13 20:35:51'),(22,33,34,34,5.0000,0.0000,0.0000,13.0000,13.0000,'fixed',0.0000,13.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-02-13 20:39:49','2023-02-13 20:39:49'),(23,34,34,34,1.0000,0.0000,0.0000,13.0000,13.0000,'fixed',0.0000,13.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-02-13 20:42:13','2023-02-13 20:42:13'),(24,35,33,33,10.0000,0.0000,0.0000,3.0000,3.0000,'fixed',0.0000,3.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-02-13 20:48:51','2023-02-13 20:48:51'),(28,63,12,12,10.0000,0.0000,0.0000,7.0000,7.0000,'fixed',0.0000,7.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-02-17 16:35:27','2023-02-17 16:35:27'),(29,65,27,27,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-02-17 17:53:05','2023-02-17 17:53:05'),(30,65,19,19,1.0000,0.0000,0.0000,0.7317,0.7317,NULL,0.0000,0.7317,0.0000,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,29,'combo',NULL,'2023-02-17 17:53:05','2023-02-17 17:53:05'),(31,65,24,24,1.0000,0.0000,0.0000,2.9268,2.9268,NULL,0.0000,2.9268,0.0000,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,29,'combo',NULL,'2023-02-17 17:53:05','2023-02-17 17:53:05'),(32,65,12,12,1.0000,0.0000,0.0000,10.2439,10.2439,NULL,0.0000,10.2439,0.0000,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,29,'combo',NULL,'2023-02-17 17:53:05','2023-02-17 17:53:05'),(33,65,26,26,1.0000,0.0000,0.0000,0.3659,0.3659,NULL,0.0000,0.3659,0.0000,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,29,'combo',NULL,'2023-02-17 17:53:05','2023-02-17 17:53:05'),(34,65,18,18,1.0000,0.0000,0.0000,0.7317,0.7317,NULL,0.0000,0.7317,0.0000,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,29,'combo',NULL,'2023-02-17 17:53:05','2023-02-17 17:53:05'),(35,66,27,27,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-02-17 17:53:29','2023-02-17 17:53:29'),(36,66,19,19,1.0000,0.0000,0.0000,0.7317,0.7317,NULL,0.0000,0.7317,0.0000,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,35,'combo',NULL,'2023-02-17 17:53:29','2023-02-17 17:53:29'),(37,66,24,24,1.0000,0.0000,0.0000,2.9268,2.9268,NULL,0.0000,2.9268,0.0000,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,35,'combo',NULL,'2023-02-17 17:53:29','2023-02-17 17:53:29'),(38,66,12,12,1.0000,0.0000,0.0000,10.2439,10.2439,NULL,0.0000,10.2439,0.0000,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,35,'combo',NULL,'2023-02-17 17:53:29','2023-02-17 17:53:29'),(39,66,26,26,1.0000,0.0000,0.0000,0.3659,0.3659,NULL,0.0000,0.3659,0.0000,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,35,'combo',NULL,'2023-02-17 17:53:29','2023-02-17 17:53:29'),(40,66,18,18,1.0000,0.0000,0.0000,0.7317,0.7317,NULL,0.0000,0.7317,0.0000,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,35,'combo',NULL,'2023-02-17 17:53:29','2023-02-17 17:53:29'),(155,86,27,27,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-02-17 18:38:46','2023-02-17 18:38:46'),(156,86,19,19,1.0000,0.0000,0.0000,0.7317,0.7317,NULL,0.0000,0.7317,0.0000,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,155,'combo',NULL,'2023-02-17 18:38:46','2023-02-17 18:38:46'),(157,86,24,24,1.0000,0.0000,0.0000,2.9268,2.9268,NULL,0.0000,2.9268,0.0000,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,155,'combo',NULL,'2023-02-17 18:38:46','2023-02-17 18:38:46'),(158,86,12,12,1.0000,0.0000,0.0000,10.2439,10.2439,NULL,0.0000,10.2439,0.0000,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,155,'combo',NULL,'2023-02-17 18:38:46','2023-02-17 18:38:46'),(159,86,26,26,1.0000,0.0000,0.0000,0.3659,0.3659,NULL,0.0000,0.3659,0.0000,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,155,'combo',NULL,'2023-02-17 18:38:46','2023-02-17 18:38:46'),(160,86,18,18,1.0000,0.0000,0.0000,0.7317,0.7317,NULL,0.0000,0.7317,0.0000,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,155,'combo',NULL,'2023-02-17 18:38:46','2023-02-17 18:38:46'),(185,103,255,255,7.0000,0.0000,0.0000,2.0000,2.0000,'fixed',0.0000,2.0000,0.0000,NULL,NULL,43,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-03-28 12:36:19','2023-03-28 12:36:19'),(186,104,33,33,5.0000,0.0000,0.0000,3.0000,3.0000,'fixed',0.0000,3.0000,0.0000,NULL,NULL,5,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-03-28 12:40:19','2023-03-28 12:40:19'),(187,112,272,272,1.0000,0.0000,0.0000,2.0000,2.0000,'fixed',0.0000,2.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-03-28 23:58:44','2023-03-28 23:58:44'),(188,112,34,34,1.0000,0.0000,0.0000,10.0000,10.0000,'fixed',0.0000,10.0000,0.0000,NULL,NULL,6,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-03-28 23:58:44','2023-03-28 23:58:44'),(189,112,255,255,1.0000,0.0000,0.0000,2.0000,2.0000,'fixed',0.0000,2.0000,0.0000,NULL,NULL,43,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-03-28 23:58:44','2023-03-28 23:58:44'),(190,113,35,35,59.0000,0.0000,0.0000,0.7000,0.7000,'fixed',0.0000,0.7000,0.0000,NULL,NULL,7,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-03-29 10:49:46','2023-03-29 10:49:46'),(191,113,34,34,1.0000,0.0000,0.0000,10.0000,10.0000,'fixed',0.0000,10.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-03-29 10:49:46','2023-03-29 10:49:46'),(192,114,255,255,1.0000,0.0000,0.0000,2.0000,2.0000,'fixed',0.0000,2.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-03-29 10:49:46','2023-03-29 10:49:46'),(193,114,35,35,1.0000,0.0000,0.0000,0.7000,0.7000,'fixed',0.0000,0.7000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-03-29 10:49:46','2023-03-29 10:49:46'),(195,121,275,275,7.0000,0.0000,0.0000,2.0000,2.0000,'fixed',0.0000,2.0000,0.0000,NULL,NULL,NULL,'',NULL,0.0000,NULL,NULL,NULL,NULL,'',NULL,'2023-03-29 14:11:27','2023-03-29 14:11:27');
/*!40000 ALTER TABLE `transaction_sell_lines` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `transaction_sell_lines_purchase_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_sell_lines_purchase_lines` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `sell_line_id` int unsigned DEFAULT NULL COMMENT 'id from transaction_sell_lines',
  `stock_adjustment_line_id` int unsigned DEFAULT NULL COMMENT 'id from stock_adjustment_lines',
  `purchase_line_id` int unsigned NOT NULL COMMENT 'id from purchase_lines',
  `quantity` decimal(22,4) NOT NULL,
  `qty_returned` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sell_line_id` (`sell_line_id`),
  KEY `stock_adjustment_line_id` (`stock_adjustment_line_id`),
  KEY `purchase_line_id` (`purchase_line_id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `transaction_sell_lines_purchase_lines` WRITE;
/*!40000 ALTER TABLE `transaction_sell_lines_purchase_lines` DISABLE KEYS */;
INSERT INTO `transaction_sell_lines_purchase_lines` VALUES (1,4,NULL,2,1.0000,0.0000,'2023-01-26 20:14:10','2023-01-26 20:14:10'),(2,5,NULL,1,3.0000,0.0000,'2023-01-26 20:14:11','2023-01-26 20:14:11'),(3,8,NULL,1,1.0000,0.0000,'2023-01-30 10:19:19','2023-01-30 10:19:19'),(4,9,NULL,1,6.0000,0.0000,'2023-01-31 10:23:25','2023-01-31 10:23:25'),(5,10,NULL,1,3.0000,0.0000,'2023-01-31 10:24:36','2023-01-31 10:24:36'),(6,11,NULL,2,1.0000,0.0000,'2023-01-31 10:24:36','2023-01-31 10:24:36'),(7,12,NULL,1,1.0000,0.0000,'2023-01-31 10:25:14','2023-01-31 10:25:14'),(8,13,NULL,1,6.0000,0.0000,'2023-02-03 10:52:34','2023-02-03 10:52:34'),(9,16,NULL,2,1.0000,0.0000,'2023-02-10 19:40:09','2023-02-10 19:40:09'),(10,17,NULL,1,3.0000,0.0000,'2023-02-10 19:40:09','2023-02-10 19:40:09'),(11,18,NULL,5,1.0000,0.0000,'2023-02-13 20:25:47','2023-02-13 20:25:47'),(12,19,NULL,6,10.0000,0.0000,'2023-02-13 20:30:14','2023-02-13 20:30:14'),(13,20,NULL,7,30.0000,0.0000,'2023-02-13 20:34:54','2023-02-13 20:34:54'),(14,21,NULL,5,50.0000,0.0000,'2023-02-13 20:35:51','2023-02-13 20:35:51'),(15,22,NULL,6,5.0000,0.0000,'2023-02-13 20:39:49','2023-02-13 20:39:49'),(16,23,NULL,6,1.0000,0.0000,'2023-02-13 20:42:13','2023-02-13 20:42:13'),(17,24,NULL,5,10.0000,0.0000,'2023-02-13 20:48:51','2023-02-13 20:48:51'),(31,156,NULL,38,1.0000,0.0000,'2023-02-17 18:38:47','2023-02-17 18:38:47'),(32,157,NULL,39,1.0000,0.0000,'2023-02-17 18:38:47','2023-02-17 18:38:47'),(33,158,NULL,40,1.0000,0.0000,'2023-02-17 18:38:47','2023-02-17 18:38:47'),(34,159,NULL,41,1.0000,0.0000,'2023-02-17 18:38:47','2023-02-17 18:38:47'),(35,160,NULL,42,1.0000,0.0000,'2023-02-17 18:38:47','2023-02-17 18:38:47'),(36,185,NULL,43,7.0000,0.0000,'2023-03-28 12:36:19','2023-03-28 12:36:19'),(37,186,NULL,5,5.0000,0.0000,'2023-03-28 12:40:19','2023-03-28 12:40:19'),(38,187,NULL,51,1.0000,0.0000,'2023-03-28 23:58:44','2023-03-28 23:58:44'),(39,188,NULL,6,1.0000,0.0000,'2023-03-28 23:58:44','2023-03-28 23:58:44'),(40,189,NULL,43,1.0000,0.0000,'2023-03-28 23:58:44','2023-03-28 23:58:44'),(41,190,NULL,7,59.0000,0.0000,'2023-03-29 10:49:46','2023-03-29 10:49:46'),(42,191,NULL,6,1.0000,0.0000,'2023-03-29 10:49:46','2023-03-29 10:49:46'),(43,192,NULL,43,1.0000,0.0000,'2023-03-29 10:49:46','2023-03-29 10:49:46'),(44,193,NULL,7,1.0000,0.0000,'2023-03-29 10:49:46','2023-03-29 10:49:46'),(46,195,NULL,57,7.0000,0.0000,'2023-03-29 14:11:27','2023-03-29 14:11:27');
/*!40000 ALTER TABLE `transaction_sell_lines_purchase_lines` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int unsigned NOT NULL,
  `location_id` int unsigned DEFAULT NULL,
  `res_table_id` int unsigned DEFAULT NULL COMMENT 'fields to restaurant module',
  `res_waiter_id` int unsigned DEFAULT NULL COMMENT 'fields to restaurant module',
  `res_order_status` enum('received','cooked','served') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_quotation` tinyint(1) NOT NULL DEFAULT '0',
  `payment_status` enum('paid','due','partial') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `adjustment_type` enum('normal','abnormal') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` int unsigned DEFAULT NULL,
  `customer_group_id` int DEFAULT NULL COMMENT 'used to add customer group while selling',
  `invoice_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subscription_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subscription_repeat_on` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_date` datetime NOT NULL,
  `total_before_tax` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Total before the purchase/invoice tax, this includeds the indivisual product tax',
  `tax_id` int unsigned DEFAULT NULL,
  `tax_amount` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `discount_type` enum('fixed','percentage') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_amount` decimal(22,4) DEFAULT '0.0000',
  `rp_redeemed` int NOT NULL DEFAULT '0' COMMENT 'rp is the short form of reward points',
  `rp_redeemed_amount` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'rp is the short form of reward points',
  `shipping_details` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address` text COLLATE utf8mb4_unicode_ci,
  `shipping_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivered_to` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_charges` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `shipping_custom_field_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_custom_field_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_custom_field_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_custom_field_4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_custom_field_5` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_notes` text COLLATE utf8mb4_unicode_ci,
  `staff_note` text COLLATE utf8mb4_unicode_ci,
  `is_export` tinyint(1) NOT NULL DEFAULT '0',
  `export_custom_fields_info` longtext COLLATE utf8mb4_unicode_ci,
  `round_off_amount` decimal(22,4) NOT NULL DEFAULT '0.0000' COMMENT 'Difference of rounded total and actual total',
  `additional_expense_key_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_expense_value_1` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `additional_expense_key_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_expense_value_2` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `additional_expense_key_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_expense_value_3` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `additional_expense_key_4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_expense_value_4` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `final_total` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `expense_category_id` int unsigned DEFAULT NULL,
  `expense_for` int unsigned DEFAULT NULL,
  `commission_agent` int DEFAULT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_direct_sale` tinyint(1) NOT NULL DEFAULT '0',
  `is_suspend` tinyint(1) NOT NULL DEFAULT '0',
  `exchange_rate` decimal(20,3) NOT NULL DEFAULT '1.000',
  `total_amount_recovered` decimal(22,4) DEFAULT NULL COMMENT 'Used for stock adjustment.',
  `transfer_parent_id` int DEFAULT NULL,
  `return_parent_id` int DEFAULT NULL,
  `opening_stock_product_id` int DEFAULT NULL,
  `created_by` int unsigned NOT NULL,
  `crm_is_order_request` tinyint(1) NOT NULL DEFAULT '0',
  `prefer_payment_method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prefer_payment_account` int DEFAULT NULL,
  `sales_order_ids` text COLLATE utf8mb4_unicode_ci,
  `purchase_order_ids` text COLLATE utf8mb4_unicode_ci,
  `custom_field_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `import_batch` int DEFAULT NULL,
  `import_time` datetime DEFAULT NULL,
  `types_of_service_id` int DEFAULT NULL,
  `packing_charge` decimal(22,4) DEFAULT NULL,
  `packing_charge_type` enum('fixed','percent') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_custom_field_1` text COLLATE utf8mb4_unicode_ci,
  `service_custom_field_2` text COLLATE utf8mb4_unicode_ci,
  `service_custom_field_3` text COLLATE utf8mb4_unicode_ci,
  `service_custom_field_4` text COLLATE utf8mb4_unicode_ci,
  `service_custom_field_5` text COLLATE utf8mb4_unicode_ci,
  `service_custom_field_6` text COLLATE utf8mb4_unicode_ci,
  `mfg_parent_production_purchase_id` int DEFAULT NULL,
  `mfg_wasted_units` decimal(22,4) DEFAULT NULL,
  `mfg_production_cost` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `mfg_production_cost_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'percentage',
  `mfg_is_final` tinyint(1) NOT NULL DEFAULT '0',
  `is_created_from_api` tinyint(1) NOT NULL DEFAULT '0',
  `essentials_duration` decimal(8,2) NOT NULL,
  `essentials_duration_unit` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `essentials_amount_per_unit_duration` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `essentials_allowances` text COLLATE utf8mb4_unicode_ci,
  `essentials_deductions` text COLLATE utf8mb4_unicode_ci,
  `rp_earned` int NOT NULL DEFAULT '0' COMMENT 'rp is the short form of reward points',
  `repair_completed_on` datetime DEFAULT NULL,
  `repair_warranty_id` int DEFAULT NULL,
  `repair_brand_id` int DEFAULT NULL,
  `repair_status_id` int DEFAULT NULL,
  `repair_model_id` int DEFAULT NULL,
  `repair_job_sheet_id` int unsigned DEFAULT NULL,
  `repair_defects` text COLLATE utf8mb4_unicode_ci,
  `repair_serial_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repair_checklist` text COLLATE utf8mb4_unicode_ci,
  `repair_security_pwd` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repair_security_pattern` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repair_due_date` datetime DEFAULT NULL,
  `repair_device_id` int DEFAULT NULL,
  `repair_updates_notif` tinyint(1) NOT NULL DEFAULT '0',
  `order_addresses` text COLLATE utf8mb4_unicode_ci,
  `is_recurring` tinyint(1) NOT NULL DEFAULT '0',
  `recur_interval` double(22,4) DEFAULT NULL,
  `recur_interval_type` enum('days','months','years') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recur_repetitions` int DEFAULT NULL,
  `recur_stopped_on` datetime DEFAULT NULL,
  `recur_parent_id` int DEFAULT NULL,
  `invoice_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pay_term_number` int DEFAULT NULL,
  `pay_term_type` enum('days','months') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pjt_project_id` int unsigned DEFAULT NULL,
  `pjt_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `woocommerce_order_id` int DEFAULT NULL,
  `selling_price_group_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transactions_tax_id_foreign` (`tax_id`),
  KEY `transactions_business_id_index` (`business_id`),
  KEY `transactions_type_index` (`type`),
  KEY `transactions_contact_id_index` (`contact_id`),
  KEY `transactions_transaction_date_index` (`transaction_date`),
  KEY `transactions_created_by_index` (`created_by`),
  KEY `transactions_location_id_index` (`location_id`),
  KEY `transactions_expense_for_foreign` (`expense_for`),
  KEY `transactions_expense_category_id_index` (`expense_category_id`),
  KEY `transactions_repair_model_id_index` (`repair_model_id`),
  KEY `transactions_sub_type_index` (`sub_type`),
  KEY `transactions_return_parent_id_index` (`return_parent_id`),
  KEY `type` (`type`),
  KEY `transactions_pjt_project_id_foreign` (`pjt_project_id`),
  KEY `transactions_status_index` (`status`),
  KEY `transactions_sub_status_index` (`sub_status`),
  KEY `transactions_res_table_id_index` (`res_table_id`),
  KEY `transactions_res_waiter_id_index` (`res_waiter_id`),
  KEY `transactions_res_order_status_index` (`res_order_status`),
  KEY `transactions_payment_status_index` (`payment_status`),
  KEY `transactions_discount_type_index` (`discount_type`),
  KEY `transactions_commission_agent_index` (`commission_agent`),
  KEY `transactions_transfer_parent_id_index` (`transfer_parent_id`),
  KEY `transactions_types_of_service_id_index` (`types_of_service_id`),
  KEY `transactions_packing_charge_type_index` (`packing_charge_type`),
  KEY `transactions_recur_parent_id_index` (`recur_parent_id`),
  KEY `transactions_selling_price_group_id_index` (`selling_price_group_id`),
  KEY `transactions_repair_warranty_id_index` (`repair_warranty_id`),
  KEY `transactions_repair_brand_id_index` (`repair_brand_id`),
  KEY `transactions_repair_status_id_index` (`repair_status_id`),
  KEY `transactions_repair_device_id_index` (`repair_device_id`),
  KEY `transactions_repair_job_sheet_id_index` (`repair_job_sheet_id`),
  KEY `transactions_woocommerce_order_id_index` (`woocommerce_order_id`),
  CONSTRAINT `transactions_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_expense_category_id_foreign` FOREIGN KEY (`expense_category_id`) REFERENCES `expense_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_expense_for_foreign` FOREIGN KEY (`expense_for`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `business_locations` (`id`),
  CONSTRAINT `transactions_pjt_project_id_foreign` FOREIGN KEY (`pjt_project_id`) REFERENCES `pjt_projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_repair_job_sheet_id_foreign` FOREIGN KEY (`repair_job_sheet_id`) REFERENCES `repair_job_sheets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_tax_id_foreign` FOREIGN KEY (`tax_id`) REFERENCES `tax_rates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (1,3,5,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 19:29:07',1665.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1665.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,3,3,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-26 19:29:07','2023-01-26 20:10:53'),(2,3,5,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 19:32:40',1060.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1060.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,4,3,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-26 19:32:40','2023-01-26 20:10:31'),(3,3,5,NULL,NULL,NULL,'expense',NULL,'final',NULL,0,'due',NULL,NULL,NULL,NULL,'EP2023/0001',NULL,NULL,NULL,'2023-01-26 19:40:00',3000.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,'Prestamo Compra Creditos MagisTV',NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,3000.0000,1,3,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,4,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-26 19:44:35','2023-01-26 19:44:35'),(4,3,5,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,3,NULL,'0001','',NULL,NULL,NULL,'2023-01-26 19:58:47',1066.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1066.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,4,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2023-01-26 19:58:47','2023-01-26 19:58:47'),(5,3,5,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,3,NULL,'0002','',NULL,NULL,NULL,'2023-01-26 19:58:47',1916.1200,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1916.1200,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,5,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2023-01-26 19:58:47','2023-01-26 19:58:47'),(6,3,5,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'due',NULL,4,NULL,'0003','',NULL,NULL,NULL,'2023-01-26 20:10:43',1950.0000,NULL,0.0000,'fixed',1000.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,950.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,5,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-26 20:10:43','2023-01-26 20:14:12'),(7,3,5,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'partial',NULL,5,NULL,'0004','',NULL,NULL,NULL,'2023-01-26 20:14:10',530.0000,NULL,0.0000,'fixed',155.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,375.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,4,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2023-01-26 20:14:10','2023-02-10 20:06:18'),(8,4,6,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 20:53:52',800.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,800.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,8,6,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-26 20:53:52','2023-03-29 13:49:40'),(9,3,5,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,7,NULL,'0005','',NULL,NULL,NULL,'2023-01-27 10:28:52',1400.0000,NULL,0.0000,'fixed',4.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1396.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,5,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 10:28:52','2023-01-27 10:29:38'),(11,3,5,NULL,NULL,NULL,'expense',NULL,'final',NULL,0,'paid',NULL,8,NULL,NULL,'EP2023/0002',NULL,NULL,NULL,'2023-01-27 16:06:00',1075.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,'compra de celular para jorge',NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1075.0000,4,5,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,5,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,0.0000,'days',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-27 16:07:52','2023-02-03 14:23:11'),(12,3,5,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,73,NULL,'0007','',NULL,NULL,NULL,'2023-01-30 10:19:19',60.0000,NULL,0.0000,'fixed',10.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,50.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,5,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2023-01-30 10:19:19','2023-01-30 10:19:19'),(13,3,5,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,12,NULL,'0008','',NULL,NULL,NULL,'2023-01-31 10:23:25',360.0000,NULL,0.0000,'fixed',20.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,340.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,5,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-31 10:23:25','2023-01-31 10:23:25'),(14,3,5,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,4,NULL,'0009','',NULL,NULL,NULL,'2023-01-31 10:24:36',530.0000,NULL,0.0000,'fixed',30.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,500.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,4,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-31 10:24:36','2023-03-01 22:00:27'),(15,3,5,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,75,NULL,'0010','',NULL,NULL,NULL,'2023-01-31 10:25:14',60.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,60.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,5,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-31 10:25:14','2023-01-31 10:25:14'),(16,3,5,NULL,NULL,NULL,'expense',NULL,'final',NULL,0,'paid',NULL,NULL,NULL,NULL,'EP2023/0003',NULL,NULL,NULL,'2023-01-31 10:25:00',22.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,'Compra Papel Térmico',NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,22.0000,2,4,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,4,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-31 10:26:16','2023-01-31 10:26:16'),(17,3,5,NULL,NULL,NULL,'expense',NULL,'final',NULL,0,'paid',NULL,NULL,NULL,NULL,'EP2023/0004',NULL,NULL,NULL,'2023-01-31 10:36:00',500.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,'pago de beneficios a favor de percy',NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,500.0000,3,5,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,5,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-31 10:37:27','2023-01-31 10:37:27'),(18,3,5,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,77,NULL,'0011','',NULL,NULL,'7','2023-02-03 10:52:34',360.0000,NULL,0.0000,'fixed',20.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,340.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,5,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2023-02-03 10:52:34','2023-02-03 10:52:34'),(19,3,5,NULL,NULL,NULL,'expense',NULL,'final',NULL,0,'paid',NULL,NULL,NULL,NULL,'EP2023/0005',NULL,NULL,NULL,'2023-02-03 14:10:00',500.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,'Pago de Beneficios Jonathan',NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,500.0000,3,4,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,4,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-03 14:12:21','2023-02-03 14:12:21'),(20,3,5,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'partial',NULL,8,NULL,'0012','',NULL,NULL,NULL,'2023-02-03 14:20:59',1270.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1270.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,4,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-03 14:20:59','2023-02-03 14:20:59'),(21,3,5,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,78,NULL,'0013','',NULL,NULL,NULL,'2023-02-10 19:36:01',1740.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1740.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,4,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2023-02-10 19:36:01','2023-02-26 20:47:50'),(22,3,5,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'partial',NULL,79,NULL,'0014','',NULL,NULL,NULL,'2023-02-10 19:40:09',530.0000,NULL,0.0000,'fixed',30.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,500.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,4,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2023-02-10 19:40:09','2023-02-10 19:40:09'),(23,3,5,NULL,NULL,NULL,'expense',NULL,'final',NULL,0,'paid',NULL,NULL,NULL,NULL,'EP2023/0006',NULL,NULL,NULL,'2023-02-10 19:40:00',1565.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,'Compra Infinix Note 12 256GB/8GB RAM',NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1565.0000,4,4,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,4,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-10 19:41:59','2023-02-10 19:41:59'),(24,3,5,NULL,NULL,NULL,'expense',NULL,'final',NULL,0,'paid',NULL,NULL,NULL,NULL,'210',NULL,NULL,NULL,'2023-02-10 19:49:00',210.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,210.0000,5,5,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,5,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,0.0000,'days',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-10 19:52:49','2023-02-11 00:59:00'),(25,5,7,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 19:03:59',240.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,240.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,32,8,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-13 19:03:59','2023-02-13 19:35:22'),(26,5,7,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 19:37:31',270.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,270.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,33,8,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-13 19:37:31','2023-02-13 19:37:31'),(27,5,7,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 20:01:55',200.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,200.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,34,8,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-13 20:01:55','2023-02-13 20:01:55'),(28,5,7,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 20:10:10',200.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,200.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,35,8,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-13 20:10:10','2023-02-13 20:10:10'),(29,5,7,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,80,NULL,'0001','',NULL,NULL,NULL,'2023-02-13 20:23:00',3.0000,NULL,0.0000,'percentage',30.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,2.1000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,8,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2023-02-13 20:25:47','2023-02-13 20:28:15'),(30,5,7,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'due',NULL,80,NULL,'0002','',NULL,NULL,NULL,'2023-02-13 20:29:00',130.0000,NULL,0.0000,'percentage',30.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,91.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,8,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-13 20:30:14','2023-02-13 20:30:14'),(31,5,7,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'due',NULL,80,NULL,'0003','',NULL,NULL,NULL,'2023-02-13 20:34:00',21.0000,NULL,0.0000,'percentage',30.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,14.7000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,8,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-13 20:34:54','2023-02-13 20:34:54'),(32,5,7,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'due',NULL,80,NULL,'0004','',NULL,NULL,NULL,'2023-02-13 20:34:00',150.0000,NULL,0.0000,'percentage',30.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,105.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,8,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-13 20:35:51','2023-02-13 20:35:51'),(33,5,7,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'due',NULL,80,NULL,'0005','',NULL,NULL,NULL,'2023-02-13 20:39:00',65.0000,NULL,0.0000,'percentage',30.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,45.5000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,8,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-13 20:39:49','2023-02-13 20:39:49'),(34,5,7,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'due',NULL,80,NULL,'0006','',NULL,NULL,NULL,'2023-02-13 20:41:00',13.0000,NULL,0.0000,'percentage',30.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,9.1000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,8,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-13 20:42:13','2023-02-13 20:42:13'),(35,5,7,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'due',NULL,81,NULL,'0007','',NULL,NULL,NULL,'2023-02-13 20:42:00',30.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,30.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,8,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-13 20:48:51','2023-02-13 20:48:51'),(40,2,3,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 10:40:43',82.5000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,82.5000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,27,2,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-16 10:40:43','2023-02-17 17:48:22'),(42,3,5,NULL,NULL,NULL,'expense',NULL,'final',NULL,0,'paid',NULL,NULL,NULL,NULL,'EP2023/0008',NULL,NULL,NULL,'2023-02-16 21:52:00',1000.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,'Pago Beneficios',NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1000.0000,3,4,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,4,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-16 21:53:51','2023-02-16 21:53:51'),(50,2,3,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 12:23:57',0.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,0.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,13,2,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-17 12:23:57','2023-02-17 16:13:53'),(51,2,3,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 12:24:22',0.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,0.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,14,2,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-17 12:24:22','2023-02-17 16:14:41'),(52,2,3,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 12:24:34',0.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,0.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,16,2,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-17 12:24:34','2023-02-17 16:23:22'),(53,2,3,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 12:24:44',0.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,0.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,17,2,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-17 12:24:44','2023-02-17 16:23:45'),(54,2,3,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 12:25:13',0.5000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,0.5000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,19,2,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-17 12:25:13','2023-02-17 18:37:08'),(55,2,3,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 12:35:03',0.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,0.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,36,2,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-17 12:35:03','2023-02-17 16:18:06'),(56,2,3,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 12:38:49',0.5000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,0.5000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,18,2,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-17 12:38:49','2023-02-17 18:38:43'),(57,2,3,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 12:40:22',0.2500,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,0.2500,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,26,2,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-17 12:40:22','2023-02-17 18:38:26'),(58,2,3,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 12:57:59',0.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,0.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,15,2,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-17 12:57:59','2023-02-17 16:14:55'),(59,2,3,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 13:03:04',0.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,0.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,20,2,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-17 13:03:04','2023-02-17 16:16:24'),(60,2,3,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 13:05:05',2.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,2.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,24,2,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-17 13:05:05','2023-02-17 18:37:39'),(61,2,3,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 16:29:10',5.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,5.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,12,2,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-17 16:29:10','2023-02-17 18:38:10'),(62,2,3,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 16:29:59',0.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,0.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,23,2,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-17 16:29:59','2023-02-17 16:34:27'),(63,2,3,NULL,NULL,NULL,'sell',NULL,'draft','quotation',1,NULL,NULL,2,NULL,'2023/0001','',NULL,NULL,NULL,'2023-02-17 16:34:00',70.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,70.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,2,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2023-02-17 16:35:27','2023-02-17 16:35:27'),(64,2,3,NULL,NULL,NULL,'expense',NULL,'final',NULL,0,'paid',NULL,NULL,NULL,NULL,'EP2023/0001',NULL,NULL,NULL,'2023-02-17 16:36:00',10.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,'delivery tradicion',NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,10.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,2,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-17 16:37:11','2023-02-17 16:37:11'),(65,2,3,NULL,NULL,NULL,'sell',NULL,'draft','quotation',1,NULL,NULL,2,NULL,'2023/0002','',NULL,NULL,NULL,'2023-02-17 17:52:00',15.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,15.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,2,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2023-02-17 17:53:05','2023-02-17 17:53:05'),(66,2,3,NULL,NULL,NULL,'sell',NULL,'draft','quotation',1,NULL,NULL,2,NULL,'2023/0003','',NULL,NULL,NULL,'2023-02-17 17:53:00',15.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,15.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,2,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2023-02-17 17:53:29','2023-02-17 17:53:29'),(86,2,3,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,2,NULL,'0001','',NULL,NULL,NULL,'2023-02-17 18:37:00',15.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,15.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,11,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2023-02-17 18:38:46','2023-02-17 18:38:46'),(101,5,7,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 12:15:41',100.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,100.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,255,8,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-28 12:15:41','2023-03-28 12:15:41'),(102,5,7,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 12:15:53',250.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,250.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,256,8,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-28 12:15:53','2023-03-28 12:15:53'),(103,5,7,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,72,NULL,'0008','',NULL,NULL,NULL,'2023-03-28 12:30:00',14.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,14.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,8,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2023-03-28 12:36:19','2023-03-28 12:36:19'),(104,5,7,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,72,NULL,'0009','',NULL,NULL,NULL,'2023-03-28 12:36:00',15.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,15.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,8,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2023-03-28 12:40:19','2023-03-28 12:40:19'),(105,10,12,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 22:59:38',1397.3100,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1397.3100,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,257,15,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-28 22:59:38','2023-03-28 22:59:38'),(106,10,12,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 23:01:55',252.6000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,252.6000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,258,15,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-28 23:01:55','2023-03-28 23:01:55'),(107,10,12,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 23:02:35',78.2000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,78.2000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,259,15,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-28 23:02:36','2023-03-28 23:02:36'),(108,10,12,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 23:05:55',797.1800,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,797.1800,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,261,15,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-28 23:05:55','2023-03-28 23:05:55'),(109,10,12,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 23:06:26',204.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,204.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,262,15,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-28 23:06:26','2023-03-28 23:06:26'),(110,10,12,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 23:18:02',204.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,204.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,271,15,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-28 23:18:02','2023-03-28 23:18:02'),(111,5,7,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 23:48:32',60.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,60.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,272,8,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-28 23:48:32','2023-03-28 23:48:32'),(112,5,7,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'due',NULL,81,NULL,'0010','',NULL,NULL,NULL,'2023-03-28 23:56:00',14.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,14.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,8,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-28 23:58:44','2023-03-28 23:58:44'),(113,5,7,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'partial',NULL,81,NULL,'0011','',NULL,NULL,NULL,'2023-03-29 10:45:00',51.3000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,51.3000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,8,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-29 10:49:46','2023-03-29 10:54:35'),(114,5,7,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'due',NULL,81,NULL,'0012','',NULL,NULL,NULL,'2023-03-29 10:45:00',2.7000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,2.7000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,8,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-29 10:49:46','2023-03-29 10:49:46'),(115,5,7,NULL,NULL,NULL,'purchase',NULL,'received',NULL,0,'partial',NULL,90,NULL,NULL,'PO2023/0001',NULL,NULL,NULL,'2023-03-29 11:00:00',52.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,52.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,8,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-29 11:09:32','2023-03-29 11:09:32'),(116,4,6,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 11:47:55',250.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,250.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,274,6,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-29 11:47:55','2023-03-29 11:47:55'),(119,4,6,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 13:50:40',50.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,50.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,273,6,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-29 13:50:40','2023-03-29 13:50:40'),(120,4,6,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 14:10:27',50.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,50.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,275,6,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-29 14:10:27','2023-03-29 14:10:27'),(121,4,6,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,6,NULL,'REC-2023-0002','',NULL,NULL,NULL,'2023-03-29 14:10:00',14.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,14.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,6,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2023-03-29 14:11:27','2023-03-29 14:11:27'),(122,10,12,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 01:00:15',490.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,490.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,312,15,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-30 01:00:15','2023-03-30 01:00:15'),(123,10,12,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 01:00:56',519.4700,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,519.4700,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,313,15,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-30 01:00:56','2023-03-30 01:00:56'),(124,10,12,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 01:01:22',294.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,294.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,314,15,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-30 01:01:22','2023-03-30 01:01:22'),(125,10,12,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 01:02:03',756.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,756.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,315,15,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-30 01:02:03','2023-03-30 01:02:03'),(126,10,12,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 01:02:42',1498.5000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1498.5000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,316,15,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-30 01:02:42','2023-03-30 01:02:42'),(127,10,12,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-01 01:03:49',300.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,300.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,318,15,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,'percentage',0,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-30 01:03:49','2023-03-30 01:03:49');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `types_of_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `types_of_services` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `business_id` int NOT NULL,
  `location_price_group` text COLLATE utf8mb4_unicode_ci,
  `packing_charge` decimal(22,4) DEFAULT NULL,
  `packing_charge_type` enum('fixed','percent') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enable_custom_fields` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `types_of_services_business_id_index` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `types_of_services` WRITE;
/*!40000 ALTER TABLE `types_of_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `types_of_services` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `units` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int unsigned NOT NULL,
  `actual_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `allow_decimal` tinyint(1) NOT NULL,
  `base_unit_id` int DEFAULT NULL,
  `base_unit_multiplier` decimal(20,4) DEFAULT NULL,
  `created_by` int unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `units_business_id_foreign` (`business_id`),
  KEY `units_created_by_foreign` (`created_by`),
  KEY `units_base_unit_id_index` (`base_unit_id`),
  CONSTRAINT `units_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `units_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` VALUES (1,1,'Pieces','Pc(s)',0,NULL,NULL,1,NULL,'2023-01-26 15:59:33','2023-01-26 15:59:33'),(2,2,'Pieces','Pc(s)',0,NULL,NULL,2,NULL,'2023-01-26 16:42:31','2023-01-26 16:42:31'),(3,3,'Pieces','Pc(s)',0,NULL,NULL,3,NULL,'2023-01-26 19:20:15','2023-01-26 19:20:15'),(4,4,'Pieces','Pc(s)',0,NULL,NULL,6,NULL,'2023-01-26 20:28:14','2023-01-26 20:28:14'),(5,5,'Pieces','Pc(s)',0,NULL,NULL,8,NULL,'2023-01-28 21:05:09','2023-01-28 21:05:09'),(6,6,'Pieces','Pc(s)',0,NULL,NULL,9,NULL,'2023-01-30 16:12:22','2023-01-30 16:12:22'),(7,7,'Pieces','Pc(s)',0,NULL,NULL,10,NULL,'2023-02-01 10:48:07','2023-02-01 10:48:07'),(8,8,'Pieces','Pc(s)',0,NULL,NULL,12,NULL,'2023-02-15 09:06:18','2023-02-15 09:06:18'),(9,9,'Pieces','Pc(s)',0,NULL,NULL,14,NULL,'2023-03-06 13:58:51','2023-03-06 13:58:51'),(10,10,'Pieces','Pc(s)',0,NULL,NULL,15,NULL,'2023-03-21 16:07:24','2023-03-21 16:07:24'),(11,11,'Pieces','Pc(s)',0,NULL,NULL,16,NULL,'2023-03-22 12:12:28','2023-03-22 12:12:28');
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_contact_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_contact_access` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `contact_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_contact_access_user_id_index` (`user_id`),
  KEY `user_contact_access_contact_id_index` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_contact_access` WRITE;
/*!40000 ALTER TABLE `user_contact_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_contact_access` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `surname` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `contact_no` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_id` int unsigned DEFAULT NULL,
  `max_sales_discount_percent` decimal(5,2) DEFAULT NULL,
  `allow_login` tinyint(1) NOT NULL DEFAULT '1',
  `essentials_department_id` int DEFAULT NULL,
  `essentials_designation_id` int DEFAULT NULL,
  `status` enum('active','inactive','terminated') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `crm_contact_id` int unsigned DEFAULT NULL,
  `is_cmmsn_agnt` tinyint(1) NOT NULL DEFAULT '0',
  `cmmsn_percent` decimal(4,2) NOT NULL DEFAULT '0.00',
  `selected_contacts` tinyint(1) NOT NULL DEFAULT '0',
  `dob` date DEFAULT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marital_status` enum('married','unmarried','divorced') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blood_group` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_number` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alt_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `family_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fb_link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_media_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_media_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permanent_address` text COLLATE utf8mb4_unicode_ci,
  `current_address` text COLLATE utf8mb4_unicode_ci,
  `guardian_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_details` longtext COLLATE utf8mb4_unicode_ci,
  `id_proof_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_proof_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crm_department` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Contact person''s department',
  `crm_designation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Contact person''s designation',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  KEY `users_business_id_foreign` (`business_id`),
  KEY `users_user_type_index` (`user_type`),
  KEY `users_crm_contact_id_index` (`crm_contact_id`),
  KEY `users_essentials_department_id_index` (`essentials_department_id`),
  KEY `users_essentials_designation_id_index` (`essentials_designation_id`),
  CONSTRAINT `users_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `users_crm_contact_id_foreign` FOREIGN KEY (`crm_contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'user',NULL,'Luis','Flores','luis.flores',NULL,'$2y$10$880qnh1E7ef.dAGC2OVpQugdGH/dEotUOPcSMQ1MEQyiI/mMPHeue','es',NULL,NULL,'iiPd5m9RI0NzgJLVqINjitVdcWvCBu7sW18Q0DpslaKuzf8XyVRdSFvdLXHn',1,NULL,1,NULL,NULL,'active',NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-26 15:59:33','2023-01-26 15:59:33'),(2,'user','Dr','Rodrigo','Skot Alvarez','rodrigo_admin','crskota@gmail.com','$2y$10$A9jerz7kNtGkbLJJHbVjnuVDuXi.7GpV9j1ww4J74NB3rUnJ56nd2','es',NULL,NULL,'NfRZMAlXayXhu3l81BJg7WTEbb2IbbtthMrvxsTyFK2d8ZSVZ1FFY0dSd4aW',2,NULL,1,NULL,NULL,'active',NULL,0,0.00,0,'1985-06-18','male','unmarried','B (-)','67271431',NULL,'67271416',NULL,NULL,NULL,NULL,NULL,'guapetrol',NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,NULL,NULL,'2023-01-26 16:42:31','2023-02-14 10:51:12'),(3,'user',NULL,'admin',NULL,'admin_shoptec',NULL,'$2y$10$1g29RkMblqZCRXJhGQNTA.Zl/2CugYwqyj8KwcOK4ry4g.njh8BIm','es',NULL,NULL,NULL,3,NULL,1,NULL,NULL,'active',NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-26 19:20:15','2023-01-26 19:20:15'),(4,'user',NULL,'jonathan',NULL,'jonathan','jonathan@loginweb.dev','$2y$10$Lz7C8MAGY.adruOgbQQw5OSiu747SMMHMQSvV0ocVu3Him3aeRb.a','es',NULL,NULL,NULL,3,NULL,1,NULL,NULL,'active',NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,NULL,NULL,'2023-01-26 19:38:51','2023-01-26 19:40:15'),(5,'user',NULL,'percy',NULL,'percy','percy@loginweb.dev','$2y$10$6fEEy9NZOu2cNi4Fk8oGW.GhWhtDcEvtH8LmtK/niXJQmi.qrmKji','es',NULL,NULL,NULL,3,NULL,1,NULL,NULL,'active',NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,NULL,NULL,'2023-01-26 19:39:29','2023-01-26 19:46:01'),(6,'user',NULL,'Claudia',NULL,'claudia',NULL,'$2y$10$LxfdM5eMZ8SuegTUpdIcaOt91vcYPZKU/oEDSrCFmJ9Q90pnm0CtS','es',NULL,NULL,'lpqWdlJX5NHB8Y1l9pk4Af8rIGRIVds3YCgcP3jxa4ZtcFB7aWVyWUhtUAxS',4,NULL,1,NULL,NULL,'active',NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-26 20:28:14','2023-02-24 17:23:14'),(7,'user',NULL,'ventas 1',NULL,'ventas1','ventas1@gmail.com','$2y$10$R66Uxvqubdt8sYZGjUofNO397X1A3HDpxlJamdT3MovSoPNSNVleq','en',NULL,NULL,NULL,4,10.00,1,NULL,NULL,'active',NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,NULL,NULL,'2023-01-26 21:00:07','2023-01-26 21:00:07'),(8,'user',NULL,'Farmacia','Rocha','rocha',NULL,'$2y$10$crhWQBuE9F7dmmE0q4w8reiJtxcLsfyPKyhAFpNcDgQAMWJos9zzK','es',NULL,NULL,'4GEaaoiPTPiDesxlAtESDpFKcdLMAzjaoQEJzflAFraGxdVa1SdIted5j5uF',5,NULL,1,NULL,NULL,'active',NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-28 21:05:09','2023-01-28 21:05:09'),(9,'user',NULL,'ecopharma','trinidad','ecopharma',NULL,'$2y$10$zXMnKJdExuD4xQvEcyohVuEzAbQ5ndS74rR0ar4w2hdB0pXu2.3hu','es',NULL,NULL,'BaCAI3VHeGUqGNdJFUAXZFKM3ZC4yNf7O2olxI4WaQOFs2HcoukkTFWc7cCZ',6,NULL,1,NULL,NULL,'active',NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-01-30 16:12:22','2023-01-30 16:12:22'),(10,'user',NULL,'Flavia','Banegas','jonnes',NULL,'$2y$10$rWUdLpo6/NNBGEJQBGLUOuNwny9wCftNzSwQ2svefzm1xsyamRbFG','es',NULL,NULL,NULL,7,NULL,1,NULL,NULL,'active',NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-01 10:48:07','2023-02-01 10:48:07'),(11,'user','Sra','Gaby','Luna Duchen','gaby.luna','gabyluna240395@gmail.com','$2y$10$apBrDlJ9Sv.XkBpm0hrftOD2D5J0TD7bp6EOQwgEvXAtyEVGs9Pyq','es',NULL,NULL,NULL,2,NULL,1,NULL,NULL,'active',NULL,0,0.00,0,'1995-03-24','female','unmarried','o +','72829380',NULL,'73910644',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,NULL,NULL,'2023-02-14 10:47:59','2023-02-17 16:27:22'),(12,'user',NULL,'Riberfarma',NULL,'riberfarma',NULL,'$2y$10$DtWAlhuBFtYMpHrgbR1zYuouNulQi7q.RSRZQG0pmAEdRcE.7r31i','es',NULL,NULL,NULL,8,NULL,1,NULL,NULL,'active',NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-02-15 09:06:18','2023-02-15 09:06:18'),(13,'user','Sr','Junior','Mendez','junior.mendez','junior@gmail.com','$2y$10$bTO9r0.qTHYRQ5QIgolOsOI7ZglY7XlK5YTr5igGiRzIupsfnR0WG','en',NULL,NULL,NULL,2,NULL,1,NULL,NULL,'active',NULL,0,0.00,0,NULL,'male',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,NULL,NULL,'2023-02-17 12:07:07','2023-02-17 12:07:08'),(14,'user',NULL,'Carlos','David','central',NULL,'$2y$10$MoHIcW7BgP9pN2hvSOPo7OObXj702Vk3D3B0pmpEug2ZgbT.J/Lyi','es',NULL,NULL,NULL,9,NULL,1,NULL,NULL,'active',NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-06 13:58:51','2023-03-06 13:58:51'),(15,'user','Dueña','Alejandra',NULL,'alejandra',NULL,'$2y$10$29EaEKFm15FWt1n685Ta5ulm7tPpdMfG2ey3tRkw7FeNXsAjj29ta','es',NULL,NULL,'Rou14xJOKeXqbtwt3dGlnRp8uwPP50WHMUSsdwdn11L8b9pTOQYv3ZFOAtO9',10,NULL,1,NULL,NULL,'active',NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,NULL,NULL,'2023-03-21 16:07:24','2023-03-22 11:22:37'),(16,'user',NULL,'Maxi','Ahorro','maxiahorro',NULL,'$2y$10$R2pyD2jqyUdFwhW3VJTmvO4xLDY.AB1lvt8jMdLA4mO6gTbihnAfO','es',NULL,NULL,NULL,11,NULL,1,NULL,NULL,'active',NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-03-22 12:12:28','2023-03-22 12:12:28');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `variation_group_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `variation_group_prices` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `variation_id` int unsigned NOT NULL,
  `price_group_id` int unsigned NOT NULL,
  `price_inc_tax` decimal(22,4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `variation_group_prices_variation_id_foreign` (`variation_id`),
  KEY `variation_group_prices_price_group_id_foreign` (`price_group_id`),
  CONSTRAINT `variation_group_prices_price_group_id_foreign` FOREIGN KEY (`price_group_id`) REFERENCES `selling_price_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `variation_group_prices_variation_id_foreign` FOREIGN KEY (`variation_id`) REFERENCES `variations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `variation_group_prices` WRITE;
/*!40000 ALTER TABLE `variation_group_prices` DISABLE KEYS */;
/*!40000 ALTER TABLE `variation_group_prices` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `variation_location_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `variation_location_details` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int unsigned NOT NULL,
  `product_variation_id` int unsigned NOT NULL COMMENT 'id from product_variations table',
  `variation_id` int unsigned NOT NULL,
  `location_id` int unsigned NOT NULL,
  `qty_available` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `variation_location_details_location_id_foreign` (`location_id`),
  KEY `variation_location_details_product_id_index` (`product_id`),
  KEY `variation_location_details_product_variation_id_index` (`product_variation_id`),
  KEY `variation_location_details_variation_id_index` (`variation_id`),
  CONSTRAINT `variation_location_details_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `business_locations` (`id`),
  CONSTRAINT `variation_location_details_variation_id_foreign` FOREIGN KEY (`variation_id`) REFERENCES `variations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `variation_location_details` WRITE;
/*!40000 ALTER TABLE `variation_location_details` DISABLE KEYS */;
INSERT INTO `variation_location_details` VALUES (1,3,3,3,5,51.0000,'2023-01-26 19:29:07','2023-02-10 19:40:09'),(2,4,4,4,5,1.0000,'2023-01-26 19:32:40','2023-02-10 19:40:09'),(4,32,32,32,7,120.0000,'2023-02-13 19:03:59','2023-02-13 19:03:59'),(5,33,33,33,7,25.0000,'2023-02-13 19:37:31','2023-03-29 11:09:32'),(6,34,34,34,7,2.0000,'2023-02-13 20:01:55','2023-03-29 10:49:46'),(7,35,35,35,7,310.0000,'2023-02-13 20:10:10','2023-03-29 10:49:46'),(8,27,27,27,2,0.0000,'2023-02-16 10:33:16','2023-02-17 12:09:19'),(9,12,12,12,2,0.0000,'2023-02-16 10:40:16','2023-02-17 12:17:22'),(10,12,12,12,3,0.0000,'2023-02-16 10:40:16','2023-02-17 18:38:46'),(11,12,12,12,4,0.0000,'2023-02-16 10:40:16','2023-02-17 11:58:06'),(12,27,27,27,3,10.0000,'2023-02-16 10:40:43','2023-02-17 17:48:22'),(13,27,27,27,4,0.0000,'2023-02-16 10:40:43','2023-02-17 12:09:19'),(14,13,13,13,3,0.0000,'2023-02-17 12:23:57','2023-02-17 16:13:53'),(16,16,16,16,3,0.0000,'2023-02-17 12:24:34','2023-02-17 16:23:22'),(17,17,17,17,3,0.0000,'2023-02-17 12:24:44','2023-02-17 16:23:45'),(18,19,19,19,3,0.0000,'2023-02-17 12:25:13','2023-02-17 18:38:46'),(19,36,36,36,3,0.0000,'2023-02-17 12:35:03','2023-02-17 16:18:06'),(20,18,18,18,3,0.0000,'2023-02-17 12:38:49','2023-02-17 18:38:46'),(21,26,26,26,3,0.0000,'2023-02-17 12:40:22','2023-02-17 18:38:46'),(22,15,15,15,3,0.0000,'2023-02-17 12:57:59','2023-02-17 16:14:55'),(23,20,20,20,3,0.0000,'2023-02-17 13:03:04','2023-02-17 16:16:24'),(24,24,24,24,3,0.0000,'2023-02-17 13:05:05','2023-02-17 18:38:46'),(25,23,23,23,3,0.0000,'2023-02-17 16:29:59','2023-02-17 16:34:27'),(26,255,255,255,7,141.0000,'2023-03-28 12:15:41','2023-03-29 11:09:32'),(27,256,256,256,7,50.0000,'2023-03-28 12:15:53','2023-03-28 12:15:53'),(28,257,257,257,12,47.0000,'2023-03-28 22:59:38','2023-03-28 22:59:38'),(29,258,258,258,12,6.0000,'2023-03-28 23:01:55','2023-03-28 23:01:55'),(30,259,259,259,12,2.0000,'2023-03-28 23:02:36','2023-03-28 23:02:36'),(31,261,261,261,12,23.0000,'2023-03-28 23:05:55','2023-03-28 23:05:55'),(32,262,262,262,12,6.0000,'2023-03-28 23:06:26','2023-03-28 23:06:26'),(33,271,271,271,12,2.0000,'2023-03-28 23:18:02','2023-03-28 23:18:02'),(34,272,272,272,7,59.0000,'2023-03-28 23:48:32','2023-03-28 23:58:44'),(37,275,275,275,6,43.0000,'2023-03-29 14:10:27','2023-03-29 14:11:27'),(38,312,312,312,12,2.0000,'2023-03-30 01:00:15','2023-03-30 01:00:15'),(39,313,313,313,12,1.0000,'2023-03-30 01:00:56','2023-03-30 01:00:56'),(40,314,314,314,12,1.0000,'2023-03-30 01:01:22','2023-03-30 01:01:22'),(41,315,315,315,12,4.0000,'2023-03-30 01:02:03','2023-03-30 01:02:03'),(42,316,316,316,12,3.0000,'2023-03-30 01:02:42','2023-03-30 01:02:42'),(43,318,318,318,12,1.0000,'2023-03-30 01:03:49','2023-03-30 01:03:49');
/*!40000 ALTER TABLE `variation_location_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `variation_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `variation_templates` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int unsigned NOT NULL,
  `woocommerce_attr_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `variation_templates_business_id_foreign` (`business_id`),
  KEY `variation_templates_woocommerce_attr_id_index` (`woocommerce_attr_id`),
  CONSTRAINT `variation_templates_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `variation_templates` WRITE;
/*!40000 ALTER TABLE `variation_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `variation_templates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `variation_value_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `variation_value_templates` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `variation_template_id` int unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `variation_value_templates_name_index` (`name`),
  KEY `variation_value_templates_variation_template_id_index` (`variation_template_id`),
  CONSTRAINT `variation_value_templates_variation_template_id_foreign` FOREIGN KEY (`variation_template_id`) REFERENCES `variation_templates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `variation_value_templates` WRITE;
/*!40000 ALTER TABLE `variation_value_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `variation_value_templates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `variations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `variations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` int unsigned NOT NULL,
  `sub_sku` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_variation_id` int unsigned NOT NULL,
  `woocommerce_variation_id` int DEFAULT NULL,
  `variation_value_id` int DEFAULT NULL,
  `default_purchase_price` decimal(22,4) DEFAULT NULL,
  `dpp_inc_tax` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `profit_percent` decimal(22,4) NOT NULL DEFAULT '0.0000',
  `default_sell_price` decimal(22,4) DEFAULT NULL,
  `sell_price_inc_tax` decimal(22,4) DEFAULT NULL COMMENT 'Sell price including tax',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `combo_variations` text COLLATE utf8mb4_unicode_ci COMMENT 'Contains the combo variation details',
  PRIMARY KEY (`id`),
  KEY `variations_product_id_foreign` (`product_id`),
  KEY `variations_product_variation_id_foreign` (`product_variation_id`),
  KEY `variations_name_index` (`name`),
  KEY `variations_sub_sku_index` (`sub_sku`),
  KEY `variations_variation_value_id_index` (`variation_value_id`),
  KEY `variations_woocommerce_variation_id_index` (`woocommerce_variation_id`),
  CONSTRAINT `variations_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `variations_product_variation_id_foreign` FOREIGN KEY (`product_variation_id`) REFERENCES `product_variations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=319 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `variations` WRITE;
/*!40000 ALTER TABLE `variations` DISABLE KEYS */;
INSERT INTO `variations` VALUES (3,'DUMMY',3,'0003',3,NULL,NULL,22.5000,22.5000,166.6700,60.0000,60.0000,'2023-01-26 19:28:13','2023-01-26 19:28:13',NULL,'[]'),(4,'DUMMY',4,'0004',4,NULL,NULL,265.0000,265.0000,32.0800,350.0000,350.0000,'2023-01-26 19:32:31','2023-01-26 19:32:31',NULL,'[]'),(5,'DUMMY',5,'0005',5,NULL,NULL,1775.0000,1775.0000,9.8600,1950.0000,1950.0000,'2023-01-26 19:35:27','2023-01-26 19:35:27',NULL,'[]'),(6,'DUMMY',6,'0006',6,NULL,NULL,0.0000,0.0000,0.0000,1066.0000,1066.0000,'2023-01-26 19:48:52','2023-01-26 19:49:27',NULL,'[]'),(7,'DUMMY',7,'0007',7,NULL,NULL,0.0000,0.0000,0.0000,1916.1200,1916.1200,'2023-01-26 19:55:36','2023-01-26 19:55:36',NULL,'[]'),(9,'DUMMY',9,'0009',9,NULL,NULL,1400.0000,1400.0000,0.0000,1400.0000,1400.0000,'2023-01-27 10:27:33','2023-01-27 10:28:09',NULL,'[]'),(10,'DUMMY',10,'0010',10,NULL,NULL,1075.0000,1075.0000,18.1400,1270.0000,1270.0000,'2023-01-27 15:52:40','2023-01-27 15:52:40',NULL,'[]'),(11,'DUMMY',11,'0011',11,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-01-27 16:58:25','2023-02-17 17:14:53',NULL,'[]'),(12,'DUMMY',12,'0012',12,NULL,NULL,5.0000,5.0000,25.0000,7.0000,7.0000,'2023-01-27 16:58:25','2023-02-17 16:35:18',NULL,'[]'),(13,'DUMMY',13,'0013',13,NULL,NULL,5.0000,5.0000,25.0000,7.0000,7.0000,'2023-01-27 16:58:25','2023-02-17 15:56:16',NULL,'[]'),(15,'DUMMY',15,'0015',15,NULL,NULL,8.0000,8.0000,25.0000,10.0000,10.0000,'2023-01-27 16:58:25','2023-02-17 17:03:58',NULL,'[]'),(16,'DUMMY',16,'0016',16,NULL,NULL,1.0000,1.0000,25.0000,2.0000,2.0000,'2023-01-27 16:58:25','2023-02-17 16:02:49',NULL,'[]'),(17,'DUMMY',17,'0017',17,NULL,NULL,4.0000,4.0000,25.0000,5.0000,5.0000,'2023-01-27 16:58:25','2023-02-17 16:03:03',NULL,'[]'),(18,'DUMMY',18,'0018',18,NULL,NULL,0.5000,0.5000,25.0000,0.5000,0.5000,'2023-01-27 16:58:25','2023-02-17 16:05:53',NULL,'[]'),(19,'DUMMY',19,'0019',19,NULL,NULL,0.5000,0.5000,25.0000,0.5000,0.5000,'2023-01-27 16:58:25','2023-02-17 16:07:19',NULL,'[]'),(20,'DUMMY',20,'0020',20,NULL,NULL,0.5000,0.5000,25.0000,0.5000,0.5000,'2023-01-27 16:58:25','2023-02-17 16:12:15',NULL,'[]'),(21,'DUMMY',21,'0021',21,NULL,NULL,1.0000,1.0000,25.0000,1.0000,1.0000,'2023-01-27 16:58:25','2023-02-17 16:16:40',NULL,'[]'),(22,'DUMMY',22,'0022',22,NULL,NULL,0.5000,0.5000,25.0000,0.5000,0.5000,'2023-01-27 16:58:25','2023-02-17 16:17:02',NULL,'[]'),(23,'DUMMY',23,'0023',23,NULL,NULL,4.0000,4.0000,25.0000,5.0000,5.0000,'2023-01-27 16:58:25','2023-02-17 16:04:00',NULL,'[]'),(24,'DUMMY',24,'0024',24,NULL,NULL,2.0000,2.0000,25.0000,2.0000,2.0000,'2023-01-27 16:58:25','2023-02-17 16:07:36',NULL,'[]'),(25,'DUMMY',25,'0025',25,NULL,NULL,1.0000,1.0000,25.0000,3.0000,3.0000,'2023-01-27 16:58:25','2023-02-17 16:17:52',NULL,'[]'),(26,'DUMMY',26,'0026',26,NULL,NULL,0.2500,0.2500,25.0000,0.2500,0.2500,'2023-01-27 16:58:25','2023-02-17 16:08:02',NULL,'[]'),(27,'DUMMY',27,'0027',27,NULL,NULL,8.2500,8.2500,81.8200,15.0000,15.0000,'2023-01-27 17:01:34','2023-02-17 18:10:33',NULL,'[{\"variation_id\":\"19\",\"quantity\":\"1.00\",\"unit_id\":\"2\"},{\"variation_id\":\"24\",\"quantity\":\"1.00\",\"unit_id\":\"2\"},{\"variation_id\":\"12\",\"quantity\":\"1.00\",\"unit_id\":\"2\"},{\"variation_id\":\"26\",\"quantity\":\"1.00\",\"unit_id\":\"2\"},{\"variation_id\":\"18\",\"quantity\":\"1.00\",\"unit_id\":\"2\"}]'),(28,'DUMMY',28,'0028',28,NULL,NULL,8.2500,8.2500,81.8200,15.0000,15.0000,'2023-01-27 17:02:27','2023-02-17 16:05:27',NULL,'[{\"variation_id\":\"20\",\"quantity\":\"1.00\",\"unit_id\":\"2\"},{\"variation_id\":\"24\",\"quantity\":\"1.00\",\"unit_id\":\"2\"},{\"variation_id\":\"13\",\"quantity\":\"1.00\",\"unit_id\":\"2\"},{\"variation_id\":\"26\",\"quantity\":\"1.00\",\"unit_id\":\"2\"},{\"variation_id\":\"18\",\"quantity\":\"1.00\",\"unit_id\":\"2\"}]'),(29,'DUMMY',29,'0029',29,NULL,NULL,11.7500,11.7500,2.1300,12.0000,12.0000,'2023-01-27 17:03:55','2023-02-17 13:02:16',NULL,'[{\"variation_id\":\"21\",\"quantity\":\"1.00\",\"unit_id\":\"2\"},{\"variation_id\":\"24\",\"quantity\":\"1.00\",\"unit_id\":\"2\"},{\"variation_id\":\"15\",\"quantity\":\"1.00\",\"unit_id\":\"2\"},{\"variation_id\":\"26\",\"quantity\":\"1.00\",\"unit_id\":\"2\"},{\"variation_id\":\"18\",\"quantity\":\"1.00\",\"unit_id\":\"2\"}]'),(30,'DUMMY',30,'0030',30,NULL,NULL,8.5000,8.5000,17.6500,10.0000,10.0000,'2023-01-27 17:05:04','2023-02-17 16:06:50',NULL,'[{\"variation_id\":\"22\",\"quantity\":\"1.00\",\"unit_id\":\"2\"},{\"variation_id\":\"14\",\"quantity\":\"1.00\",\"unit_id\":\"2\"},{\"variation_id\":\"23\",\"quantity\":\"1.00\",\"unit_id\":\"2\"},{\"variation_id\":\"24\",\"quantity\":\"1.00\",\"unit_id\":\"2\"}]'),(31,'DUMMY',31,'0031',31,NULL,NULL,1565.0000,1565.0000,11.1800,1740.0000,1740.0000,'2023-02-10 19:34:59','2023-02-10 19:34:59',NULL,'[]'),(32,'DUMMY',32,'0032',32,NULL,NULL,1.5000,1.5000,33.3300,2.0000,2.0000,'2023-02-13 19:03:46','2023-02-13 19:44:51',NULL,'[]'),(33,'DUMMY',33,'0033',33,NULL,NULL,2.0000,2.0000,50.0000,3.0000,3.0000,'2023-02-13 19:37:22','2023-02-13 19:44:23',NULL,'[]'),(34,'DUMMY',34,'0034',34,NULL,NULL,10.0000,10.0000,0.0000,10.0000,10.0000,'2023-02-13 20:01:44','2023-02-13 20:44:46',NULL,'[]'),(35,'DUMMY',35,'0035',35,NULL,NULL,0.5000,0.5000,40.0000,0.7000,0.7000,'2023-02-13 20:09:05','2023-02-13 20:09:05',NULL,'[]'),(36,'DUMMY',36,'0036',36,NULL,NULL,1.0000,1.0000,100.0000,2.0000,2.0000,'2023-02-17 12:32:48','2023-02-17 12:34:37',NULL,'[]'),(255,'DUMMY',255,'0255',255,NULL,NULL,1.0000,1.0000,100.0000,2.0000,2.0000,'2023-03-28 12:11:47','2023-03-28 12:25:27',NULL,'[]'),(256,'DUMMY',256,'0256',256,NULL,NULL,5.0000,5.0000,100.0000,10.0000,10.0000,'2023-03-28 12:13:06','2023-03-28 12:13:06',NULL,'[]'),(257,'DUMMY',257,'0257',257,NULL,NULL,29.7300,29.7300,51.3600,45.0000,45.0000,'2023-03-28 22:59:38','2023-03-28 22:59:38',NULL,'[]'),(258,'DUMMY',258,'0258',258,NULL,NULL,42.1000,42.1000,78.1500,75.0000,75.0000,'2023-03-28 23:01:55','2023-03-28 23:01:55',NULL,'[]'),(259,'DUMMY',259,'0259',259,NULL,NULL,39.1000,39.1000,40.6600,55.0000,55.0000,'2023-03-28 23:02:35','2023-03-28 23:02:35',NULL,'[]'),(260,'DUMMY',260,'0260',260,NULL,NULL,16.4000,16.4000,52.4400,25.0000,25.0000,'2023-03-28 23:05:20','2023-03-28 23:05:20',NULL,'[]'),(261,'DUMMY',261,'0261',261,NULL,NULL,34.6600,34.6600,9.6400,38.0000,38.0000,'2023-03-28 23:05:55','2023-03-28 23:05:55',NULL,'[]'),(262,'DUMMY',262,'0262',262,NULL,NULL,34.0000,34.0000,17.6500,40.0000,40.0000,'2023-03-28 23:06:26','2023-03-28 23:06:26',NULL,'[]'),(263,'DUMMY',263,'0263',263,NULL,NULL,18.0000,18.0000,38.8900,25.0000,25.0000,'2023-03-28 23:07:04','2023-03-28 23:07:04',NULL,'[]'),(264,'DUMMY',264,'0264',264,NULL,NULL,52.0000,52.0000,15.3800,60.0000,60.0000,'2023-03-28 23:07:34','2023-03-28 23:07:34',NULL,'[]'),(265,'DUMMY',265,'0265',265,NULL,NULL,2.0000,2.0000,200.0000,6.0000,6.0000,'2023-03-28 23:14:57','2023-03-28 23:14:57',NULL,'[]'),(266,'DUMMY',266,'0266',266,NULL,NULL,37.1900,37.1900,34.4400,50.0000,50.0000,'2023-03-28 23:15:34','2023-03-28 23:15:34',NULL,'[]'),(267,'DUMMY',267,'0267',267,NULL,NULL,31.4100,31.4100,27.3500,40.0000,40.0000,'2023-03-28 23:16:09','2023-03-28 23:16:09',NULL,'[]'),(268,'DUMMY',268,'0268',268,NULL,NULL,36.0000,36.0000,38.8900,50.0000,50.0000,'2023-03-28 23:16:33','2023-03-28 23:16:33',NULL,'[]'),(269,'DUMMY',269,'0269',269,NULL,NULL,125.0000,125.0000,16.0000,145.0000,145.0000,'2023-03-28 23:17:10','2023-03-28 23:17:10',NULL,'[]'),(270,'DUMMY',270,'0270',270,NULL,NULL,340.0000,340.0000,5.8800,360.0000,360.0000,'2023-03-28 23:17:38','2023-03-28 23:17:38',NULL,'[]'),(271,'DUMMY',271,'0271',271,NULL,NULL,102.0000,102.0000,27.4500,130.0000,130.0000,'2023-03-28 23:18:02','2023-03-28 23:18:02',NULL,'[]'),(272,'DUMMY',272,'0272',272,NULL,NULL,1.0000,1.0000,100.0000,2.0000,2.0000,'2023-03-28 23:48:32','2023-03-28 23:48:32',NULL,'[]'),(275,'DUMMY',275,'0275',275,NULL,NULL,1.0000,1.0000,100.0000,2.0000,2.0000,'2023-03-29 14:10:27','2023-03-29 14:10:27',NULL,'[]'),(276,'DUMMY',276,'0276',276,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 16:19:28','2023-03-29 16:19:28',NULL,'[]'),(277,'DUMMY',277,'0277',277,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 16:23:19','2023-03-29 16:23:19',NULL,'[]'),(278,'DUMMY',278,'0278',278,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 16:26:32','2023-03-29 16:26:32',NULL,'[]'),(279,'DUMMY',279,'0279',279,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 16:27:45','2023-03-29 16:27:45',NULL,'[]'),(280,'DUMMY',280,'0280',280,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 16:36:31','2023-03-29 16:36:31',NULL,'[]'),(281,'DUMMY',281,'0281',281,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 16:44:06','2023-03-29 16:44:06',NULL,'[]'),(282,'DUMMY',282,'0282',282,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 16:46:14','2023-03-29 16:46:14',NULL,'[]'),(283,'DUMMY',283,'0283',283,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 16:58:46','2023-03-29 16:58:46',NULL,'[]'),(284,'DUMMY',284,'0284',284,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 17:05:19','2023-03-29 17:05:19',NULL,'[]'),(285,'DUMMY',285,'0285',285,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 17:31:59','2023-03-29 17:31:59',NULL,'[]'),(286,'DUMMY',286,'0286',286,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 17:34:03','2023-03-29 17:34:03',NULL,'[]'),(287,'DUMMY',287,'0287',287,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 17:41:19','2023-03-29 17:41:19',NULL,'[]'),(288,'DUMMY',288,'0288',288,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 18:13:13','2023-03-29 18:13:13',NULL,'[]'),(289,'DUMMY',289,'0289',289,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 18:43:38','2023-03-29 18:43:38',NULL,'[]'),(290,'DUMMY',290,'0290',290,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 18:46:00','2023-03-29 18:46:00',NULL,'[]'),(291,'DUMMY',291,'0291',291,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 18:47:55','2023-03-29 18:47:55',NULL,'[]'),(292,'DUMMY',292,'0292',292,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 18:55:15','2023-03-29 18:55:15',NULL,'[]'),(293,'DUMMY',293,'0293',293,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 18:57:42','2023-03-29 18:57:42',NULL,'[]'),(294,'DUMMY',294,'0294',294,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 18:59:16','2023-03-29 18:59:16',NULL,'[]'),(295,'DUMMY',295,'0295',295,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 19:01:13','2023-03-29 19:01:13',NULL,'[]'),(296,'DUMMY',296,'0296',296,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 19:03:44','2023-03-29 19:03:44',NULL,'[]'),(297,'DUMMY',297,'0297',297,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 19:04:46','2023-03-29 19:04:46',NULL,'[]'),(298,'DUMMY',298,'0298',298,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 19:06:40','2023-03-29 19:06:40',NULL,'[]'),(299,'DUMMY',299,'0299',299,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 19:08:44','2023-03-29 19:08:44',NULL,'[]'),(300,'DUMMY',300,'0300',300,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 19:11:47','2023-03-29 19:11:47',NULL,'[]'),(301,'DUMMY',301,'0301',301,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 19:13:51','2023-03-29 19:13:51',NULL,'[]'),(302,'DUMMY',302,'0302',302,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 19:15:19','2023-03-29 19:15:19',NULL,'[]'),(303,'DUMMY',303,'0303',303,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 19:18:20','2023-03-29 19:18:20',NULL,'[]'),(304,'DUMMY',304,'0304',304,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 19:21:22','2023-03-29 19:21:22',NULL,'[]'),(305,'DUMMY',305,'0305',305,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 19:24:07','2023-03-29 19:24:07',NULL,'[]'),(306,'DUMMY',306,'0306',306,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 19:29:37','2023-03-29 19:29:37',NULL,'[]'),(307,'DUMMY',307,'0307',307,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 19:31:27','2023-03-29 19:31:27',NULL,'[]'),(308,'DUMMY',308,'0308',308,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 19:35:31','2023-03-29 19:35:31',NULL,'[]'),(309,'DUMMY',309,'0309',309,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 19:38:21','2023-03-29 19:38:21',NULL,'[]'),(310,'DUMMY',310,'0310',310,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 19:40:16','2023-03-29 19:40:16',NULL,'[]'),(311,'DUMMY',311,'0311',311,NULL,NULL,0.0000,0.0000,25.0000,0.0000,0.0000,'2023-03-29 19:45:50','2023-03-29 19:45:50',NULL,'[]'),(312,'DUMMY',312,'0312',312,NULL,NULL,245.0000,245.0000,33.4700,327.0000,327.0000,'2023-03-30 01:00:15','2023-03-30 01:00:15',NULL,'[]'),(313,'DUMMY',313,'0313',313,NULL,NULL,519.4700,519.4700,34.7500,700.0000,700.0000,'2023-03-30 01:00:56','2023-03-30 01:00:56',NULL,'[]'),(314,'DUMMY',314,'0314',314,NULL,NULL,294.0000,294.0000,39.4600,410.0000,410.0000,'2023-03-30 01:01:22','2023-03-30 01:01:22',NULL,'[]'),(315,'DUMMY',315,'0315',315,NULL,NULL,189.0000,189.0000,32.2800,250.0000,250.0000,'2023-03-30 01:02:03','2023-03-30 01:02:03',NULL,'[]'),(316,'DUMMY',316,'0316',316,NULL,NULL,499.5000,499.5000,25.1300,625.0000,625.0000,'2023-03-30 01:02:42','2023-03-30 01:02:42',NULL,'[]'),(317,'DUMMY',317,'0317',317,NULL,NULL,205.5000,205.5000,38.6900,285.0000,285.0000,'2023-03-30 01:03:12','2023-03-30 01:03:12',NULL,'[]'),(318,'DUMMY',318,'0318',318,NULL,NULL,300.0000,300.0000,43.3300,430.0000,430.0000,'2023-03-30 01:03:49','2023-03-30 01:03:49',NULL,'[]');
/*!40000 ALTER TABLE `variations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `warranties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `warranties` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `duration` int NOT NULL,
  `duration_type` enum('days','months','years') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `warranties_business_id_index` (`business_id`),
  KEY `warranties_duration_type_index` (`duration_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `warranties` WRITE;
/*!40000 ALTER TABLE `warranties` DISABLE KEYS */;
/*!40000 ALTER TABLE `warranties` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `woocommerce_sync_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `woocommerce_sync_logs` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int NOT NULL,
  `sync_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` longtext COLLATE utf8mb4_unicode_ci,
  `details` longtext COLLATE utf8mb4_unicode_ci,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `woocommerce_sync_logs` WRITE;
/*!40000 ALTER TABLE `woocommerce_sync_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `woocommerce_sync_logs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

